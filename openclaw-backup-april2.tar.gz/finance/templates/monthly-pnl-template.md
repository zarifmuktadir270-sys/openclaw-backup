# Zen Labs — Monthly P&L Template

## [Month Year]

### Revenue
| Line Item | Amount |
|-----------|--------|
| POS Subscriptions | $ |
| Web Design Setup Fees | $ |
| Web Design Hosting | $ |
| **Total Revenue** | **$** |

### Cost of Goods Sold (COGS)
| Line Item | Amount |
|-----------|--------|
| Infrastructure (per-client hosting costs) | $ |
| Freelance / contractor (project delivery) | $ |
| Payment processing fees | $ |
| **Total COGS** | **$** |

### Gross Profit
| | Amount |
|-----------|--------|
| **Gross Profit** | **$** |
| **Gross Margin %** | **%** |

### Operating Expenses
| Line Item | Budget | Actual | Variance |
|-----------|--------|--------|----------|
| Team / Contractors | $ | $ | $ |
| Software & Tools | $ | $ | $ |
| Marketing & Sales | $ | $ | $ |
| Infrastructure (fixed) | $ | $ | $ |
| Banking & FX fees | $ | $ | $ |
| Legal & Compliance | $ | $ | $ |
| Miscellaneous | $ | $ | $ |
| **Total OpEx** | **$** | **$** | **$** |

### Net Income
| | Amount |
|-----------|--------|
| **Net Income (Loss)** | **$** |
| **Net Margin %** | **%** |

---

### Key Metrics This Month
- **MRR:** $
- **New customers:** 
- **Churned customers:** 
- **Projects delivered:** 
- **Cash on hand:** $
- **Runway:** months
