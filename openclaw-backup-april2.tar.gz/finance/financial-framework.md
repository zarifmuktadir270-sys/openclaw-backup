# Zen Labs — Financial Framework

*Created: 2026-03-27 by Finance Manager*

---

## 💰 Revenue Model

### Stream 1: POS Subscriptions (Bangladesh Market)
| Tier | Monthly Price (est.) | Target |
|------|---------------------|--------|
| Basic | $15–$25/mo | Small retailers |
| Pro | $40–$75/mo | Mid-size shops |
| Enterprise | $100+/mo | Chains/multi-location |

- **Revenue type:** Recurring (MRR)
- **Payment:** Monthly or annual (discount for annual)
- **Key levers:** Churn reduction, upsells, volume

### Stream 2: Web Design Projects (US/AU Market)
| Package | Setup Fee | Monthly Hosting |
|---------|-----------|-----------------|
| Starter | $499 | $79/mo |
| Business | $1,499 | $149/mo |
| Premium | $2,999 | $299/mo |

- **Revenue type:** One-time setup + recurring hosting
- **Payment:** 50% upfront, 50% on delivery for setup; hosting auto-charged monthly
- **Key levers:** Higher package mix, referral pipeline, low hosting churn

---

## 📊 Expense Categories

### Fixed / Recurring
| Category | Examples | Est. Monthly Range |
|----------|----------|--------------------|
| **Infrastructure** | Servers, domains, SaaS tools, APIs | $200–$800 |
| **Team / Contractors** | Dev, design, VA support | $500–$3,000 |
| **Software & Tools** | Design tools, project mgmt, accounting | $100–$400 |
| **Marketing** | Ads, content, SEO tools | $100–$500 |

### Variable / Project-Based
| Category | Examples |
|----------|----------|
| **Freelance Dev** | Overflow dev work per project |
| **Assets** | Stock photos, fonts, plugins |
| **Client Tools** | Domain purchases, hosting setup per client |
| **Payment Processing** | Stripe/PayPal fees (~2.9% + $0.30) |

### Operational
| Category | Examples |
|----------|----------|
| **Banking & FX** | International transfer fees, currency conversion |
| **Legal & Compliance** | Contracts, business registration |
| **Misc** | Contingency, one-off purchases |

---

## 📈 Key Metrics to Track

### Revenue Metrics
- **MRR** (Monthly Recurring Revenue) — total from POS + hosting
- **ARR** (Annual Recurring Revenue) — MRR × 12
- **ARPU** (Average Revenue Per User) — by stream
- **New MRR** — revenue from new customers this month
- **Expansion MRR** — upsells/upgrades from existing customers
- **Churned MRR** — revenue lost from cancellations
- **Net Revenue Retention** — (New + Expansion - Churn) / Starting MRR

### Project Metrics
- **Average project value** — setup fees collected / projects delivered
- **Project margin** — (setup fee - cost to deliver) / setup fee
- **Hosting margin** — (hosting revenue - infra cost per client) / hosting revenue
- **Pipeline value** — signed + proposals outstanding

### Health Metrics
- **Runway** — cash on hand / monthly burn rate
- **Gross margin** — (revenue - COGS) / revenue
- **CAC** (Customer Acquisition Cost) — total sales+marketing / new customers
- **LTV** (Lifetime Value) — ARPU × average customer lifespan
- **LTV:CAC ratio** — target ≥ 3:1
- **Burn rate** — net cash out per month
- **Break-even point** — monthly fixed costs / gross margin %

---

## 🗓️ Reporting Cadence

| Report | Frequency | Contents |
|--------|-----------|----------|
| **Cash Position** | Weekly | Bank balance, upcoming payments, invoices due |
| **P&L Snapshot** | Monthly | Revenue by stream, expenses by category, net income |
| **MRR Dashboard** | Monthly | MRR movement (new/expansion/churn), cohort analysis |
| **Project Pipeline** | Bi-weekly | Active projects, proposals, conversion rate |
| **Forecast Update** | Monthly | 3-month revenue/expense projection, runway check |
| **Full Financial Review** | Quarterly | Deep dive — all metrics, trends, pricing review |

---

## 🎯 Immediate Priorities

1. **Set up expense tracking** — categorize all current spend
2. **Establish MRR baseline** — know exactly where we stand today
3. **Create invoice templates** — standardized for both revenue streams
4. **Build simple P&L** — even a spreadsheet, start recording
5. **Define pricing guardrails** — minimum margins before discounting

---

*This framework is a living document. As Zen Labs grows, we'll refine categories, add dashboards, and build toward proper financial tooling.*
