CREATE EXTENSION IF NOT EXISTS postgis;

-- Companies (API consumers)
CREATE TABLE IF NOT EXISTS companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  api_key VARCHAR(64) UNIQUE NOT NULL,
  plan VARCHAR(50) DEFAULT 'starter',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Saved delivery locations / pins
CREATE TABLE IF NOT EXISTS delivery_locations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  customer_id VARCHAR(255) NOT NULL,
  location GEOGRAPHY(POINT, 4326) NOT NULL,
  plus_code VARCHAR(20),
  address_label VARCHAR(255),
  delivery_notes TEXT,
  landmark TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_delivery_locations_geom ON delivery_locations USING GIST(location);
CREATE INDEX IF NOT EXISTS idx_delivery_locations_company ON delivery_locations(company_id);
CREATE INDEX IF NOT EXISTS idx_delivery_locations_customer ON delivery_locations(company_id, customer_id);

-- Active deliveries with driver tracking
CREATE TABLE IF NOT EXISTS active_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  delivery_location_id UUID REFERENCES delivery_locations(id) ON DELETE SET NULL,
  driver_id VARCHAR(255) NOT NULL,
  driver_location GEOGRAPHY(POINT, 4326),
  status VARCHAR(50) DEFAULT 'assigned',
  eta_minutes INTEGER,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  delivered_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_active_deliveries_company ON active_deliveries(company_id);
CREATE INDEX IF NOT EXISTS idx_active_deliveries_driver ON active_deliveries USING GIST(driver_location);
CREATE INDEX IF NOT EXISTS idx_active_deliveries_status ON active_deliveries(status);

-- Analytics: aggregated per-completion delivery data
CREATE TABLE IF NOT EXISTS delivery_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  delivery_id UUID REFERENCES active_deliveries(id) ON DELETE SET NULL,
  driver_call_count INTEGER DEFAULT 0,
  time_to_find_minutes FLOAT,
  was_pin_used BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_delivery_analytics_company ON delivery_analytics(company_id);
CREATE INDEX IF NOT EXISTS idx_delivery_analytics_created ON delivery_analytics(created_at);
