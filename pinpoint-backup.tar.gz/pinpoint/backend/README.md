# PinPoint Backend API

A delivery location pinning API built on Express + PostGIS. Save precise customer delivery pins, track drivers in real-time via WebSockets, and reduce failed deliveries.

## Quick Start

### Prerequisites

- Node.js 18+
- Docker & Docker Compose (for PostGIS)
- Git

### 1. Start the database

```bash
docker compose up -d db
```

This starts PostGIS on `localhost:5432` and runs the schema migrations in `init-db/`.

### 2. Install & run the API

```bash
npm install
cp .env.example .env    # Edit DATABASE_URL, JWT_SECRET, etc.
npm run dev              # or: npm start
```

The API runs on `http://localhost:3000`.

### 3. Full stack (with OSRM + Nominatim)

```bash
docker compose --profile full up -d
```

> **Note:** OSRM and Nominatim require pre-downloaded map data. See their docs for setup.

---

## API Reference

### Health Check

```
GET /health
```

---

### Auth

#### Register a Company

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name": "FastFood Delivery Co."}'
```

**Response:**
```json
{
  "company_id": "550e8400-e29b-41d4-a716-446655440000",
  "api_key": "a1b2c3d4e5f6...",
  "name": "FastFood Delivery Co.",
  "created_at": "2026-03-30T13:40:00.000Z"
}
```

Save the `api_key` — it's required for all other endpoints.

---

### Locations

All location endpoints require the `X-API-Key` header.

#### Save a Pin

```bash
curl -X POST http://localhost:3000/api/locations \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_API_KEY" \
  -d '{
    "customer_id": "cust_001",
    "lat": 23.8103,
    "lng": 90.4125,
    "address_label": "House 42, Road 7",
    "delivery_notes": "Gate code: 1234, 2nd floor",
    "landmark": "Red mosque next door"
  }'
```

#### Get Customer Location

```bash
curl http://localhost:3000/api/locations/cust_001 \
  -H "X-API-Key: YOUR_API_KEY"
```

#### Find Nearby Locations

```bash
curl "http://localhost:3000/api/locations/nearby?lat=23.81&lng=90.41&radius=500" \
  -H "X-API-Key: YOUR_API_KEY"
```

Returns locations within `radius` meters (default: 500m) sorted by distance.

#### Update a Pin

```bash
curl -X PUT http://localhost:3000/api/locations/LOCATION_ID \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_API_KEY" \
  -d '{"is_verified": true, "delivery_notes": "Updated: Ring doorbell"}'
```

#### Delete a Pin

```bash
curl -X DELETE http://localhost:3000/api/locations/LOCATION_ID \
  -H "X-API-Key: YOUR_API_KEY"
```

---

### Deliveries

#### Start a Delivery

```bash
curl -X POST http://localhost:3000/api/deliveries \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_API_KEY" \
  -d '{
    "delivery_location_id": "LOCATION_ID",
    "driver_id": "driver_042"
  }'
```

#### Update Driver Location

```bash
curl -X PUT http://localhost:3000/api/deliveries/DELIVERY_ID/location \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_API_KEY" \
  -d '{"lat": 23.8105, "lng": 90.4130}'
```

This also emits a `driver:location_update` WebSocket event to all clients tracking this delivery.

#### Update Delivery Status

```bash
curl -X PUT http://localhost:3000/api/deliveries/DELIVERY_ID/status \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_API_KEY" \
  -d '{"status": "delivered", "eta_minutes": 0}'
```

Valid statuses: `assigned`, `en_route`, `arrived`, `delivered`, `cancelled`

#### Get Delivery Info

```bash
curl http://localhost:3000/api/deliveries/DELIVERY_ID \
  -H "X-API-Key: YOUR_API_KEY"
```

---

### Analytics

```bash
curl http://localhost:3000/api/analytics/YOUR_COMPANY_ID \
  -H "X-API-Key: YOUR_API_KEY"
```

Returns:
- `total_deliveries` — completed delivery count
- `avg_time_to_find_minutes` — average time from assignment to completion
- `pin_usage_rate` — proportion of deliveries using saved pins
- `recent_30_days` — daily breakdown
- `active_deliveries` — current delivery counts by status

---

## WebSocket (Real-Time Tracking)

### Connect

```javascript
import { io } from "socket.io-client";

const socket = io("http://localhost:3000", {
  auth: { api_key: "YOUR_API_KEY" }
});

// Join a delivery room
socket.emit("join_delivery", { delivery_id: "DELIVERY_ID" });

// Listen for driver location updates
socket.on("driver:location_update", (data) => {
  console.log(`Driver at ${data.lat}, ${data.lng}`);
});

// Listen for status changes
socket.on("delivery:status_change", (data) => {
  console.log(`Status: ${data.status}`);
});
```

### Events

| Client Sends | Server Emits | Description |
|---|---|---|
| `join_delivery` | `joined_delivery` | Join tracking room |
| `driver_location` | `driver:location_update` | Update & broadcast position |
| `leave_delivery` | — | Leave tracking room |
| — | `delivery:status_change` | Status was updated via REST |
| — | `delivery:eta_update` | ETA recalculated |

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3000` | API server port |
| `DATABASE_URL` | — | PostGIS connection string |
| `OSRM_URL` | `http://localhost:5000` | OSRM routing server |
| `NOMINATIM_URL` | `http://localhost:7070` | Geocoding server |
| `JWT_SECRET` | — | JWT signing key (change in prod!) |

## Project Structure

```
backend/
├── docker-compose.yml
├── .env.example
├── package.json
├── README.md
├── init-db/
│   └── 001-schema.sql
└── src/
    ├── server.js
    ├── db.js
    ├── socket.js
    ├── middleware/
    │   ├── auth.js
    │   └── rateLimiter.js
    └── routes/
        ├── auth.js
        ├── locations.js
        ├── deliveries.js
        └── analytics.js
```

## License

MIT
