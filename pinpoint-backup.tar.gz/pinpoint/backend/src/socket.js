import { query } from './db.js';

/**
 * Set up Socket.io event handlers.
 * @param {import('socket.io').Server} io
 */
export function setupSocket(io) {
  // Auth middleware — verify API key from handshake
  io.use(async (socket, next) => {
    try {
      const apiKey = socket.handshake.auth?.api_key || socket.handshake.headers?.['x-api-key'];

      if (!apiKey) {
        return next(new Error('Authentication error: Missing API key'));
      }

      const result = await query(
        'SELECT id, name, api_key, plan FROM companies WHERE api_key = $1',
        [apiKey]
      );

      if (result.rows.length === 0) {
        return next(new Error('Authentication error: Invalid API key'));
      }

      socket.company = result.rows[0];
      next();
    } catch (err) {
      console.error('Socket auth error:', err.message);
      next(new Error('Authentication error'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`Socket connected: ${socket.id} (company: ${socket.company.name})`);

    /**
     * join_delivery — Join a room to receive real-time updates for a delivery.
     * Payload: { delivery_id }
     */
    socket.on('join_delivery', async (data) => {
      try {
        const { delivery_id } = data;

        if (!delivery_id) {
          socket.emit('error', { message: 'delivery_id is required' });
          return;
        }

        // Verify delivery belongs to this company
        const result = await query(
          'SELECT id FROM active_deliveries WHERE id = $1 AND company_id = $2',
          [delivery_id, socket.company.id]
        );

        if (result.rows.length === 0) {
          socket.emit('error', { message: 'Delivery not found' });
          return;
        }

        const room = `delivery:${delivery_id}`;
        socket.join(room);
        socket.currentDeliveryRoom = room;
        socket.emit('joined_delivery', { delivery_id, room });
        console.log(`Socket ${socket.id} joined room ${room}`);
      } catch (err) {
        console.error('join_delivery error:', err.message);
        socket.emit('error', { message: 'Failed to join delivery room' });
      }
    });

    /**
     * driver_location — Driver updates their current position.
     * Payload: { delivery_id, lat, lng }
     * Broadcasts to the delivery room.
     */
    socket.on('driver_location', async (data) => {
      try {
        const { delivery_id, lat, lng } = data;

        if (!delivery_id || lat == null || lng == null) {
          socket.emit('error', { message: 'delivery_id, lat, and lng are required' });
          return;
        }

        const latNum = parseFloat(lat);
        const lngNum = parseFloat(lng);

        if (isNaN(latNum) || isNaN(lngNum)) {
          socket.emit('error', { message: 'lat and lng must be valid numbers' });
          return;
        }

        // Update in database
        const result = await query(
          `UPDATE active_deliveries
           SET driver_location = ST_SetSRID(ST_MakePoint($3, $4), 4326)::geography
           WHERE id = $1 AND company_id = $2
           RETURNING id, driver_id`,
          [delivery_id, socket.company.id, lngNum, latNum]
        );

        if (result.rows.length === 0) {
          socket.emit('error', { message: 'Delivery not found' });
          return;
        }

        // Broadcast to delivery room
        const room = `delivery:${delivery_id}`;
        io.to(room).emit('driver:location_update', {
          delivery_id,
          driver_id: result.rows[0].driver_id,
          lat: latNum,
          lng: lngNum,
          timestamp: new Date().toISOString(),
        });
      } catch (err) {
        console.error('driver_location error:', err.message);
        socket.emit('error', { message: 'Failed to update driver location' });
      }
    });

    /**
     * leave_delivery — Leave a delivery room.
     * Payload: { delivery_id }
     */
    socket.on('leave_delivery', (data) => {
      const { delivery_id } = data || {};
      if (delivery_id) {
        const room = `delivery:${delivery_id}`;
        socket.leave(room);
        socket.currentDeliveryRoom = null;
        console.log(`Socket ${socket.id} left room ${room}`);
      }
    });

    socket.on('disconnect', (reason) => {
      console.log(`Socket disconnected: ${socket.id} (${reason})`);
    });
  });
}
