import { query } from '../db.js';

/**
 * Validates the X-API-Key header against the companies table.
 * Attaches the company record to req.company on success.
 */
export async function authMiddleware(req, res, next) {
  const apiKey = req.headers['x-api-key'];

  if (!apiKey) {
    return res.status(401).json({ error: 'Missing X-API-Key header' });
  }

  try {
    const result = await query(
      'SELECT id, name, api_key, plan, created_at FROM companies WHERE api_key = $1',
      [apiKey]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid API key' });
    }

    req.company = result.rows[0];
    next();
  } catch (err) {
    console.error('Auth middleware error:', err.message);
    return res.status(500).json({ error: 'Authentication check failed' });
  }
}
