import { Router } from 'express';
import { query } from '../db.js';
import { authMiddleware } from '../middleware/auth.js';
import { apiLimiter } from '../middleware/rateLimiter.js';

const router = Router();

router.use(authMiddleware);
router.use(apiLimiter);

/**
 * GET /api/analytics/:company_id
 * Get delivery statistics for a company.
 * Returns: avg_time_to_find, total_deliveries, pin_usage_rate, recent deliveries
 */
router.get('/:company_id', async (req, res) => {
  try {
    const { company_id } = req.params;

    // Ensure the requesting company matches
    if (company_id !== req.company.id) {
      return res.status(403).json({ error: 'Cannot access another company\'s analytics' });
    }

    // Aggregate stats
    const statsResult = await query(
      `SELECT
         COUNT(*) as total_deliveries,
         AVG(time_to_find_minutes) as avg_time_to_find,
         AVG(CASE WHEN was_pin_used THEN 1 ELSE 0 END) as pin_usage_rate
       FROM delivery_analytics
       WHERE company_id = $1`,
      [company_id]
    );

    // Recent deliveries (last 30 days)
    const recentResult = await query(
      `SELECT
         DATE(created_at) as date,
         COUNT(*) as deliveries,
         AVG(time_to_find_minutes) as avg_time
       FROM delivery_analytics
       WHERE company_id = $1 AND created_at >= NOW() - INTERVAL '30 days'
       GROUP BY DATE(created_at)
       ORDER BY date DESC`,
      [company_id]
    );

    // Current active deliveries
    const activeResult = await query(
      `SELECT status, COUNT(*) as count
       FROM active_deliveries
       WHERE company_id = $1 AND delivered_at IS NULL
       GROUP BY status`,
      [company_id]
    );

    const stats = statsResult.rows[0];

    return res.json({
      company_id,
      total_deliveries: parseInt(stats.total_deliveries, 10) || 0,
      avg_time_to_find_minutes: parseFloat(stats.avg_time_to_find) || 0,
      pin_usage_rate: parseFloat(stats.pin_usage_rate) || 0,
      recent_30_days: recentResult.rows.map((r) => ({
        date: r.date,
        deliveries: parseInt(r.deliveries, 10),
        avg_time: parseFloat(r.avg_time) || 0,
      })),
      active_deliveries: activeResult.rows.map((r) => ({
        status: r.status,
        count: parseInt(r.count, 10),
      })),
    });
  } catch (err) {
    console.error('Analytics error:', err.message);
    return res.status(500).json({ error: 'Failed to get analytics' });
  }
});

export default router;
