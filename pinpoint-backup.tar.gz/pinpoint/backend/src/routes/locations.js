import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../db.js';
import { authMiddleware } from '../middleware/auth.js';
import { apiLimiter } from '../middleware/rateLimiter.js';

const router = Router();

// All location routes require authentication
router.use(authMiddleware);
router.use(apiLimiter);

/**
 * POST /api/locations
 * Save a delivery pin for a customer.
 * Body: { customer_id, lat, lng, address_label, delivery_notes, landmark }
 */
router.post('/', async (req, res) => {
  try {
    const { customer_id, lat, lng, address_label, delivery_notes, landmark } = req.body;

    if (!customer_id || lat == null || lng == null) {
      return res.status(400).json({ error: 'customer_id, lat, and lng are required' });
    }

    const latNum = parseFloat(lat);
    const lngNum = parseFloat(lng);

    if (isNaN(latNum) || isNaN(lngNum)) {
      return res.status(400).json({ error: 'lat and lng must be valid numbers' });
    }

    const id = uuidv4();
    const result = await query(
      `INSERT INTO delivery_locations
         (id, company_id, customer_id, location, address_label, delivery_notes, landmark)
       VALUES ($1, $2, $3, ST_SetSRID(ST_MakePoint($4, $5), 4326)::geography, $6, $7, $8)
       RETURNING id, company_id, customer_id,
                 ST_Y(location::geometry) as lat,
                 ST_X(location::geometry) as lng,
                 plus_code, address_label, delivery_notes, landmark,
                 is_verified, created_at`,
      [id, req.company.id, customer_id, lngNum, latNum,
       address_label || null, delivery_notes || null, landmark || null]
    );

    return res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Create location error:', err.message);
    return res.status(500).json({ error: 'Failed to save location' });
  }
});

/**
 * GET /api/locations/nearby?lat=X&lng=Y&radius=500
 * Find delivery locations within radius (meters) of a point.
 */
router.get('/nearby', async (req, res) => {
  try {
    const { lat, lng, radius } = req.query;

    if (!lat || !lng) {
      return res.status(400).json({ error: 'lat and lng query parameters are required' });
    }

    const latNum = parseFloat(lat);
    const lngNum = parseFloat(lng);
    const radiusNum = parseFloat(radius) || 500;

    if (isNaN(latNum) || isNaN(lngNum)) {
      return res.status(400).json({ error: 'lat and lng must be valid numbers' });
    }

    const result = await query(
      `SELECT id, company_id, customer_id,
              ST_Y(location::geometry) as lat,
              ST_X(location::geometry) as lng,
              plus_code, address_label, delivery_notes, landmark,
              is_verified, created_at, updated_at,
              ST_Distance(location, ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography) as distance_meters
       FROM delivery_locations
       WHERE company_id = $3
         AND ST_DWithin(
           location,
           ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography,
           $4
         )
       ORDER BY distance_meters ASC
       LIMIT 50`,
      [lngNum, latNum, req.company.id, radiusNum]
    );

    return res.json({ locations: result.rows, count: result.rows.length });
  } catch (err) {
    console.error('Nearby search error:', err.message);
    return res.status(500).json({ error: 'Failed to search nearby locations' });
  }
});

/**
 * GET /api/locations/:customer_id
 * Get saved location(s) for a customer.
 */
router.get('/:customer_id', async (req, res) => {
  try {
    const { customer_id } = req.params;

    const result = await query(
      `SELECT id, company_id, customer_id,
              ST_Y(location::geometry) as lat,
              ST_X(location::geometry) as lng,
              plus_code, address_label, delivery_notes, landmark,
              is_verified, created_at, updated_at
       FROM delivery_locations
       WHERE company_id = $1 AND customer_id = $2
       ORDER BY created_at DESC`,
      [req.company.id, customer_id]
    );

    return res.json({ locations: result.rows });
  } catch (err) {
    console.error('Get location error:', err.message);
    return res.status(500).json({ error: 'Failed to get location' });
  }
});

/**
 * PUT /api/locations/:id
 * Update a delivery location.
 * Body: { lat, lng, address_label, delivery_notes, landmark, is_verified }
 */
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { lat, lng, address_label, delivery_notes, landmark, is_verified } = req.body;

    // First verify ownership
    const existing = await query(
      'SELECT id FROM delivery_locations WHERE id = $1 AND company_id = $2',
      [id, req.company.id]
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Location not found' });
    }

    const sets = [];
    const params = [id, req.company.id];
    let paramIdx = 3;

    if (lat != null && lng != null) {
      const latNum = parseFloat(lat);
      const lngNum = parseFloat(lng);
      if (isNaN(latNum) || isNaN(lngNum)) {
        return res.status(400).json({ error: 'lat and lng must be valid numbers' });
      }
      sets.push(`location = ST_SetSRID(ST_MakePoint($${paramIdx}, $${paramIdx + 1}), 4326)::geography`);
      params.push(lngNum, latNum);
      paramIdx += 2;
    }

    if (address_label !== undefined) {
      sets.push(`address_label = $${paramIdx}`);
      params.push(address_label);
      paramIdx++;
    }

    if (delivery_notes !== undefined) {
      sets.push(`delivery_notes = $${paramIdx}`);
      params.push(delivery_notes);
      paramIdx++;
    }

    if (landmark !== undefined) {
      sets.push(`landmark = $${paramIdx}`);
      params.push(landmark);
      paramIdx++;
    }

    if (is_verified !== undefined) {
      sets.push(`is_verified = $${paramIdx}`);
      params.push(is_verified);
      paramIdx++;
    }

    if (sets.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    sets.push('updated_at = NOW()');

    const result = await query(
      `UPDATE delivery_locations
       SET ${sets.join(', ')}
       WHERE id = $1 AND company_id = $2
       RETURNING id, company_id, customer_id,
                 ST_Y(location::geometry) as lat,
                 ST_X(location::geometry) as lng,
                 plus_code, address_label, delivery_notes, landmark,
                 is_verified, created_at, updated_at`,
      params
    );

    return res.json(result.rows[0]);
  } catch (err) {
    console.error('Update location error:', err.message);
    return res.status(500).json({ error: 'Failed to update location' });
  }
});

/**
 * DELETE /api/locations/:id
 * Delete a delivery location.
 */
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await query(
      'DELETE FROM delivery_locations WHERE id = $1 AND company_id = $2 RETURNING id',
      [id, req.company.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Location not found' });
    }

    return res.json({ message: 'Location deleted', id: result.rows[0].id });
  } catch (err) {
    console.error('Delete location error:', err.message);
    return res.status(500).json({ error: 'Failed to delete location' });
  }
});

export default router;
