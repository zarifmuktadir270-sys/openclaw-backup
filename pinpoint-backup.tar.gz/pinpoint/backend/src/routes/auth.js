import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../db.js';
import { apiLimiter } from '../middleware/rateLimiter.js';

const router = Router();

/**
 * POST /api/auth/register
 * Register a new company and generate an API key.
 * Body: { name }
 * Returns: { company_id, api_key, name }
 */
router.post('/register', apiLimiter, async (req, res) => {
  try {
    const { name } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return res.status(400).json({ error: 'Company name is required' });
    }

    const id = uuidv4();
    const apiKey = uuidv4().replace(/-/g, '') + uuidv4().replace(/-/g, '').substring(0, 32);
    // Resulting key is 64 chars (32 + 32)

    const result = await query(
      `INSERT INTO companies (id, name, api_key)
       VALUES ($1, $2, $3)
       RETURNING id, name, api_key, created_at`,
      [id, name.trim(), apiKey]
    );

    const company = result.rows[0];

    return res.status(201).json({
      company_id: company.id,
      api_key: company.api_key,
      name: company.name,
      created_at: company.created_at,
    });
  } catch (err) {
    console.error('Register error:', err.message);
    return res.status(500).json({ error: 'Failed to register company' });
  }
});

export default router;
