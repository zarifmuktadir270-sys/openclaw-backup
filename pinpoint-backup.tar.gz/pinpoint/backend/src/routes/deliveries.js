import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../db.js';
import { authMiddleware } from '../middleware/auth.js';
import { apiLimiter } from '../middleware/rateLimiter.js';

const router = Router();

// All delivery routes require authentication
router.use(authMiddleware);
router.use(apiLimiter);

/**
 * POST /api/deliveries
 * Start a new delivery.
 * Body: { delivery_location_id, driver_id }
 */
router.post('/', async (req, res) => {
  try {
    const { delivery_location_id, driver_id } = req.body;

    if (!delivery_location_id || !driver_id) {
      return res.status(400).json({ error: 'delivery_location_id and driver_id are required' });
    }

    // Verify the delivery location belongs to this company
    const locResult = await query(
      'SELECT id FROM delivery_locations WHERE id = $1 AND company_id = $2',
      [delivery_location_id, req.company.id]
    );

    if (locResult.rows.length === 0) {
      return res.status(404).json({ error: 'Delivery location not found' });
    }

    const id = uuidv4();
    const result = await query(
      `INSERT INTO active_deliveries (id, company_id, delivery_location_id, driver_id)
       VALUES ($1, $2, $3, $4)
       RETURNING id, company_id, delivery_location_id, driver_id,
                 driver_location, status, eta_minutes, started_at, delivered_at`,
      [id, req.company.id, delivery_location_id, driver_id]
    );

    return res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Create delivery error:', err.message);
    return res.status(500).json({ error: 'Failed to create delivery' });
  }
});

/**
 * PUT /api/deliveries/:id/location
 * Update driver's current location during delivery.
 * Body: { lat, lng }
 * Emits: driver:location_update via Socket.io
 */
router.put('/:id/location', async (req, res) => {
  try {
    const { id } = req.params;
    const { lat, lng } = req.body;

    if (lat == null || lng == null) {
      return res.status(400).json({ error: 'lat and lng are required' });
    }

    const latNum = parseFloat(lat);
    const lngNum = parseFloat(lng);

    if (isNaN(latNum) || isNaN(lngNum)) {
      return res.status(400).json({ error: 'lat and lng must be valid numbers' });
    }

    // Verify ownership
    const existing = await query(
      'SELECT id, delivery_location_id FROM active_deliveries WHERE id = $1 AND company_id = $2',
      [id, req.company.id]
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Delivery not found' });
    }

    const result = await query(
      `UPDATE active_deliveries
       SET driver_location = ST_SetSRID(ST_MakePoint($3, $4), 4326)::geography
       WHERE id = $1 AND company_id = $2
       RETURNING id, company_id, delivery_location_id, driver_id,
                 ST_Y(driver_location::geometry) as driver_lat,
                 ST_X(driver_location::geometry) as driver_lng,
                 status, eta_minutes, started_at, delivered_at`,
      [id, req.company.id, lngNum, latNum]
    );

    // Emit socket event for real-time tracking
    const io = req.app.get('io');
    io.to(`delivery:${id}`).emit('driver:location_update', {
      delivery_id: id,
      driver_id: result.rows[0].driver_id,
      lat: latNum,
      lng: lngNum,
      timestamp: new Date().toISOString(),
    });

    return res.json(result.rows[0]);
  } catch (err) {
    console.error('Update driver location error:', err.message);
    return res.status(500).json({ error: 'Failed to update driver location' });
  }
});

/**
 * PUT /api/deliveries/:id/status
 * Update delivery status.
 * Body: { status, eta_minutes? }
 * Valid statuses: assigned, en_route, arrived, delivered, cancelled
 * Emits: delivery:status_change via Socket.io
 */
router.put('/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, eta_minutes } = req.body;

    const validStatuses = ['assigned', 'en_route', 'arrived', 'delivered', 'cancelled'];
    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({
        error: `status is required and must be one of: ${validStatuses.join(', ')}`,
      });
    }

    // Verify ownership
    const existing = await query(
      'SELECT id, status as current_status FROM active_deliveries WHERE id = $1 AND company_id = $2',
      [id, req.company.id]
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Delivery not found' });
    }

    const sets = ['status = $3'];
    const params = [id, req.company.id, status];
    let paramIdx = 4;

    if (eta_minutes != null) {
      sets.push(`eta_minutes = $${paramIdx}`);
      params.push(parseInt(eta_minutes, 10));
      paramIdx++;
    }

    if (status === 'delivered' || status === 'cancelled') {
      sets.push('delivered_at = NOW()');
    }

    const result = await query(
      `UPDATE active_deliveries
       SET ${sets.join(', ')}
       WHERE id = $1 AND company_id = $2
       RETURNING id, company_id, delivery_location_id, driver_id,
                 status, eta_minutes, started_at, delivered_at`,
      params
    );

    // Insert analytics on delivery completion
    if (status === 'delivered') {
      const delivery = result.rows[0];
      const startedAt = new Date(delivery.started_at);
      const now = new Date();
      const timeToFindMinutes = (now - startedAt) / 60000;

      await query(
        `INSERT INTO delivery_analytics
           (company_id, delivery_id, time_to_find_minutes, was_pin_used)
         VALUES ($1, $2, $3, $4)`,
        [req.company.id, id, timeToFindMinutes, true]
      );
    }

    // Emit socket event
    const io = req.app.get('io');
    io.to(`delivery:${id}`).emit('delivery:status_change', {
      delivery_id: id,
      previous_status: existing.rows[0].current_status,
      status,
      eta_minutes: eta_minutes ? parseInt(eta_minutes, 10) : null,
      timestamp: new Date().toISOString(),
    });

    return res.json(result.rows[0]);
  } catch (err) {
    console.error('Update delivery status error:', err.message);
    return res.status(500).json({ error: 'Failed to update delivery status' });
  }
});

/**
 * GET /api/deliveries/:id
 * Get delivery info including ETA.
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await query(
      `SELECT d.id, d.company_id, d.delivery_location_id, d.driver_id,
              ST_Y(d.driver_location::geometry) as driver_lat,
              ST_X(d.driver_location::geometry) as driver_lng,
              d.status, d.eta_minutes, d.started_at, d.delivered_at,
              ST_Y(dl.location::geometry) as dest_lat,
              ST_X(dl.location::geometry) as dest_lng,
              dl.address_label, dl.delivery_notes, dl.landmark
       FROM active_deliveries d
       JOIN delivery_locations dl ON d.delivery_location_id = dl.id
       WHERE d.id = $1 AND d.company_id = $2`,
      [id, req.company.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Delivery not found' });
    }

    return res.json(result.rows[0]);
  } catch (err) {
    console.error('Get delivery error:', err.message);
    return res.status(500).json({ error: 'Failed to get delivery' });
  }
});

export default router;
