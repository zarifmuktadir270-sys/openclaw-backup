enum DeliveryStatus {
  assigned,
  enRoute,
  arrived,
  delivered;

  String get label {
    switch (this) {
      case DeliveryStatus.assigned:
        return 'Assigned';
      case DeliveryStatus.enRoute:
        return 'En Route';
      case DeliveryStatus.arrived:
        return 'Arrived';
      case DeliveryStatus.delivered:
        return 'Delivered';
    }
  }

  static DeliveryStatus fromString(String value) {
    switch (value.toLowerCase()) {
      case 'assigned':
        return DeliveryStatus.assigned;
      case 'en_route':
      case 'enroute':
      case 'en route':
        return DeliveryStatus.enRoute;
      case 'arrived':
        return DeliveryStatus.arrived;
      case 'delivered':
        return DeliveryStatus.delivered;
      default:
        return DeliveryStatus.assigned;
    }
  }
}

class ActiveDelivery {
  final String id;
  final String? locationId;
  final String? driverId;
  final double driverLat;
  final double driverLng;
  final double? customerLat;
  final double? customerLng;
  final DeliveryStatus status;
  final int etaMinutes;
  final DateTime? startedAt;
  final DateTime? updatedAt;

  const ActiveDelivery({
    required this.id,
    this.locationId,
    this.driverId,
    required this.driverLat,
    required this.driverLng,
    this.customerLat,
    this.customerLng,
    this.status = DeliveryStatus.assigned,
    this.etaMinutes = 0,
    this.startedAt,
    this.updatedAt,
  });

  factory ActiveDelivery.fromJson(Map<String, dynamic> json) {
    return ActiveDelivery(
      id: json['id'] as String,
      locationId: json['locationId'] as String?,
      driverId: json['driverId'] as String?,
      driverLat: (json['driverLat'] as num).toDouble(),
      driverLng: (json['driverLng'] as num).toDouble(),
      customerLat: json['customerLat'] != null
          ? (json['customerLat'] as num).toDouble()
          : null,
      customerLng: json['customerLng'] != null
          ? (json['customerLng'] as num).toDouble()
          : null,
      status: DeliveryStatus.fromString(json['status'] as String? ?? 'assigned'),
      etaMinutes: (json['etaMinutes'] as num?)?.toInt() ?? 0,
      startedAt: json['startedAt'] != null
          ? DateTime.parse(json['startedAt'] as String)
          : null,
      updatedAt: json['updatedAt'] != null
          ? DateTime.parse(json['updatedAt'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      if (locationId != null) 'locationId': locationId,
      if (driverId != null) 'driverId': driverId,
      'driverLat': driverLat,
      'driverLng': driverLng,
      if (customerLat != null) 'customerLat': customerLat,
      if (customerLng != null) 'customerLng': customerLng,
      'status': status.name,
      'etaMinutes': etaMinutes,
      if (startedAt != null) 'startedAt': startedAt!.toIso8601String(),
      if (updatedAt != null) 'updatedAt': updatedAt!.toIso8601String(),
    };
  }

  ActiveDelivery copyWith({
    String? id,
    String? locationId,
    String? driverId,
    double? driverLat,
    double? driverLng,
    double? customerLat,
    double? customerLng,
    DeliveryStatus? status,
    int? etaMinutes,
    DateTime? startedAt,
    DateTime? updatedAt,
  }) {
    return ActiveDelivery(
      id: id ?? this.id,
      locationId: locationId ?? this.locationId,
      driverId: driverId ?? this.driverId,
      driverLat: driverLat ?? this.driverLat,
      driverLng: driverLng ?? this.driverLng,
      customerLat: customerLat ?? this.customerLat,
      customerLng: customerLng ?? this.customerLng,
      status: status ?? this.status,
      etaMinutes: etaMinutes ?? this.etaMinutes,
      startedAt: startedAt ?? this.startedAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'ActiveDelivery(id: $id, status: ${status.label}, eta: ${etaMinutes}min)';
  }
}
