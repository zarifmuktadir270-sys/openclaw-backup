class DeliveryLocation {
  final String id;
  final double lat;
  final double lng;
  final String? plusCode;
  final String? addressLabel;
  final String? deliveryNotes;
  final String? landmark;
  final bool isVerified;
  final DateTime? createdAt;

  const DeliveryLocation({
    required this.id,
    required this.lat,
    required this.lng,
    this.plusCode,
    this.addressLabel,
    this.deliveryNotes,
    this.landmark,
    this.isVerified = false,
    this.createdAt,
  });

  factory DeliveryLocation.fromJson(Map<String, dynamic> json) {
    return DeliveryLocation(
      id: json['id'] as String,
      lat: (json['lat'] as num).toDouble(),
      lng: (json['lng'] as num).toDouble(),
      plusCode: json['plusCode'] as String?,
      addressLabel: json['addressLabel'] as String?,
      deliveryNotes: json['deliveryNotes'] as String?,
      landmark: json['landmark'] as String?,
      isVerified: json['isVerified'] as bool? ?? false,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'lat': lat,
      'lng': lng,
      if (plusCode != null) 'plusCode': plusCode,
      if (addressLabel != null) 'addressLabel': addressLabel,
      if (deliveryNotes != null) 'deliveryNotes': deliveryNotes,
      if (landmark != null) 'landmark': landmark,
      'isVerified': isVerified,
      if (createdAt != null) 'createdAt': createdAt!.toIso8601String(),
    };
  }

  DeliveryLocation copyWith({
    String? id,
    double? lat,
    double? lng,
    String? plusCode,
    String? addressLabel,
    String? deliveryNotes,
    String? landmark,
    bool? isVerified,
    DateTime? createdAt,
  }) {
    return DeliveryLocation(
      id: id ?? this.id,
      lat: lat ?? this.lat,
      lng: lng ?? this.lng,
      plusCode: plusCode ?? this.plusCode,
      addressLabel: addressLabel ?? this.addressLabel,
      deliveryNotes: deliveryNotes ?? this.deliveryNotes,
      landmark: landmark ?? this.landmark,
      isVerified: isVerified ?? this.isVerified,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  String toString() {
    return 'DeliveryLocation(id: $id, lat: $lat, lng: $lng, label: $addressLabel)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is DeliveryLocation && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
