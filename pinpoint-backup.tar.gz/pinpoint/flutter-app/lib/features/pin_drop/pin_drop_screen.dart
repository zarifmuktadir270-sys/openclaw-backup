import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:geolocator/geolocator.dart';
import 'package:pinpoint_customer/core/constants/api_constants.dart';
import 'package:pinpoint_customer/core/theme/app_theme.dart';
import 'package:pinpoint_customer/services/location_service.dart';
import 'package:pinpoint_customer/services/api_service.dart';
import 'package:pinpoint_customer/features/pin_drop/widgets/confirm_location_sheet.dart';

class PinDropScreen extends ConsumerStatefulWidget {
  const PinDropScreen({super.key});

  @override
  ConsumerState<PinDropScreen> createState() => _PinDropScreenState();
}

class _PinDropScreenState extends ConsumerState<PinDropScreen> {
  MapLibreMapController? _mapController;
  String _currentAddress = 'Move the map to select location...';
  bool _isLoadingAddress = false;
  bool _isSatellite = false;
  bool _isSaving = false;
  double _selectedLat = 0;
  double _selectedLng = 0;

  // Default center: Dhaka, Bangladesh
  static const _defaultLat = 23.8103;
  static const _defaultLng = 90.4125;

  @override
  void initState() {
    super.initState();
    _selectedLat = _defaultLat;
    _selectedLng = _defaultLng;
    _initLocation();
  }

  Future<void> _initLocation() async {
    final locationService = ref.read(locationServiceProvider);
    final hasPermission = await locationService.requestPermission();
    if (hasPermission) {
      try {
        final position = await locationService.getCurrentPosition();
        setState(() {
          _selectedLat = position.latitude;
          _selectedLng = position.longitude;
        });
        _mapController?.animateCamera(
          CameraUpdate.newLatLngZoom(
            LatLng(position.latitude, position.longitude),
            16,
          ),
        );
        _reverseGeocode(position.latitude, position.longitude);
      } catch (e) {
        print('[PinDropScreen] Could not get position: $e');
      }
    }
  }

  Future<void> _reverseGeocode(double lat, double lng) async {
    setState(() => _isLoadingAddress = true);
    final locationService = ref.read(locationServiceProvider);
    final address = await locationService.reverseGeocode(lat, lng);
    if (mounted) {
      setState(() {
        _currentAddress = address;
        _isLoadingAddress = false;
      });
    }
  }

  void _onMapCreated(MapLibreMapController controller) {
    _mapController = controller;
  }

  void _onCameraMove(CameraPosition position) {
    setState(() {
      _selectedLat = position.target.latitude;
      _selectedLng = position.target.longitude;
    });
  }

  void _onCameraIdle() {
    _reverseGeocode(_selectedLat, _selectedLng);
  }

  void _toggleSatellite() {
    // OSM doesn't have a satellite layer, so we toggle between standard
    // and a different tile style. For a real app, you'd swap tile sources.
    setState(() => _isSatellite = !_isSatellite);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _isSatellite
              ? 'Satellite view not available with OSM tiles'
              : 'Standard map view',
        ),
        duration: const Duration(seconds: 2),
      ),
    );
    if (_isSatellite) setState(() => _isSatellite = false);
  }

  void _confirmLocation() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => ConfirmLocationSheet(
        address: _currentAddress,
        lat: _selectedLat,
        lng: _selectedLng,
        onSave: _saveLocation,
        isLoading: _isSaving,
      ),
    );
  }

  Future<void> _saveLocation({
    required double lat,
    required double lng,
    required String notes,
    required String landmark,
  }) async {
    setState(() => _isSaving = true);
    try {
      final api = ref.read(apiServiceProvider);
      await api.saveLocation(
        lat: lat,
        lng: lng,
        notes: notes,
        landmark: landmark,
        addressLabel: _currentAddress,
      );

      if (mounted) {
        Navigator.pop(context); // Close bottom sheet
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Location saved successfully!'),
            backgroundColor: AppTheme.secondaryColor,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to save: ${e.toString()}'),
            backgroundColor: AppTheme.errorColor,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Full screen MapLibre map
          MapLibreMap(
            styleString: jsonEncode(ApiConstants.osmStyleJson),
            initialCameraPosition: CameraPosition(
              target: LatLng(_selectedLat, _selectedLng),
              zoom: 16,
            ),
            onMapCreated: _onMapCreated,
            onCameraMove: _onCameraMove,
            onCameraIdle: _onCameraIdle,
            myLocationEnabled: false,
            compassEnabled: true,
            zoomGesturesEnabled: true,
            scrollGesturesEnabled: true,
            tiltGesturesEnabled: true,
            rotateGesturesEnabled: true,
          ),

          // Fixed pin in center of screen
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.location_on,
                  color: AppTheme.primaryColor,
                  size: 48,
                  shadows: const [
                    Shadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2)),
                  ],
                ),
                const SizedBox(height: 48), // Offset pin tip from center
              ],
            ),
          ),

          // Floating address bar at top
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      const Icon(Icons.place, color: AppTheme.primaryColor, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _isLoadingAddress
                            ? const Row(
                                children: [
                                  SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(strokeWidth: 2),
                                  ),
                                  SizedBox(width: 12),
                                  Text('Finding address...'),
                                ],
                              )
                            : Text(
                                _currentAddress,
                                style: const TextStyle(fontSize: 14),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Satellite toggle button (top right)
          Positioned(
            top: MediaQuery.of(context).padding.top + 70,
            right: 16,
            child: FloatingActionButton.small(
              heroTag: 'satellite_toggle',
              onPressed: _toggleSatellite,
              backgroundColor: Colors.white,
              foregroundColor: Colors.black87,
              child: Icon(
                _isSatellite ? Icons.map : Icons.satellite_alt,
              ),
            ),
          ),

          // My location button
          Positioned(
            top: MediaQuery.of(context).padding.top + 120,
            right: 16,
            child: FloatingActionButton.small(
              heroTag: 'my_location',
              onPressed: _initLocation,
              backgroundColor: Colors.white,
              foregroundColor: Colors.black87,
              child: const Icon(Icons.my_location),
            ),
          ),

          // Confirm Location button at bottom
          Positioned(
            left: 16,
            right: 16,
            bottom: MediaQuery.of(context).padding.bottom + 16,
            child: SafeArea(
              child: SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: _confirmLocation,
                  icon: const Icon(Icons.check_circle_outline),
                  label: const Text('Confirm Location'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    elevation: 4,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
