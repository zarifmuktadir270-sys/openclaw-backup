import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:pinpoint_customer/core/constants/api_constants.dart';
import 'package:pinpoint_customer/core/theme/app_theme.dart';
import 'package:pinpoint_customer/models/active_delivery.dart';
import 'package:pinpoint_customer/services/api_service.dart';
import 'package:pinpoint_customer/services/socket_service.dart';

class TrackingScreen extends ConsumerStatefulWidget {
  const TrackingScreen({super.key});

  @override
  ConsumerState<TrackingScreen> createState() => _TrackingScreenState();
}

class _TrackingScreenState extends ConsumerState<TrackingScreen> {
  MapLibreMapController? _mapController;
  ActiveDelivery? _activeDelivery;
  bool _isLoading = true;
  String? _error;
  String? _deliveryIdController;
  final _deliveryIdFieldController = TextEditingController();
  StreamSubscription<SocketEvent>? _socketSub;

  // Default: Dhaka
  static const _defaultLat = 23.8103;
  static const _defaultLng = 90.4125;

  @override
  void initState() {
    super.initState();
    _setupSocketListener();
  }

  void _setupSocketListener() {
    final socketService = ref.read(socketServiceProvider);
    socketService.connect();
    _socketSub = socketService.events.listen(_handleSocketEvent);
  }

  void _handleSocketEvent(SocketEvent event) {
    if (!mounted) return;

    switch (event.type) {
      case SocketEventType.driverLocationUpdate:
        if (_activeDelivery != null && event.data != null) {
          final lat = (event.data!['driverLat'] as num?)?.toDouble();
          final lng = (event.data!['driverLng'] as num?)?.toDouble();
          if (lat != null && lng != null) {
            setState(() {
              _activeDelivery = _activeDelivery!.copyWith(
                driverLat: lat,
                driverLng: lng,
              );
            });
            _updateDriverMarker(lat, lng);
          }
        }
        break;

      case SocketEventType.etaUpdate:
        if (_activeDelivery != null && event.data != null) {
          final eta = (event.data!['etaMinutes'] as num?)?.toInt();
          if (eta != null) {
            setState(() {
              _activeDelivery = _activeDelivery!.copyWith(etaMinutes: eta);
            });
          }
        }
        break;

      case SocketEventType.statusChange:
        if (_activeDelivery != null && event.data != null) {
          final statusStr = event.data!['status'] as String?;
          if (statusStr != null) {
            setState(() {
              _activeDelivery = _activeDelivery!.copyWith(
                status: DeliveryStatus.fromString(statusStr),
              );
            });
            _updatePolylines();
          }
        }
        break;

      default:
        break;
    }
  }

  void _updateDriverMarker(double lat, double lng) async {
    if (_mapController == null) return;
    // Animate camera to show both points
    if (_activeDelivery?.customerLat != null &&
        _activeDelivery?.customerLng != null) {
      _fitBounds();
    }
  }

  void _fitBounds() {
    if (_mapController == null || _activeDelivery == null) return;
    final d = _activeDelivery!;
    if (d.customerLat == null || d.customerLng == null) return;

    final sw = LatLng(
      [d.driverLat, d.customerLat!].reduce((a, b) => a < b ? a : b),
      [d.driverLng, d.customerLng!].reduce((a, b) => a < b ? a : b),
    );
    final ne = LatLng(
      [d.driverLat, d.customerLat!].reduce((a, b) => a > b ? a : b),
      [d.driverLng, d.customerLng!].reduce((a, b) => a > b ? a : b),
    );

    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(southwest: sw, northeast: ne),
        left: 40,
        right: 40,
        top: 100,
        bottom: 200,
      ),
    );
  }

  void _updatePolylines() {
    if (_mapController == null || _activeDelivery == null) return;
    // Polylines require the line layer - we skip complex polyline
    // implementation and just rely on camera fitting
    _fitBounds();
  }

  void _loadDelivery(String deliveryId) async {
    setState(() {
      _isLoading = true;
      _error = null;
      _deliveryIdController = deliveryId;
    });

    try {
      final api = ref.read(apiServiceProvider);
      final delivery = await api.getDeliveryStatus(deliveryId);

      setState(() {
        _activeDelivery = delivery;
        _isLoading = false;
      });

      // Join socket room for this delivery
      final socketService = ref.read(socketServiceProvider);
      socketService.joinDeliveryRoom(deliveryId);

      // Fit map to show both markers
      _fitBounds();
    } catch (e) {
      setState(() {
        _error = 'Could not load delivery: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _socketSub?.cancel();
    _deliveryIdFieldController.dispose();
    // Leave socket room
    if (_deliveryIdController != null) {
      ref.read(socketServiceProvider).leaveDeliveryRoom(_deliveryIdController!);
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Track Delivery'),
        actions: [
          if (_activeDelivery != null)
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: () => _loadDelivery(_deliveryIdController!),
            ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    // Show delivery ID input if no active delivery
    if (_activeDelivery == null && !_isLoading) {
      return _buildDeliveryIdInput();
    }

    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48, color: AppTheme.errorColor),
              const SizedBox(height: 16),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => setState(() {
                  _error = null;
                  _activeDelivery = null;
                }),
                child: const Text('Try Again'),
              ),
            ],
          ),
        ),
      );
    }

    final delivery = _activeDelivery!;
    return Stack(
      children: [
        // Map with markers
        MapLibreMap(
          styleString: jsonEncode(ApiConstants.osmStyleJson),
          initialCameraPosition: CameraPosition(
            target: LatLng(delivery.driverLat, delivery.driverLng),
            zoom: 14,
          ),
          onMapCreated: (controller) {
            _mapController = controller;
            _addMarkers();
          },
          myLocationEnabled: false,
          compassEnabled: true,
        ),

        // ETA Badge (top right)
        Positioned(
          top: MediaQuery.of(context).padding.top + 16,
          right: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor,
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [
                BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(0, 2)),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.timer, color: Colors.white, size: 18),
                const SizedBox(width: 6),
                Text(
                  delivery.etaMinutes > 0 ? '${delivery.etaMinutes} min' : 'Calculating...',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ),

        // Status card at bottom
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: _buildStatusCard(delivery),
        ),
      ],
    );
  }

  Widget _buildDeliveryIdInput() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.delivery_dining,
            size: 64,
            color: AppTheme.primaryColor,
          ),
          const SizedBox(height: 24),
          const Text(
            'Track Your Delivery',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'Enter your delivery ID to start tracking',
            style: TextStyle(color: Colors.grey.shade600),
          ),
          const SizedBox(height: 32),
          TextField(
            controller: _deliveryIdFieldController,
            decoration: const InputDecoration(
              labelText: 'Delivery ID',
              hintText: 'e.g., DEL-20240101-ABC123',
              prefixIcon: Icon(Icons.confirmation_number),
            ),
            textCapitalization: TextCapitalization.characters,
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: () {
                final id = _deliveryIdFieldController.text.trim();
                if (id.isNotEmpty) _loadDelivery(id);
              },
              child: const Text('Track'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard(ActiveDelivery delivery) {
    final statuses = DeliveryStatus.values;
    final currentIndex = statuses.indexOf(delivery.status);

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 12, offset: Offset(0, -2)),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Status progress bar
          Row(
            children: List.generate(statuses.length, (index) {
              final isActive = index <= currentIndex;
              final isCurrent = index == currentIndex;
              return Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(
                          color: isActive
                              ? AppTheme.primaryColor
                              : Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    if (index < statuses.length - 1) const SizedBox(width: 4),
                  ],
                ),
              );
            }),
          ),
          const SizedBox(height: 12),

          // Status labels
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: statuses.map((s) {
              final isActive = statuses.indexOf(s) <= currentIndex;
              final isCurrent = s == delivery.status;
              return Text(
                s.label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
                  color: isActive ? AppTheme.primaryColor : Colors.grey.shade400,
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),

          // Current status
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  _getStatusIcon(delivery.status),
                  color: AppTheme.primaryColor,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      delivery.status.label,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      _getStatusDescription(delivery.status),
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              // ETA
              Column(
                children: [
                  Text(
                    '${delivery.etaMinutes}',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                  const Text(
                    'min',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  IconData _getStatusIcon(DeliveryStatus status) {
    switch (status) {
      case DeliveryStatus.assigned:
        return Icons.assignment_ind;
      case DeliveryStatus.enRoute:
        return Icons.directions;
      case DeliveryStatus.arrived:
        return Icons.location_on;
      case DeliveryStatus.delivered:
        return Icons.check_circle;
    }
  }

  String _getStatusDescription(DeliveryStatus status) {
    switch (status) {
      case DeliveryStatus.assigned:
        return 'A driver has been assigned to your delivery';
      case DeliveryStatus.enRoute:
        return 'Your driver is on the way';
      case DeliveryStatus.arrived:
        return 'Your driver has arrived at the location';
      case DeliveryStatus.delivered:
        return 'Your delivery is complete';
    }
  }

  void _addMarkers() async {
    if (_mapController == null || _activeDelivery == null) return;
    final d = _activeDelivery!;

    // Add customer marker
    if (d.customerLat != null && d.customerLng != null) {
      await _mapController!.addSymbol(
        SymbolOptions(
          geometry: LatLng(d.customerLat!, d.customerLng!),
          iconImage: 'marker-15',
          iconSize: 2.0,
          iconColor: '#2563EB',
          textField: 'Delivery',
          textSize: 12,
          textOffset: const Offset(0, 1.5),
        ),
      );
    }

    // Add driver marker
    await _mapController!.addSymbol(
      SymbolOptions(
        geometry: LatLng(d.driverLat, d.driverLng),
        iconImage: 'marker-15',
        iconSize: 2.0,
        iconColor: '#10B981',
        textField: 'Driver',
        textSize: 12,
        textOffset: const Offset(0, 1.5),
      ),
    );
  }
}
