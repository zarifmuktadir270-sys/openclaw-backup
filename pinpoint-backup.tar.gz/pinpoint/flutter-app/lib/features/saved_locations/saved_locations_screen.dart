import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pinpoint_customer/core/theme/app_theme.dart';
import 'package:pinpoint_customer/models/delivery_location.dart';
import 'package:pinpoint_customer/services/api_service.dart';

final savedLocationsProvider =
    StateNotifierProvider<SavedLocationsNotifier, AsyncValue<List<DeliveryLocation>>>(
  (ref) => SavedLocationsNotifier(ref.read(apiServiceProvider)),
);

class SavedLocationsNotifier
    extends StateNotifier<AsyncValue<List<DeliveryLocation>>> {
  final ApiService _api;

  SavedLocationsNotifier(this._api) : super(const AsyncValue.loading());

  Future<void> fetchLocations(String customerId) async {
    state = const AsyncValue.loading();
    try {
      final locations = await _api.getLocations(customerId);
      state = AsyncValue.data(locations);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> deleteLocation(String locationId) async {
    try {
      await _api.deleteLocation(locationId);
      state.whenData((locations) {
        state = AsyncValue.data(
          locations.where((l) => l.id != locationId).toList(),
        );
      });
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}

class SavedLocationsScreen extends ConsumerStatefulWidget {
  const SavedLocationsScreen({super.key});

  @override
  ConsumerState<SavedLocationsScreen> createState() =>
      _SavedLocationsScreenState();
}

class _SavedLocationsScreenState extends ConsumerState<SavedLocationsScreen> {
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      _initialized = true;
      // Fetch with a placeholder customer ID; in production, use auth
      ref.read(savedLocationsProvider.notifier).fetchLocations('current-user');
    }
  }

  @override
  Widget build(BuildContext context) {
    final locationsAsync = ref.watch(savedLocationsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Saved Locations'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              ref
                  .read(savedLocationsProvider.notifier)
                  .fetchLocations('current-user');
            },
          ),
        ],
      ),
      body: locationsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline,
                    size: 48, color: AppTheme.errorColor),
                const SizedBox(height: 16),
                Text(
                  'Failed to load locations',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  error.toString(),
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => ref
                      .read(savedLocationsProvider.notifier)
                      .fetchLocations('current-user'),
                  icon: const Icon(Icons.refresh),
                  label: const Text('Retry'),
                ),
              ],
            ),
          ),
        ),
        data: (locations) {
          if (locations.isEmpty) {
            return _buildEmptyState();
          }
          return RefreshIndicator(
            onRefresh: () => ref
                .read(savedLocationsProvider.notifier)
                .fetchLocations('current-user'),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: locations.length,
              itemBuilder: (context, index) {
                final location = locations[index];
                return _buildLocationTile(location);
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.bookmark_border,
              size: 72,
              color: Colors.grey.shade300,
            ),
            const SizedBox(height: 16),
            Text(
              'No saved locations yet',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Pin a location on the map and save it to see it here',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade400,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationTile(DeliveryLocation location) {
    return Dismissible(
      key: Key(location.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        color: AppTheme.errorColor,
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (direction) async {
        return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Delete Location'),
            content: const Text(
                'Are you sure you want to delete this saved location?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                style: TextButton.styleFrom(foregroundColor: AppTheme.errorColor),
                child: const Text('Delete'),
              ),
            ],
          ),
        );
      },
      onDismissed: (_) {
        ref.read(savedLocationsProvider.notifier).deleteLocation(location.id);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Location deleted')),
        );
      },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.location_on,
              color: AppTheme.primaryColor,
              size: 24,
            ),
          ),
          title: Text(
            location.addressLabel ?? 'Unnamed Location',
            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 4),
              Text(
                '${location.lat.toStringAsFixed(4)}, ${location.lng.toStringAsFixed(4)}',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
              ),
              if (location.deliveryNotes != null &&
                  location.deliveryNotes!.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(
                  '📝 ${location.deliveryNotes}',
                  style: const TextStyle(fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
              if (location.landmark != null &&
                  location.landmark!.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(
                  '📍 ${location.landmark}',
                  style: const TextStyle(fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
          trailing: location.isVerified
              ? const Icon(Icons.verified, color: AppTheme.secondaryColor, size: 20)
              : null,
          onTap: () {
            // Return selected location
            Navigator.pop(context, location);
          },
        ),
      ),
    );
  }
}
