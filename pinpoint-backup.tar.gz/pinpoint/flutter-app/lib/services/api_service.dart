import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pinpoint_customer/core/constants/api_constants.dart';
import 'package:pinpoint_customer/models/delivery_location.dart';
import 'package:pinpoint_customer/models/active_delivery.dart';

class ApiService {
  late final Dio _dio;

  ApiService() {
    _dio = Dio(BaseOptions(
      baseUrl: ApiConstants.baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {'Content-Type': 'application/json'},
    ));

    // Logging interceptor for debugging
    _dio.interceptors.add(LogInterceptor(
      requestBody: true,
      responseBody: true,
      logPrint: (obj) => print('[ApiService] $obj'),
    ));
  }

  /// Save a delivery location.
  Future<DeliveryLocation> saveLocation({
    required double lat,
    required double lng,
    String? notes,
    String? landmark,
    String? addressLabel,
  }) async {
    final response = await _dio.post(
      ApiConstants.saveLocation,
      data: {
        'lat': lat,
        'lng': lng,
        if (notes != null && notes.isNotEmpty) 'deliveryNotes': notes,
        if (landmark != null && landmark.isNotEmpty) 'landmark': landmark,
        if (addressLabel != null && addressLabel.isNotEmpty)
          'addressLabel': addressLabel,
      },
    );
    return DeliveryLocation.fromJson(response.data as Map<String, dynamic>);
  }

  /// Get a saved location by ID.
  Future<DeliveryLocation> getLocation(String locationId) async {
    final response = await _dio.get(
      '${ApiConstants.getLocation}/$locationId',
    );
    return DeliveryLocation.fromJson(response.data as Map<String, dynamic>);
  }

  /// Get all saved locations for a customer.
  Future<List<DeliveryLocation>> getLocations(String customerId) async {
    final response = await _dio.get(
      ApiConstants.saveLocation,
      queryParameters: {'customerId': customerId},
    );
    final list = response.data as List<dynamic>;
    return list
        .map((json) =>
            DeliveryLocation.fromJson(json as Map<String, dynamic>))
        .toList();
  }

  /// Start a delivery for a given location.
  Future<ActiveDelivery> startDelivery({
    required String locationId,
    required String driverId,
  }) async {
    final response = await _dio.post(
      ApiConstants.startDelivery,
      data: {
        'locationId': locationId,
        'driverId': driverId,
      },
    );
    return ActiveDelivery.fromJson(response.data as Map<String, dynamic>);
  }

  /// Update driver's current position for a delivery.
  Future<void> updateDriverLocation({
    required String deliveryId,
    required double lat,
    required double lng,
  }) async {
    await _dio.put(
      '${ApiConstants.updateDriverLocation}/$deliveryId/location',
      data: {
        'driverLat': lat,
        'driverLng': lng,
      },
    );
  }

  /// Get current delivery status.
  Future<ActiveDelivery> getDeliveryStatus(String deliveryId) async {
    final response = await _dio.get(
      '${ApiConstants.getDeliveryStatus}/$deliveryId',
    );
    return ActiveDelivery.fromJson(response.data as Map<String, dynamic>);
  }

  /// Reverse geocode coordinates.
  Future<Map<String, dynamic>?> reverseGeocode(
      double lat, double lng) async {
    try {
      final response = await _dio.get(
        ApiConstants.reverseGeocode,
        queryParameters: {'lat': lat, 'lng': lng},
      );
      return response.data as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  /// Delete a saved location.
  Future<void> deleteLocation(String locationId) async {
    await _dio.delete('${ApiConstants.saveLocation}/$locationId');
  }
}

// Provider
final apiServiceProvider = Provider<ApiService>((ref) => ApiService());
