import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'package:pinpoint_customer/services/api_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class LocationService {
  final ApiService _api;

  LocationService(this._api);

  /// Request location permissions. Returns true if granted.
  Future<bool> requestPermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled
      return false;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return false;
    }

    return true;
  }

  /// Get the current device position with high accuracy.
  Future<Position> getCurrentPosition() async {
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
      timeLimit: const Duration(seconds: 15),
    );
  }

  /// Stream position updates at the given interval.
  Stream<Position> getPositionStream({
    int distanceFilterMeters = 10,
    int intervalMs = 5000,
  }) {
    return Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: distanceFilterMeters,
        timeLimit: const Duration(seconds: 10),
      ),
    );
  }

  /// Reverse geocode coordinates to an address string via backend.
  /// Falls back to "Lat, Lng" format if the API call fails.
  Future<String> reverseGeocode(double lat, double lng) async {
    try {
      final response = await _api.reverseGeocode(lat, lng);
      if (response != null && response['address'] != null) {
        return response['address'] as String;
      }
    } catch (_) {}
    return '${lat.toStringAsFixed(6)}, ${lng.toStringAsFixed(6)}';
  }

  /// Calculate distance between two points in meters.
  double distanceBetween(
    double startLat,
    double startLng,
    double endLat,
    double endLng,
  ) {
    return Geolocator.distanceBetween(startLat, startLng, endLat, endLng);
  }

  /// Open device location settings.
  Future<void> openLocationSettings() async {
    await Geolocator.openLocationSettings();
  }

  /// Open app settings for permission changes.
  Future<void> openAppSettings() async {
    await Geolocator.openAppSettings();
  }
}

// Provider
final locationServiceProvider = Provider<LocationService>((ref) {
  final api = ref.watch(apiServiceProvider);
  return LocationService(api);
});
