import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:pinpoint_customer/core/constants/api_constants.dart';

class SocketService {
  io.Socket? _socket;
  final _socketController = StreamController<SocketEvent>.broadcast();

  Stream<SocketEvent> get events => _socketController.stream;

  bool get isConnected => _socket?.connected ?? false;

  /// Connect to the Socket.IO server.
  void connect() {
    if (_socket != null && _socket!.connected) return;

    _socket = io.io(ApiConstants.socketUrl, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false,
      'reconnection': true,
      'reconnectionAttempts': 10,
      'reconnectionDelay': 2000,
    });

    _socket!.onConnect((_) {
      print('[SocketService] Connected');
      _socketController.add(SocketEvent(type: SocketEventType.connected));
    });

    _socket!.onDisconnect((_) {
      print('[SocketService] Disconnected');
      _socketController.add(SocketEvent(type: SocketEventType.disconnected));
    });

    _socket!.onConnectError((error) {
      print('[SocketService] Connection error: $error');
      _socketController.add(SocketEvent(
        type: SocketEventType.error,
        data: {'error': error.toString()},
      ));
    });

    // Listen for driver location updates
    _socket!.on('driver:location_update', (data) {
      print('[SocketService] Driver location update: $data');
      _socketController.add(SocketEvent(
        type: SocketEventType.driverLocationUpdate,
        data: data is Map<String, dynamic> ? data : Map<String, dynamic>.from(data as Map),
      ));
    });

    // Listen for ETA updates
    _socket!.on('delivery:eta_update', (data) {
      print('[SocketService] ETA update: $data');
      _socketController.add(SocketEvent(
        type: SocketEventType.etaUpdate,
        data: data is Map<String, dynamic> ? data : Map<String, dynamic>.from(data as Map),
      ));
    });

    // Listen for delivery status changes
    _socket!.on('delivery:status_change', (data) {
      print('[SocketService] Status change: $data');
      _socketController.add(SocketEvent(
        type: SocketEventType.statusChange,
        data: data is Map<String, dynamic> ? data : Map<String, dynamic>.from(data as Map),
      ));
    });

    _socket!.connect();
  }

  /// Join a delivery room to receive updates for a specific delivery.
  void joinDeliveryRoom(String deliveryId) {
    if (_socket == null || !_socket!.connected) {
      print('[SocketService] Cannot join room - not connected');
      return;
    }
    _socket!.emit('join:delivery', {'deliveryId': deliveryId});
    print('[SocketService] Joined delivery room: $deliveryId');
  }

  /// Leave a delivery room.
  void leaveDeliveryRoom(String deliveryId) {
    if (_socket == null || !_socket!.connected) return;
    _socket!.emit('leave:delivery', {'deliveryId': deliveryId});
    print('[SocketService] Left delivery room: $deliveryId');
  }

  /// Disconnect from the server.
  void disconnect() {
    _socket?.disconnect();
    _socket?.dispose();
    _socket = null;
  }

  /// Dispose resources.
  void dispose() {
    disconnect();
    _socketController.close();
  }
}

enum SocketEventType {
  connected,
  disconnected,
  error,
  driverLocationUpdate,
  etaUpdate,
  statusChange,
}

class SocketEvent {
  final SocketEventType type;
  final Map<String, dynamic>? data;

  const SocketEvent({required this.type, this.data});
}

// Provider
final socketServiceProvider = Provider<SocketService>((ref) {
  final service = SocketService();
  ref.onDispose(() => service.dispose());
  return service;
});

// Stream provider for socket events
final socketEventsProvider = StreamProvider<SocketEvent>((ref) {
  final service = ref.watch(socketServiceProvider);
  return service.events;
});
