class ApiConstants {
  ApiConstants._();

  // Change this to your backend server URL
  static const String baseUrl = 'http://10.0.2.2:3000/api';
  // For physical device, use your machine's LAN IP:
  // static const String baseUrl = 'http://192.168.1.100:3000/api';

  // Socket.io server URL (same host, no /api path)
  static const String socketUrl = 'http://10.0.2.2:3000';

  // API Endpoints
  static const String saveLocation = '/locations';
  static const String getLocation = '/locations'; // GET /locations/:id
  static const String startDelivery = '/deliveries/start';
  static const String updateDriverLocation = '/deliveries'; // PUT /deliveries/:id/location
  static const String getDeliveryStatus = '/deliveries'; // GET /deliveries/:id

  // Reverse geocoding endpoint
  static const String reverseGeocode = '/geocode/reverse';

  // OpenStreetMap tile server
  static const String osmTileUrl = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';

  // Map style JSON for MapLibre with OSM raster tiles
  static const Map<String, dynamic> osmStyleJson = {
    'version': 8,
    'sources': {
      'osm': {
        'type': 'raster',
        'tiles': ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
        'tileSize': 256,
        'attribution': '© OpenStreetMap',
      },
    },
    'layers': [
      {
        'id': 'osm',
        'type': 'raster',
        'source': 'osm',
      },
    ],
  };
}
