# PinPoint Customer App

A Flutter-based customer delivery location pinning app using MapLibre GL with OpenStreetMap tiles.

## Features

- 📍 **Pin Drop** — Full-screen interactive map. Move the map, the pin stays fixed in center. Confirm your exact delivery location.
- 📝 **Location Details** — Add delivery notes (e.g., "blue gate, 3rd floor") and nearest landmark before saving.
- 💾 **Saved Locations** — View, manage, and quickly select previously saved delivery locations.
- 🚚 **Live Tracking** — Track your delivery driver in real-time with ETA updates and status progression.
- 🔌 **Real-time Updates** — Socket.IO integration for live driver location, ETA, and delivery status changes.

## Stack

| Layer | Technology |
|-------|-----------|
| Framework | Flutter (Dart) |
| Map | MapLibre GL + OpenStreetMap tiles (free, no API key) |
| State | Riverpod |
| HTTP | Dio |
| Real-time | Socket.IO |
| Location | Geolocator |
| Fonts | Google Fonts (Inter) |

## Project Structure

```
lib/
├── main.dart                              # App entry, navigation
├── core/
│   ├── constants/
│   │   └── api_constants.dart             # URLs, endpoints, map style
│   └── theme/
│       └── app_theme.dart                 # Material 3 theme, brand colors
├── models/
│   ├── delivery_location.dart             # Saved location model
│   └── active_delivery.dart               # Active delivery + status enum
├── services/
│   ├── location_service.dart              # GPS permissions, position, reverse geocode
│   ├── api_service.dart                   # Dio HTTP client, all API calls
│   └── socket_service.dart                # Socket.IO real-time events
├── features/
│   ├── pin_drop/
│   │   ├── pin_drop_screen.dart           # Main map screen with fixed pin
│   │   └── widgets/
│   │       └── confirm_location_sheet.dart # Bottom sheet for notes + save
│   ├── tracking/
│   │   └── tracking_screen.dart           # Driver tracking with ETA
│   └── saved_locations/
│       └── saved_locations_screen.dart     # Saved locations list
└── widgets/
    └── loading_overlay.dart               # Loading spinner overlay
```

## Prerequisites

- Flutter SDK >= 3.1.0
- Android SDK / Xcode (for iOS)
- A running PinPoint backend server

## Setup

### 1. Clone & Install

```bash
cd pinpoint/flutter-app
flutter pub get
```

### 2. Configure Backend URL

Edit `lib/core/constants/api_constants.dart`:

```dart
// For Android emulator
static const String baseUrl = 'http://10.0.2.2:3000/api';

// For iOS simulator or physical device (use your machine's LAN IP)
static const String baseUrl = 'http://192.168.1.100:3000/api';

// Socket URL (same host, no /api)
static const String socketUrl = 'http://192.168.1.100:3000';
```

### 3. Android Permissions

Add to `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.INTERNET" />
```

### 4. iOS Permissions

Add to `ios/Runner/Info.plist`:

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>PinPoint needs your location to set delivery pins</string>
<key>NSLocationAlwaysUsageDescription</key>
<string>PinPoint tracks your delivery in the background</string>
```

### 5. Run

```bash
flutter run
```

## API Endpoints Expected

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/locations` | Save a delivery location |
| GET | `/api/locations/:id` | Get a saved location |
| GET | `/api/locations?customerId=X` | List saved locations |
| DELETE | `/api/locations/:id` | Delete a saved location |
| POST | `/api/deliveries/start` | Start a delivery |
| PUT | `/api/deliveries/:id/location` | Update driver position |
| GET | `/api/deliveries/:id` | Get delivery status |
| GET | `/api/geocode/reverse?lat=X&lng=Y` | Reverse geocoding |

## Socket.IO Events

| Event | Direction | Payload |
|-------|-----------|---------|
| `join:delivery` | Client → Server | `{deliveryId: string}` |
| `leave:delivery` | Client → Server | `{deliveryId: string}` |
| `driver:location_update` | Server → Client | `{driverLat: number, driverLng: number}` |
| `delivery:eta_update` | Server → Client | `{etaMinutes: number}` |
| `delivery:status_change` | Server → Client | `{status: string}` |

## Map Configuration

The app uses OpenStreetMap raster tiles via MapLibre GL. No API key is required. The map style JSON is embedded in `api_constants.dart`.

## Brand Colors

- **Primary:** #2563EB (blue)
- **Success:** #10B981 (green)
- **Error:** #EF4444 (red)
- **Warning:** #F59E0B (amber)

## License

Proprietary — PinPoint Team
