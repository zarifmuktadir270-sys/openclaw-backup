# PinPoint PWA 📍

A Progressive Web App for delivery location pin-pointing. Customers drop their exact delivery location on a map and share it with a link.

## Features

- 🗺️ **Full-screen interactive map** (MapLibre GL JS + OpenStreetMap)
- 📍 **Fixed center pin** — user moves the map, pin stays
- 🔍 **Live reverse geocoding** — address updates as you pan
- 🛰️ **Satellite toggle** — switch between street and satellite view
- 📌 **GPS "My Location"** button
- 📝 **Delivery notes** — notes, landmark, name, phone fields
- 🔗 **Shareable links** — `?lat=...&lng=...&notes=...&landmark=...`
- 📴 **Offline support** — Service Worker caches app shell + tiles
- 📲 **Installable** — Add to Home Screen on Android & iOS
- 🌙 **Dark mode** — respects system preference
- 📱 **Safe area support** — notch phones (iPhone X+)
- 🔳 **Haptic feedback** on key actions

## Quick Start

### Local Development

```bash
# Serve with any static server
npx serve .
# or
python3 -m http.server 8080
```

Then open `http://localhost:8080` on your phone or desktop.

### Deploy

This is a **static site** — deploy anywhere that serves static files:

#### Netlify
1. Push to GitHub
2. Connect repo to Netlify
3. Build command: _(none)_
4. Publish directory: `.`

#### Vercel
```bash
npx vercel --prod
```

#### GitHub Pages
1. Push to GitHub
2. Settings → Pages → Source: `main` branch, `/` folder

#### Any VPS
```bash
# Just copy files to your web root
scp -r . user@server:/var/www/pinpoint/
```

## Shareable Link Format

When a user shares their location, the URL looks like:

```
https://pinpoint.app/?lat=23.8103&lng=90.4125&notes=blue+gate&landmark=near+mosque&name=Ahmed
```

Opening this link auto-centers the map and displays the notes.

## Project Structure

```
pinpoint/pwa/
├── index.html          # Single page app
├── css/
│   └── style.css       # All styles (glassmorphism, dark mode)
├── js/
│   ├── app.js          # Main app logic
│   └── geocoder.js     # Nominatim reverse geocoding
├── icons/
│   ├── icon-192.svg    # PWA icon (small)
│   └── icon-512.svg    # PWA icon (large)
├── manifest.json       # PWA manifest
├── sw.js               # Service Worker
└── README.md           # This file
```

## Tech Stack

- **Map**: [MapLibre GL JS 3.6.2](https://maplibre.org/) (CDN)
- **Tiles**: OpenStreetMap (free) + Esri satellite (optional)
- **Geocoding**: Nominatim (OpenStreetMap, free, no API key)
- **Offline**: Service Worker with stale-while-revalidate for tiles
- **No build step** — pure HTML/CSS/JS

## How It Works

1. **Map loads** with OSM tiles centered on last saved location (or Dhaka default)
2. **User pans** the map — the center pin stays fixed
3. **Address updates** live via Nominatim reverse geocoding (debounced 500ms)
4. **User adds notes** (optional): delivery instructions, landmark, name, phone
5. **User shares** — generates a link with coordinates + notes baked in
6. **Recipient opens link** — map auto-centers on the location, notes displayed

## Browser Support

- Chrome/Edge 80+
- Safari 14+ (iOS & macOS)
- Firefox 80+
- Samsung Internet 12+

## Notes on Nominatim

Nominatim has a [usage policy](https://operations.osmfoundation.org/policies/nominatim/):
- Max 1 request per second
- Must include a valid User-Agent
- For high-traffic production, consider [self-hosting Nominatim](https://nominatim.org/release-docs/latest/admin/Installation/) or using a commercial geocoding service.

The geocoder already debounces requests to respect this policy.

## License

MIT
