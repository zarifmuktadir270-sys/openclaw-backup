/**
 * PinPoint PWA - Service Worker
 * Caches app shell, map tiles, and Nominatim responses
 */

const CACHE_VERSION = 'v1.0.0';
const SHELL_CACHE = `pinpoint-shell-${CACHE_VERSION}`;
const TILE_CACHE = `pinpoint-tiles-${CACHE_VERSION}`;
const GEO_CACHE = `pinpoint-geo-${CACHE_VERSION}`;

// App shell files to pre-cache
const SHELL_FILES = [
  '/',
  '/index.html',
  '/css/style.css',
  '/js/app.js',
  '/js/geocoder.js',
  '/manifest.json',
  '/icons/icon-192.svg',
  '/icons/icon-512.svg'
];

// External resources
const EXTERNAL_RESOURCES = [
  'https://unpkg.com/maplibre-gl@3.6.2/dist/maplibre-gl.js',
  'https://unpkg.com/maplibre-gl@3.6.2/dist/maplibre-gl.css'
];

// ========== Install ==========
self.addEventListener('install', (event) => {
  event.waitUntil(
    Promise.all([
      // Cache shell
      caches.open(SHELL_CACHE).then((cache) => {
        return cache.addAll(SHELL_FILES.concat(EXTERNAL_RESOURCES));
      })
    ]).then(() => {
      return self.skipWaiting();
    })
  );
});

// ========== Activate ==========
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys
          .filter((key) => {
            return key.startsWith('pinpoint-') &&
              key !== SHELL_CACHE &&
              key !== TILE_CACHE &&
              key !== GEO_CACHE;
          })
          .map((key) => caches.delete(key))
      );
    }).then(() => {
      return self.clients.claim();
    })
  );
});

// ========== Fetch ==========
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Skip non-GET requests
  if (event.request.method !== 'GET') return;

  // OpenStreetMap tiles - Stale While Revalidate
  if (url.hostname === 'tile.openstreetmap.org' ||
      url.hostname === 'server.arcgisonline.com') {
    event.respondWith(staleWhileRevalidate(event.request, TILE_CACHE, 30));
    return;
  }

  // Nominatim geocoding - Network First with cache fallback
  if (url.hostname === 'nominatim.openstreetmap.org') {
    event.respondWith(networkFirst(event.request, GEO_CACHE, 50));
    return;
  }

  // App shell / local files - Cache First
  if (url.origin === self.location.origin) {
    event.respondWith(cacheFirst(event.request, SHELL_CACHE));
    return;
  }

  // External CDN resources - Cache First with network fallback
  if (url.hostname === 'unpkg.com') {
    event.respondWith(cacheFirst(event.request, SHELL_CACHE));
    return;
  }
});

// ========== Strategies ==========

/**
 * Cache First: Return cached version, fallback to network
 */
async function cacheFirst(request, cacheName) {
  const cached = await caches.match(request);
  if (cached) return cached;

  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    // If both cache and network fail, return offline page for navigation
    if (request.mode === 'navigate') {
      return caches.match('/index.html');
    }
    throw err;
  }
}

/**
 * Stale While Revalidate: Return cached, update in background
 */
async function staleWhileRevalidate(request, cacheName, maxItems) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);

  // Fetch in background to update cache
  const fetchPromise = fetch(request).then((response) => {
    if (response.ok) {
      cache.put(request, response.clone()).then(() => {
        // Limit cache size
        trimCache(cacheName, maxItems);
      });
    }
    return response;
  }).catch(() => null);

  // Return cached immediately if available, otherwise wait for network
  return cached || fetchPromise || new Response('', { status: 504 });
}

/**
 * Network First: Try network, fallback to cache
 */
async function networkFirst(request, cacheName, maxItems) {
  const cache = await caches.open(cacheName);

  try {
    const response = await fetch(request);
    if (response.ok) {
      cache.put(request, response.clone()).then(() => {
        trimCache(cacheName, maxItems);
      });
    }
    return response;
  } catch (err) {
    const cached = await cache.match(request);
    if (cached) return cached;

    return new Response(JSON.stringify({ error: 'offline' }), {
      headers: { 'Content-Type': 'application/json' },
      status: 503
    });
  }
}

// ========== Cache Management ==========
async function trimCache(cacheName, maxItems) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length > maxItems) {
    // Delete oldest entries (first in the list)
    const toDelete = keys.slice(0, keys.length - maxItems);
    await Promise.all(toDelete.map((key) => cache.delete(key)));
  }
}

// ========== Background Sync (for queued pin saves) ==========
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-pin') {
    event.waitUntil(syncQueuedPins());
  }
});

async function syncQueuedPins() {
  // Could sync queued pins to a server when back online
  console.log('Syncing queued pins...');
}
