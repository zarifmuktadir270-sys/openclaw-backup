/**
 * PinPoint PWA - Main Application
 */
(function () {
  'use strict';

  // ========== State ==========
  const state = {
    map: null,
    center: { lat: 23.8103, lng: 90.4125 }, // Default: Dhaka
    zoom: 15,
    address: '',
    notes: '',
    landmark: '',
    name: '',
    phone: '',
    satellite: false,
    geolocated: false
  };

  // ========== DOM refs ==========
  const $ = (sel) => document.querySelector(sel);
  const headerAddress = $('#header-address .address-text');
  const bottomAddressText = $('#bottom-address-text');
  const bottomCoords = $('#bottom-coords');
  const loadingSkeleton = $('#loading-skeleton');
  const centerPin = $('#center-pin');
  const notesBadge = $('#notes-badge');

  // Buttons
  const btnMyLocation = $('#btn-my-location');
  const btnSatellite = $('#btn-satellite');
  const btnNotes = $('#btn-notes');
  const btnShare = $('#btn-share');

  // Notes modal
  const notesModal = $('#notes-modal');
  const inputNotes = $('#input-notes');
  const inputLandmark = $('#input-landmark');
  const inputName = $('#input-name');
  const inputPhone = $('#input-phone');
  const btnSaveNotes = $('#btn-save-notes');
  const btnCancelNotes = $('#btn-cancel-notes');

  // Share modal
  const shareModal = $('#share-modal');
  const shareAddress = $('#share-address');
  const shareCoords = $('#share-coords');
  const shareNotes = $('#share-notes');
  const shareLinkInput = $('#share-link-input');
  const btnCopyLink = $('#btn-copy-link');
  const btnCloseShare = $('#btn-close-share');
  const btnNativeShare = $('#btn-native-share');
  const shareNativeContainer = $('#share-native-container');

  // Offline banner
  const offlineBanner = $('#offline-banner');

  // ========== Plus Code Generator ==========
  // Simple Open Location Code (Plus Code) implementation
  const PLUS_CODE_CHARS = '23456789CFGHJMPQRVWX';
  const PLUS_CODE_LAT_ORIGIN = -90;
  const PLUS_CODE_LNG_ORIGIN = -180;

  function generatePlusCode(lat, lng, codeLength = 10) {
    let latVal = lat - PLUS_CODE_LAT_ORIGIN;
    let lngVal = lng - PLUS_CODE_LNG_ORIGIN;
    // Normalize to [0, 1]
    latVal = Math.max(0, Math.min(1, latVal / 180));
    lngVal = Math.max(0, Math.min(1, lngVal / 360));

    let code = '';
    let digits = Math.floor(codeLength / 2);

    for (let i = 0; i < digits; i++) {
      // Encode longitude then latitude
      const lngDigit = Math.floor(lngVal * 20);
      code += PLUS_CODE_CHARS[lngDigit];
      lngVal = (lngVal * 20) - lngDigit;

      const latDigit = Math.floor(latVal * 20);
      code += PLUS_CODE_CHARS[latDigit];
      latVal = (latVal * 20) - latDigit;

      if (i === 3 && codeLength > 8) {
        code += '+';
      }
    }

    return code;
  }

  // ========== Haptic Feedback ==========
  function haptic(style = 'light') {
    if (!navigator.vibrate) return;
    switch (style) {
      case 'light': navigator.vibrate(10); break;
      case 'medium': navigator.vibrate(25); break;
      case 'heavy': navigator.vibrate([10, 30, 10]); break;
      case 'success': navigator.vibrate([10, 50, 10]); break;
    }
  }

  // ========== Local Storage ==========
  function saveState() {
    try {
      localStorage.setItem('pinpoint_state', JSON.stringify({
        center: state.center,
        zoom: state.zoom,
        notes: state.notes,
        landmark: state.landmark,
        name: state.name,
        phone: state.phone
      }));
    } catch (e) {
      // localStorage might be full or disabled
    }
  }

  function loadState() {
    try {
      const saved = localStorage.getItem('pinpoint_state');
      if (saved) {
        const data = JSON.parse(saved);
        if (data.center) state.center = data.center;
        if (data.zoom) state.zoom = data.zoom;
        if (data.notes) state.notes = data.notes;
        if (data.landmark) state.landmark = data.landmark;
        if (data.name) state.name = data.name;
        if (data.phone) state.phone = data.phone;
      }
    } catch (e) {
      // ignore
    }
  }

  // ========== URL Params ==========
  function parseUrlParams() {
    const params = new URLSearchParams(window.location.search);
    if (params.has('lat') && params.has('lng')) {
      state.center.lat = parseFloat(params.get('lat'));
      state.center.lng = parseFloat(params.get('lng'));
      state.zoom = 17;
    }
    if (params.has('notes')) {
      state.notes = decodeURIComponent(params.get('notes'));
    }
    if (params.has('landmark')) {
      state.landmark = decodeURIComponent(params.get('landmark'));
    }
    if (params.has('name')) {
      state.name = decodeURIComponent(params.get('name'));
    }
  }

  // ========== Map Setup ==========
  const osmStyle = {
    version: 8,
    sources: {
      osm: {
        type: 'raster',
        tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
        tileSize: 256,
        attribution: '© OpenStreetMap'
      }
    },
    layers: [{ id: 'osm', type: 'raster', source: 'osm' }]
  };

  function initMap() {
    state.map = new maplibregl.Map({
      container: 'map',
      style: osmStyle,
      center: [state.center.lng, state.center.lat],
      zoom: state.zoom,
      attributionControl: true,
      pitchWithRotate: false,
      dragRotate: false,
      touchPitch: false
    });

    // Remove default controls except attribution
    state.map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'bottom-right');

    state.map.on('load', () => {
      // Hide loading skeleton
      setTimeout(() => {
        loadingSkeleton.classList.add('fade-out');
        setTimeout(() => {
          loadingSkeleton.style.display = 'none';
        }, 500);
      }, 300);

      // Add satellite source (hidden initially)
      addSatelliteSource();
    });

    // Track map movement
    let moveEndTimeout;
    state.map.on('move', () => {
      const center = state.map.getCenter();
      state.center.lat = center.lat;
      state.center.lng = center.lng;
      state.zoom = state.map.getZoom();

      // Update coords display
      bottomCoords.textContent = `${center.lat.toFixed(6)}, ${center.lng.toFixed(6)}`;
    });

    state.map.on('moveend', () => {
      clearTimeout(moveEndTimeout);
      moveEndTimeout = setTimeout(() => {
        updateAddress();
        saveState();
      }, 200);
    });

    state.map.on('error', (e) => {
      console.error('Map error:', e);
    });
  }

  // ========== Satellite Toggle ==========
  function addSatelliteSource() {
    try {
      state.map.addSource('satellite', {
        type: 'raster',
        tiles: [
          'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
        ],
        tileSize: 256,
        attribution: '© Esri'
      });
      state.map.addLayer({
        id: 'satellite-layer',
        type: 'raster',
        source: 'satellite',
        layout: { visibility: 'none' },
        beforeId: 'osm'
      });
    } catch (e) {
      console.warn('Could not add satellite source:', e);
    }
  }

  function toggleSatellite() {
    state.satellite = !state.satellite;
    haptic('medium');

    if (state.satellite) {
      btnSatellite.classList.add('active');
      if (state.map.getLayer('satellite-layer')) {
        state.map.setLayoutProperty('satellite-layer', 'visibility', 'visible');
      }
    } else {
      btnSatellite.classList.remove('active');
      if (state.map.getLayer('satellite-layer')) {
        state.map.setLayoutProperty('satellite-layer', 'visibility', 'none');
      }
    }
  }

  // ========== Geolocation ==========
  function goToMyLocation() {
    haptic('medium');
    btnMyLocation.style.opacity = '0.5';

    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser');
      btnMyLocation.style.opacity = '1';
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        state.center.lat = latitude;
        state.center.lng = longitude;
        state.geolocated = true;

        state.map.flyTo({
          center: [longitude, latitude],
          zoom: 17,
          duration: 1000
        });

        haptic('success');
        btnMyLocation.style.opacity = '1';

        // Bounce the pin
        centerPin.classList.add('bounce');
        setTimeout(() => centerPin.classList.remove('bounce'), 400);
      },
      (err) => {
        console.warn('Geolocation error:', err);
        alert('Could not get your location. Please enable location services.');
        btnMyLocation.style.opacity = '1';
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 5000
      }
    );
  }

  // ========== Address Update ==========
  function updateAddress() {
    Geocoder.reverseGeocode(state.center.lat, state.center.lng, (result) => {
      if (!result) return;
      state.address = result.address;
      headerAddress.textContent = result.address;
      bottomAddressText.textContent = result.address;
    });
  }

  // ========== Notes Modal ==========
  function openNotesModal() {
    haptic('light');
    inputNotes.value = state.notes;
    inputLandmark.value = state.landmark;
    inputName.value = state.name;
    inputPhone.value = state.phone;
    notesModal.classList.add('active');
    // Focus after animation
    setTimeout(() => inputNotes.focus(), 350);
  }

  function closeNotesModal() {
    notesModal.classList.remove('active');
  }

  function saveNotes() {
    state.notes = inputNotes.value.trim();
    state.landmark = inputLandmark.value.trim();
    state.name = inputName.value.trim();
    state.phone = inputPhone.value.trim();

    // Update badge
    const hasNotes = state.notes || state.landmark;
    if (hasNotes) {
      notesBadge.textContent = '✓';
      notesBadge.classList.remove('hidden');
    } else {
      notesBadge.classList.add('hidden');
    }

    haptic('success');
    closeNotesModal();
    saveState();
  }

  // ========== Share ==========
  function buildShareUrl() {
    const base = window.location.origin;
    const params = new URLSearchParams();
    params.set('lat', state.center.lat.toFixed(6));
    params.set('lng', state.center.lng.toFixed(6));
    if (state.notes) params.set('notes', state.notes);
    if (state.landmark) params.set('landmark', state.landmark);
    if (state.name) params.set('name', state.name);
    return `${base}/?${params.toString()}`;
  }

  function openShareModal() {
    haptic('medium');

    // Build share content
    shareAddress.textContent = state.address || 'Loading address...';
    shareCoords.textContent = `${state.center.lat.toFixed(6)}, ${state.center.lng.toFixed(6)}  •  Plus Code: ${generatePlusCode(state.center.lat, state.center.lng)}`;

    const noteParts = [];
    if (state.notes) noteParts.push(`📝 ${state.notes}`);
    if (state.landmark) noteParts.push(`📍 ${state.landmark}`);
    if (state.name) noteParts.push(`👤 ${state.name}`);
    if (state.phone) noteParts.push(`📞 ${state.phone}`);
    shareNotes.textContent = noteParts.length ? noteParts.join('\n') : '';

    const shareUrl = buildShareUrl();
    shareLinkInput.value = shareUrl;

    // Show native share button if available
    if (navigator.share) {
      shareNativeContainer.style.display = 'block';
    } else {
      shareNativeContainer.style.display = 'none';
    }

    // Make sure we have an address
    if (!state.address) {
      Geocoder.reverseGeocodeImmediate(state.center.lat, state.center.lng).then((result) => {
        if (result) {
          state.address = result.address;
          shareAddress.textContent = result.address;
        }
      });
    }

    shareModal.classList.add('active');
  }

  function closeShareModal() {
    shareModal.classList.remove('active');
  }

  function copyShareLink() {
    haptic('success');
    navigator.clipboard.writeText(shareLinkInput.value).then(() => {
      btnCopyLink.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        Copied!
      `;
      btnCopyLink.style.background = '#22c55e';
      setTimeout(() => {
        btnCopyLink.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
          </svg>
          Copy
        `;
        btnCopyLink.style.background = '';
      }, 2000);
    }).catch(() => {
      // Fallback: select the text
      shareLinkInput.select();
      document.execCommand('copy');
    });
  }

  function nativeShare() {
    haptic('medium');
    const shareUrl = buildShareUrl();
    const shareText = `📍 My delivery location\n${state.address}\n${state.notes ? '📝 ' + state.notes + '\n' : ''}${state.landmark ? '📍 ' + state.landmark + '\n' : ''}`;

    navigator.share({
      title: 'PinPoint - Delivery Location',
      text: shareText,
      url: shareUrl
    }).catch(() => {
      // User cancelled or error - do nothing
    });
  }

  // ========== Offline Detection ==========
  function updateOnlineStatus() {
    if (!navigator.onLine) {
      offlineBanner.classList.remove('hidden');
      // Adjust header position
      document.querySelector('.header-bar').style.top = `calc(40px + var(--safe-top))`;
    } else {
      offlineBanner.classList.add('hidden');
      document.querySelector('.header-bar').style.top = '';
    }
  }

  // ========== Pull to Refresh ==========
  let pullStartY = 0;
  let pulling = false;

  function initPullRefresh() {
    document.addEventListener('touchstart', (e) => {
      if (window.scrollY === 0 && e.touches[0].clientY > 60) {
        pullStartY = e.touches[0].clientY;
        pulling = true;
      }
    }, { passive: true });

    document.addEventListener('touchmove', (e) => {
      if (!pulling) return;
      const pullDistance = e.touches[0].clientY - pullStartY;
      if (pullDistance > 100) {
        // Could show a refresh indicator here
      }
    }, { passive: true });

    document.addEventListener('touchend', (e) => {
      if (!pulling) return;
      pulling = false;
      // No actual refresh needed for a map app, but nice UX feel
    });
  }

  // ========== Service Worker ==========
  function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then((reg) => {
          console.log('SW registered:', reg.scope);
        })
        .catch((err) => {
          console.warn('SW registration failed:', err);
        });
    }
  }

  // ========== Event Listeners ==========
  function bindEvents() {
    // Controls
    btnMyLocation.addEventListener('click', goToMyLocation);
    btnSatellite.addEventListener('click', toggleSatellite);

    // Notes
    btnNotes.addEventListener('click', openNotesModal);
    btnSaveNotes.addEventListener('click', saveNotes);
    btnCancelNotes.addEventListener('click', closeNotesModal);

    // Close notes modal on overlay click
    notesModal.addEventListener('click', (e) => {
      if (e.target === notesModal) closeNotesModal();
    });

    // Share
    btnShare.addEventListener('click', openShareModal);
    btnCopyLink.addEventListener('click', copyShareLink);
    btnCloseShare.addEventListener('click', closeShareModal);
    btnNativeShare.addEventListener('click', nativeShare);

    // Close share modal on overlay click
    shareModal.addEventListener('click', (e) => {
      if (e.target === shareModal) closeShareModal();
    });

    // Keyboard
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeNotesModal();
        closeShareModal();
      }
    });

    // Online/offline
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);

    // Pull to refresh
    initPullRefresh();

    // Prevent double-tap zoom on buttons
    document.querySelectorAll('.btn, .control-btn').forEach(btn => {
      btn.addEventListener('touchend', (e) => {
        e.preventDefault();
        btn.click();
      });
    });
  }

  // ========== Init ==========
  function init() {
    // Parse URL params first (shared link)
    parseUrlParams();

    // Load saved state (URL params override saved state)
    if (!window.location.search) {
      loadState();
    }

    // Apply saved notes to UI
    if (state.notes || state.landmark) {
      notesBadge.textContent = '✓';
      notesBadge.classList.remove('hidden');
    }

    // Set initial header address
    if (state.address) {
      headerAddress.textContent = state.address;
      bottomAddressText.textContent = state.address;
    }

    // Init
    initMap();
    bindEvents();
    registerServiceWorker();
    updateOnlineStatus();

    // If we loaded from a shared link, immediately geocode
    if (window.location.search.includes('lat=')) {
      Geocoder.reverseGeocodeImmediate(state.center.lat, state.center.lng).then((result) => {
        if (result) {
          state.address = result.address;
          headerAddress.textContent = result.address;
          bottomAddressText.textContent = result.address;

          // Show notes if present
          if (state.notes || state.landmark) {
            openShareModal();
          }
        }
      });
    }
  }

  // Start when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
