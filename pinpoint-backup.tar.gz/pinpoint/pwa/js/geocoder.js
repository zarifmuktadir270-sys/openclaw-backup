/**
 * PinPoint - Reverse Geocoding Module
 * Uses Nominatim API with debounce, caching, and error handling
 */
const Geocoder = (() => {
  const CACHE_SIZE = 100;
  const DEBOUNCE_MS = 500;
  const API_URL = 'https://nominatim.openstreetmap.org/reverse';

  // In-memory cache: key -> { address, display, timestamp }
  const cache = new Map();
  let debounceTimer = null;
  let pendingController = null;

  /**
   * Generate a cache key from coordinates (rounded to 5 decimals ~1m precision)
   */
  function cacheKey(lat, lng) {
    return `${lat.toFixed(5)},${lng.toFixed(5)}`;
  }

  /**
   * Format address from Nominatim response
   */
  function formatAddress(data) {
    if (!data || !data.address) return data?.display_name || 'Unknown location';

    const a = data.address;
    const parts = [];

    // Building/house number + road
    if (a.house_number && a.road) {
      parts.push(`${a.road} ${a.house_number}`);
    } else if (a.road) {
      parts.push(a.road);
    }

    // Suburb / neighbourhood
    const neighbourhood = a.neighbourhood || a.suburb || a.residential || a.commercial;
    if (neighbourhood && !parts.some(p => p.includes(neighbourhood))) {
      parts.push(neighbourhood);
    }

    // City / town / village
    const city = a.city || a.town || a.village || a.municipality || a.county;
    if (city) {
      parts.push(city);
    }

    // State
    if (a.state) {
      parts.push(a.state);
    }

    // Country
    if (a.country) {
      parts.push(a.country);
    }

    return parts.length > 0 ? parts.join(', ') : (data.display_name || 'Unknown location');
  }

  /**
   * Perform the actual reverse geocode request
   */
  async function fetchGeocode(lat, lng) {
    // Cancel any in-flight request
    if (pendingController) {
      pendingController.abort();
    }
    pendingController = new AbortController();

    const url = `${API_URL}?lat=${lat}&lon=${lng}&format=json&addressdetails=1&zoom=18`;

    try {
      const response = await fetch(url, {
        signal: pendingController.signal,
        headers: {
          'Accept': 'application/json',
          'Accept-Language': 'en'
        }
      });

      if (!response.ok) {
        throw new Error(`Geocode HTTP ${response.status}`);
      }

      const data = await response.json();
      pendingController = null;

      const result = {
        display: data.display_name || 'Unknown location',
        address: formatAddress(data),
        raw: data,
        timestamp: Date.now()
      };

      // Cache it
      const key = cacheKey(lat, lng);
      if (cache.size >= CACHE_SIZE) {
        // Evict oldest entry
        const oldestKey = cache.keys().next().value;
        cache.delete(oldestKey);
      }
      cache.set(key, result);

      return result;
    } catch (err) {
      pendingController = null;
      if (err.name === 'AbortError') {
        return null; // Cancelled, ignore
      }
      console.warn('Geocoder error:', err);
      return {
        display: `${lat.toFixed(5)}, ${lng.toFixed(5)}`,
        address: `${lat.toFixed(5)}, ${lng.toFixed(5)}`,
        raw: null,
        error: true,
        timestamp: Date.now()
      };
    }
  }

  /**
   * Reverse geocode with debounce. Returns a Promise that resolves
   * with the geocoded address or null if cancelled by a newer request.
   * @param {number} lat
   * @param {number} lng
   * @param {function} callback - Called with the result
   */
  function reverseGeocode(lat, lng, callback) {
    const key = cacheKey(lat, lng);

    // Check cache first
    if (cache.has(key)) {
      callback(cache.get(key));
      return;
    }

    // Debounce
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(async () => {
      const result = await fetchGeocode(lat, lng);
      if (result) {
        callback(result);
      }
    }, DEBOUNCE_MS);
  }

  /**
   * Immediate geocode (no debounce). Useful for initial load or share links.
   */
  async function reverseGeocodeImmediate(lat, lng) {
    const key = cacheKey(lat, lng);
    if (cache.has(key)) {
      return cache.get(key);
    }
    return await fetchGeocode(lat, lng);
  }

  /**
   * Cancel any pending geocode
   */
  function cancel() {
    clearTimeout(debounceTimer);
    if (pendingController) {
      pendingController.abort();
      pendingController = null;
    }
  }

  return {
    reverseGeocode,
    reverseGeocodeImmediate,
    cancel,
    formatAddress
  };
})();
