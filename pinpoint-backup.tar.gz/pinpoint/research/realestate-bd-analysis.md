# Bangladesh Real Estate AI Assistant: Market Analysis
## Can You Sell AI to Property Dealers in Bangladesh?

**Date:** March 31, 2026
**Status:** Market Research Report
**Core Thesis:** BD property dealers are drowning in repetitive inquiries, losing deals daily, and many will pay ৳2,000-5,000/month for an AI assistant — but only if it speaks their language (literally and figuratively).

---

## 1. Real Estate Agent Daily Pain

### A Typical Day for a BD Property Dealer

**Morning (9 AM - 12 PM):**
- Arrive at office (usually a small shop or floor in a commercial building)
- Check missed calls from overnight — 20-30 calls on property listing numbers
- Call back serious leads, ignore spam
- WhatsApp messages from Bikroy/Bproperty inquiries pile up
- 2-3 walk-in customers wanting to list their property

**Afternoon (12 PM - 5 PM):**
- Peak inquiry time — phone rings every 3-5 minutes
- Show 2-3 properties to walk-in customers
- Negotiate with buyers/sellers
- Deal with existing tenants calling about maintenance
- More WhatsApp forwarding of property photos

**Evening (5 PM - 9 PM):**
- Second peak for calls (people call after work)
- Facebook page messages — usually 15-40 per day, mostly unanswered
- Follow up on deals in progress
- Update listings on Bikroy (if they bother anymore)

### Repetitive Tasks That Consume Their Time

| Task | Time Wasted/Day | Frequency |
|------|-----------------|-----------|
| Answering "price koto?" calls | 2-3 hours | 40-60 calls |
| Answering "location kothay?" | 30-45 min | Same calls, different questions |
| "Flat ta available?" (is it still available?) | 30 min | 20-30 calls for sold properties |
| WhatsApp forwarding same photos/info | 1 hour | Dozens of conversations |
| Facebook message responses | 30 min | Usually ignored anyway |
| Showing properties to non-serious buyers | 1-2 hours | 3-5 visits |
| Note-taking/lead tracking | 30 min | Ad hoc, usually mental notes |

**Total wasted time: 5-7 hours per day on repetitive inquiry handling.**

### What Happens When They Miss a Call?

**Brutal truth: In BD, the caller moves to the next agent within minutes.**

- Property buyer calls Agent A → no answer → calls Agent B → answers → done.
- The buyer has already called 3-5 agents for the same area.
- There is ZERO loyalty to the first agent they found.
- **Estimated loss: 30-50% of inbound calls go unanswered, and those customers are gone forever.**

A busy Dhaka property dealer might miss 20-40 calls per day. If each call was a potential ৳50,000-200,000 commission opportunity... do the math.

### Current Inquiry Channels (Ranked by Volume)

1. **Phone calls** — #1 channel by far. BD buyers love calling.
2. **WhatsApp** — #2. Text, photos, voice notes. Critical for initial contact.
3. **Facebook Messenger** — #3. Most agents have a page, most ignore the messages.
4. **Bikroy.com** — Generates calls, but agents complain about quality leads.
5. **Bproperty** — Similar to Bikroy, slightly more serious buyers.
6. **Walk-in** — Still happens, especially in neighborhoods with broker shops.
7. **FlatB, Osthek.com** — Small players, not worth optimizing for.

### Peak Hours for Inquiries

| Time Slot | Call Volume | Notes |
|-----------|-------------|-------|
| 9-10 AM | Medium | People checking before work |
| 10 AM-12 PM | High | Serious buyers actively searching |
| 12-2 PM | Medium | Lunch break calls |
| 2-5 PM | High | Afternoon prime time |
| 5-7 PM | **PEAK** | Post-work, everyone calls |
| 7-9 PM | High | Evening prime, family discussions |
| 9 PM-12 AM | Medium | Late night browsers (NRBs calling from abroad) |
| 12 AM-9 AM | Low | Missed calls accumulate |

**The 5-8 PM window is the killing zone** — this is when most agents are overwhelmed and missing calls.

---

## 2. The Money They Lose

### Customer Loss Calculation

**Scenario: Mid-tier Dhaka property dealer**

- Receives 80 calls/day
- Answers ~50 (misses ~30)
- Of 50 answered: ~15 are serious inquiries
- Of 15 serious: ~5 lead to property visits
- Of 5 visits: ~1-2 lead to a deal

**If AI answered all 80 calls:**
- 30 missed calls recovered → ~6 additional serious inquiries → ~1 additional property visit → **~0.2-0.4 extra deals per month**

That doesn't sound like much, but read on.

### Value of One Property Deal

**Dhaka Residential Property Commissions:**

| Property Type | Typical Value (BDT) | Commission % | Agent Earnings (BDT) |
|---------------|---------------------|--------------|----------------------|
| Apartment (Dhaka mid-range) | 50-80 lakh | 1-2% | 50,000-160,000 |
| Apartment (Dhaka premium, Gulshan/Banani) | 1.5-5 crore | 1-2% | 1,50,000-10,00,000 |
| Plot/Land (Dhaka) | 30 lakh-5 crore | 1-2% (sometimes fixed) | 50,000-10,00,000 |
| Rental property | 15,000-80,000/month | 1 month rent as commission | 15,000-80,000 |
| Commercial space | 50 lakh-10 crore | 1-2% | 50,000-20,00,000 |

**Chittagong/Sylhet:**
- Values are 40-60% of Dhaka prices
- Commissions are similar percentages but smaller absolute amounts
- A Chittagong agent might earn ৳30,000-100,000 per residential deal

### ROI if AI Saves ONE Deal Per Month

**Conservative scenario (small Dhaka agent):**
- One extra rental deal/month: ৳25,000-50,000 commission
- AI cost: ৳3,000-5,000/month
- **ROI: 5x-16x**

**Moderate scenario (mid-tier Dhaka agent):**
- One extra apartment sale every 2 months: ৳50,000-100,000 commission
- AI cost: ৳5,000/month
- **ROI: 10x-20x**

**Premium scenario (upscale area agent):**
- One extra premium deal per quarter: ৳200,000+ commission
- AI cost: ৳5,000-8,000/month
- **ROI: 7x-10x**

**The math is stupid-simple: If the AI saves ONE call that converts per month, it pays for itself 5-20x over.**

### Annual Impact

A busy agent doing 15-20 deals/year (earning ৳15-40 lakh/year in commissions):
- 10% improvement from AI = 1.5-2 extra deals/year
- Extra annual income: ৳1.5-5 lakh
- AI annual cost: ৳36,000-96,000
- **Net benefit: ৳1-4 lakh/year for a ৳36-96k investment**

---

## 3. Current Tools They Use

### Software Adoption: Brutally Honest

**What they actually use:**
- **WhatsApp:** Universal. 95%+ of agents. This is their CRM, their calling tool, their photo gallery.
- **Phone (native dialer):** 100%. No CRM, no call tracking. Missed calls = lost.
- **Facebook Pages:** 70%+ have one. Maybe 20% actively manage Messenger.
- **Bikroy.com:** ~60% of Dhaka agents, less in smaller cities. Complain about cost and lead quality.
- **Bproperty:** ~30% of active agents. Slightly more premium positioning.
- **FlatB:** ~10%. Smaller but growing.
- **Google Sheets/Notes app:** ~15% track leads. The rest have no system.
- **Proper CRM software:** <5%. Almost nobody.

### What They DON'T Use

- ❌ No call tracking system
- ❌ No lead management/CRM
- ❌ No automated responses of any kind
- ❌ No scheduling tools (use manual diary or nothing)
- ❌ No analytics on which listings perform best
- ❌ No chatbot on Facebook or WhatsApp

### Tech Attitude: The Three Tiers

**Tier 1 — "Old School" (40-50% of agents)**
- Age 40+
- Basic phone usage, WhatsApp for forwarding
- Skeptical of any software
- "Amar bari'r number diye kotha boli" (I talk on my personal number)
- **Will NOT adopt AI easily.** Need extreme simplicity.

**Tier 2 — "Willing but clueless" (30-40% of agents)**
- Age 25-40
- Uses WhatsApp actively, maybe has a business page
- Has tried Bikroy, pays for listings
- Open to tools if they're easy and cheap
- **PRIMARY TARGET. This is your customer.**

**Tier 3 — "Tech-forward" (10-15% of agents)**
- Age 20-35
- Multiple listings on Bproperty + Bikroy + Facebook
- Some use two phones, WhatsApp Business
- Might already want something like this
- **Early adopters. Sell to them first to build case studies.**

### Platform-Specific Observations

**Bikroy.com:**
- Listing costs: ৳500-5,000 per listing depending on category and duration
- Premium packages: ৳5,000-20,000/month
- Agents complain about spam inquiries and low-quality leads
- A great "pain point" to reference in sales conversations

**Bproperty:**
- More curated, higher quality leads
- Similar pricing to Bikroy
- Agents appreciate the lead matching feature
- Less volume than Bikroy

**Facebook:**
- Free to list, but requires manual management
- Many agents post in local groups (Dhaka Flat & Apartment, Area-specific groups)
- Messenger responses are painfully slow (hours to days)
- **This is the lowest-hanging fruit for AI automation**

---

## 4. AI Assistant Use Cases — What Actually Works in BD

### Feature Priority Matrix

| Feature | Impact | Ease of Sale | Tech Complexity | Priority |
|---------|--------|-------------|-----------------|----------|
| WhatsApp auto-responder | 🔥🔥🔥 | Easy | Medium | #1 |
| Facebook Messenger bot | 🔥🔥 | Medium | Medium | #2 |
| Lead qualification | 🔥🔥🔥 | Medium | High | #3 |
| Property catalog in WhatsApp | 🔥🔥 | Easy | Medium | #4 |
| Auto-schedule visits | 🔥 | Hard | High | #5 |
| Voice call AI (IVR) | 🔥🔥🔥 | Hard | Very High | #6 |

### #1: WhatsApp Auto-Responder (THE KILLER FEATURE)

**How it works:**
- Agent lists a property with photos, price, location
- When someone messages about it, AI instantly replies
- Handles the first 3-5 questions automatically
- If buyer wants to visit, AI schedules with agent
- If buyer has unusual questions, hands off to human

**Sample conversation:**

> **Buyer:** এই ফ্ল্যাটটা কত?
> **AI:** Assalamu Alaikum! 🏠 Ei 3-bedroom flatটা ৳55 lakh. 1200 sqft, 7th floor, Uttara Sector 7. Gas, lift, parking আছে। কি জানতে চান?
>
> **Buyer:** Rent কত?
> **AI:** Ei flatটা sale এর জন্য আছে — ৳55 lakh। যদি rent চান, আমাদের কাছে 3 other options আছে Uttara তে — ৳18,000-25,000/month। কোনটা দেখতে চান?
>
> **Buyer:** Location ta bolben?
> **AI:** Uttara Sector 7, House #42. Metro station থেকে 5 min walk। Airport থেকে 15 min। Map link: [gmaps link]
>
> **Buyer:** Visit korte parbo?
> **AI:** Absolutely! Apni kon din available? Amra Saturday/Sunday কোনো একটা slot安排 করতে পারি। বিকাল 3-6 tayer moddhe কোনো time convenient?
>
> **Buyer:** Kisu barta pathano jacche na (messages not going)
> **AI:** Ei flatটা still available, InshaAllah! Price: ৳55 lakh. Apni ki visit করতে চান? Ami apnake schedule এ � rakhbo. আপনার নাম কি?

**Why this works in BD:**
- Buyers expect immediate response
- 80% of buyer questions are identical: price, location, size, facilities
- Auto-response within 30 seconds vs. human response within hours/days
- Even a "wrong" answer is better than no answer

### #2: Facebook Messenger Bot

**Why it matters:**
- Agents post on Facebook groups and pages
- Buyers message on Facebook first, then call
- Current response time: 2-24 hours (if ever)
- AI response: instant

**Key limitation:** Facebook doesn't like bots. You need Meta Business Suite integration or use a third-party like ManyChat. In BD, most agents won't bother with Meta Business verification.

**Practical approach:** Simple auto-reply that says "Call this number / WhatsApp this number" + collects basic info (name, budget, area) and forwards to agent.

### #3: Lead Qualification

**The problem:** BD agents waste 60%+ of their time on "window shoppers" — people who call to check prices with no intent to buy.

**AI Qualification Flow:**
1. Buyer asks about property
2. AI provides basic info
3. AI asks: "Apni budget roughly koto range এ ভাবছেন?" (What's your budget range?)
4. AI asks: "Kon area তে খুঁজছেন?" (Which area?)
5. AI asks: "Apni ki NRB naki এখানে আছেন?" (Are you local or abroad?)
6. AI tags lead as HOT (budget + area match + wants visit), WARM (interested but vague), or COLD (just browsing)

**This alone could save 2-3 hours per day for a busy agent.**

### #4: WhatsApp Property Catalog

**Setup:**
- Agent sends AI a list of properties with photos
- AI organizes them into a WhatsApp Business catalog or a simple bot menu
- Buyer texts "list" or "ami flat dekhte chai"
- AI sends available properties matching their criteria

**Why BD-specific:** WhatsApp is king. No app downloads, no websites, no logins. Everyone has WhatsApp.

### #5: Auto-Schedule Visits

**Problem:** Scheduling property visits is chaos. Buyer wants Saturday 3 PM. Agent says "ok" but forgets. No show. Lost deal.

**AI Solution:**
- AI checks agent's calendar (or just accepts time slots)
- Sends confirmation to both parties
- Sends reminder 2 hours before
- If buyer cancels, AI offers slot to next interested buyer

**Why it's harder to sell:** Most BD agents operate on "I'll call you when I'm free." Calendar management is foreign to them.

### #6: Voice Call AI (IVR)

**The dream:** AI answers actual phone calls, handles initial questions, schedules visits.

**Why it's hard in BD:**
- Voice recognition in Bangla/Banglish is still unreliable
- BD phone lines have quality issues
- Agent trust issue: "If AI answers my calls, customers might think I'm not serious"
- Telecom costs and technical complexity
- **Don't lead with this. Build it later.**

---

## 5. Pricing Analysis

### What BD Property Dealers Currently Spend

| Expense | Monthly Cost (BDT) |
|---------|-------------------|
| Bikroy premium listing | ৳3,000-20,000 |
| Office rent (shared/cramped) | ৳10,000-50,000 |
| Phone bills (multiple SIMs) | ৳1,000-3,000 |
| Assistant/receptionist | ৳8,000-15,000 |
| Transportation | ৳3,000-10,000 |
| **Total monthly overhead** | **৳25,000-100,000** |

### Receptionist Comparison (Key Sales Angle)

| | Human Receptionist | AI Assistant |
|---|---|---|
| Monthly cost | ৳8,000-15,000 | ৳2,000-5,000 |
| Available 24/7 | ❌ Works 9-8 | ✅ Always on |
| Can handle 100 calls/day | ❌ Overwhelmed at 20-30 | ✅ Unlimited |
| Knows all properties | ❌ New hires take 2-3 weeks | ✅ Instant |
| Takes sick days | ✅ Yes, monthly | ❌ Never |
| Speaks Bangla fluently | ✅ Native | ⚠️ 85-90% accurate |
| Can sell/negotiate | ⚠️ Sometimes | ❌ No |
| Replaces agent entirely | ❌ No | ❌ No |

**The pitch:** "It's like having a receptionist who never sleeps, costs 1/3 as much, and never forgets a property detail."

### Recommended Pricing Models

#### Model A: Flat Monthly (Recommended)

| Tier | Price (BDT/month) | Features | Target |
|------|-------------------|----------|--------|
| **Basic** | ৳1,500 | WhatsApp auto-reply for 10 properties, basic FAQ | Small agents, new starters |
| **Standard** | ৳3,000 | WhatsApp + FB Messenger, lead qualification, 30 properties | Mid-tier agents (MAIN TARGET) |
| **Premium** | ৳5,000 | Everything + visit scheduling + lead analytics + 100 properties | High-volume agencies |

#### Model B: Per-Lead (Bad Idea for BD)

- ৳50-100 per qualified lead
- **Why it won't work:** Agents will argue about what counts as a "qualified lead"
- Creates adversarial relationship instead of partnership
- BD agents are used to paying fixed costs (Bikroy packages)

#### Model C: Per-Property Listed

- ৳200-500 per property in the AI catalog
- **Okay as an add-on** but not the primary model
- Could work as: "Base ৳2,000/month + ৳100/property after 20"

### What They'll Actually Pay

**Brutal honesty on price sensitivity:**

- Dhaka Tier 1 agents (Gulshan, Banani, Dhanmondi): ৳3,000-8,000/month — no problem
- Dhaka Tier 2 agents (Mirpur, Mohammadpur, Uttara): ৳2,000-4,000/month — sweet spot
- Dhaka Tier 3 agents (outer areas): ৳1,000-2,000/month — needs to be cheap
- Chittagong/Sylhet: ৳1,000-2,500/month — lower ceiling
- Other cities (Rajshahi, Khulna, Rangpur): ৳500-1,500/month — price sensitive

**Recommended launch price: ৳2,000/month for Standard tier.** Raise to ৳3,000 after proving value with first 20 customers.

### Revenue Projections

| Customers | Monthly Revenue | Notes |
|-----------|----------------|-------|
| 10 | ৳20,000 | MVP phase |
| 50 | ৳1,00,000 | Proving the model |
| 200 | ৳4,00,000 | Regional proof |
| 500 | ৳10,00,000 | Scaling |
| 1,000 | ৳20,00,000 | Serious business |

**Realistic first-year target: 50-100 paying customers = ৳1-3 lakh/month revenue.**

---

## 6. Exact Sales Pipeline

### Step 1: Finding and Approaching Real Estate Agents

**Where to find them:**
1. **Bikroy.com** — Scrape listing phone numbers (public info)
2. **Facebook groups** — "Dhaka Flat & Apartment," "Property Dealers Bangladesh," area-specific groups
3. **Physical visit** — Go to areas with high broker density: Mirpur 12, Mohammadpur, Uttara, Banasree
4. **Google Maps** — Search "real estate agent" in Dhaka neighborhoods
5. **Bproperty agent directory** — Publicly listed agents
6. **Word of mouth** — One agent tells another (powerful in BD)

**Approach script (in-person, Bangla-English mix):**

> **You:** Assalamu Alaikum bhaiya/kaka! Ami [Name]. Amra ekta chotto service চালু korsi — AI assistant jeta apnar phone calls and WhatsApp manage kore. Shunben 2 minute?
>
> **Agent:** Ki je service? ChatGPT naki?
>
> **You:** Na na, ChatGPT to sobai use kore, kintu eta specifically apnar moto property dealer er jonno banano. Dekhun — apni daily 50-100 ta call pennen, na? Ar onekta same question thake — price, location, availability. Ei AI shob answer kore automatic. Apni shudhu serious customer er sathe kotha bolben.
>
> **Agent:** Koto khoroche eta?
>
> **You:** Ekhon amra free trial dicchi 15 din. Tarpor only ৳2,000/month. Ekta receptionist er dam er 1/4. Dekhun, 15 diner moddhe jodi apnar 1 ta extra deal hoyeo, tar commission etar khorcha 100 gun cover kore jabe.

**Approach script (phone/WhatsApp cold message):**

> "Assalamu Alaikum bhaiya! Apni [Bikroy/Facebook] theke property dekhlam — খুব সুন্দর listing! 🏠
>
> Ami ekta AI assistant এর service offer করতে chai apnar jonno. Eta apnar WhatsApp e auto-reply kore — jokhon kono customer message kore, AI instantly answer kore apnar property er price, location, size — shob kichu. Apni shudhu visit schedule korte paren.
>
> 15 din free trial. Tarpor only ৳2,000/month. Ekbar dekhle bujhben 🙏
>
> Ei number e WhatsApp korben: [your number]"

### Step 2: What to Show in First Meeting (5-Minute Demo)

**Materials needed:** Phone with demo running

1. **Show the problem (30 seconds):**
   "Apnar WhatsApp dekhun — koto gula message pending. Ei shob customer waiting."

2. **Show the solution (2 minutes):**
   Send a test message to the demo number. Show AI replying instantly with property details.

3. **Show the lead qualification (1 minute):**
   Show how AI asks budget/area/wants-visit questions and tags leads.

4. **Show the comparison (1 minute):**
   "Without AI: customer calls → no answer → gone to competitor.
   With AI: customer messages → instant reply → scheduled visit → deal."

5. **Show the price (30 seconds):**
   "Only ৳2,000/month. 15 din free trial, cancel anytime."

### Step 3: Handling the "ChatGPT is Free" Objection

This WILL come up. Every time.

**Response script:**

> "Bhaiya, ChatGPT to free, thik. Kintu ChatGPT ke:
> 1. Apnar property list setup korte hobe — apni ki khudha kore diten?
> 2. Every time kono customer asle apni ChatGPT khulben? Typing korben?
> 3. ChatGPT apnar property er price, location bolte parbe na — because eta apnar data nei.
> 4. ChatGPT bangla te apnar moto respond korte parbe na.
>
> Eita alada kotha. Eta apnar business er jonno custom built. Apnar 50 ta property er data dhukalam — AI ready. Customer message korle instant answer. 24/7.
>
> Ekta simple example dicchi — apni ChatGPT khulun, amar demo number e message korun, tarpor ai helper number e korun. Donno er difference bujhben."

**Alternative objection handler:**

> "ChatGPT ekjon general knowledge student. AI assistant ekjon trained receptionist. General student ke apnar office e boshaben na — apnar trained chahiye."

### Step 4: Contract/Deal Structure

**Simple approach (NO complicated contracts):**

1. **15-day free trial** — no credit card, no commitment
2. **After trial:** Pay monthly via bKash/Nagad/bank transfer
3. **No lock-in** — cancel anytime by texting "cancel"
4. **Simple terms:** "You pay ৳2,000/month, we provide AI assistant service. Cancel anytime."

**Why keep it simple:**
- BD agents hate paperwork
- Lawyers are expensive and slow
- Trust is built through performance, not contracts
- A verbal agreement + bKash payment is how BD small business works

**Later (after 50+ customers):** Consider a basic written agreement for higher tiers.

### Step 5: Onboarding Process (30 Minutes)

**What the agent needs to provide:**

1. **Phone number** — The one they use for property inquiries (WhatsApp)
2. **Property list** — Google Sheet or WhatsApp messages with:
   - Property type (flat/plot/commercial)
   - Location (area, sector, road)
   - Size (sqft)
   - Price
   - Facilities (gas, lift, parking, etc.)
   - Photos (can be sent via WhatsApp)
3. **Basic FAQ answers:**
   - Office location
   - Working hours
   - Commission terms (if they want AI to share)
4. **Available hours for visits** — When can they show properties?

**Onboarding call/meeting:**
1. Set up AI account (10 min)
2. Agent sends property data (10 min — they can forward existing WhatsApp messages)
3. Test the system with 2-3 test messages (5 min)
4. Go live (5 min)

**Key: Make it so easy that even a Tier 1 "old school" agent can do it.**

### Step 6: Retention Strategy

**Why agents will cancel:**
1. AI gives wrong info (quality control)
2. No visible value (can't measure ROI)
3. Agent forgets they're paying (no ongoing touchpoint)
4. Better competitor appears

**Retention tactics:**

1. **Monthly report (automated):** "Apnar AI assistant e gache month e 342 ta inquiry handle korse. 87 ta lead qualify korse. 23 ta visit schedule korse." — Agents love seeing numbers.

2. **Weekly check-in (WhatsApp):** Short message: "Everything going well? Any property to add/remove?" — Shows you care.

3. **Free feature drops:** "New feature: AI ekhon voice note o pathate pare!" — Keeps it exciting.

4. **Community:** Create a WhatsApp group of agent customers. They share tips, complain, bond. Sticky.

5. **Referral program:** "Friend ke invite korle — tar first month free, apni ek month 50% discount." — BD agents talk to each other.

6. **Annual discount:** Pay yearly = 2 months free. Commits them for a year.

---

## 7. BD Real Estate Specifics

### Dhaka vs Other Cities

| Factor | Dhaka | Chittagong | Sylhet | Other Cities |
|--------|-------|------------|--------|--------------|
| Price range (apartment) | 30L-10Cr+ | 15L-4Cr | 15L-3Cr | 10L-2Cr |
| Commission % | 1-2% | 1-2% | 1-2% | 1-2% |
| Agent density | Extremely high | High | Medium | Low-Medium |
| Tech adoption | Highest in BD | Medium | Medium | Low |
| Willingness to pay | Highest | Medium | Medium | Low |
| Call volume | 80-150/day | 40-80/day | 30-60/day | 20-50/day |
| **Best market** | **Yes** | **Yes (tier 2)** | **Okay** | **Later** |

**Recommendation:** Launch in Dhaka only. Expand to Chittagong after 50 customers. Other cities after 200.

### Flat Sale vs Rent Market

| | Sale | Rent |
|---|---|---|
| Commission value | ৳50,000-10,00,000 | ৳15,000-80,000 |
| Frequency | 1-3/month | 3-10/month |
| Inquiry volume | High | Very high |
| AI value | High (big deals) | **Very high** (volume) |
| Decision time | Weeks-months | Days-weeks |

**Insight:** Rent market has MORE inquiries and MORE repetitive questions. AI is even more valuable for rental agents because they handle 3-5x more inquiries per deal.

### Commercial vs Residential

| | Residential | Commercial |
|---|---|---|
| Deal size | 30L-5Cr | 50L-10Cr+ |
| Complexity | Low | High |
| AI suitability | **Perfect** | Needs human for details |
| Customer type | Individual | Business owner |
| Inquiry pattern | Simple questions | Complex questions |

**Focus on residential.** It's 80% of the market and 90% of repetitive inquiries.

### NRB (Non-Resident Bangladeshi) Buyers

**This is a GOLDMINE for AI:**

- NRBs live in USA, UK, Canada, Middle East, Australia
- They buy property in BD for investment or retirement
- **They call/message at weird hours** (BD time night/morning)
- They ask the SAME questions repeatedly (price, location, legal status, rent yield)
- They need photos, videos, and lots of hand-holding
- They often use WhatsApp because international calling is expensive

**AI value for NRBs:**
- 24/7 availability (NRB calls at 2 AM BD time — AI answers)
- Instant property info with photos
- Can handle English and Bangla
- Can explain basic legal process (mutation, deed, registration)
- Schedule visits with family members visiting on their behalf

**NRB-specific features:**
- English-first responses with Bangla option
- NRB-focused FAQs: "Is the property in a good area for investment?" "What's the rental yield?" "Can I buy without visiting?"
- Time zone awareness: Auto-suggest BD visiting hours

**Commission from NRB deals is often higher** because they negotiate less and pay asking price more often.

---

## 8. Competitive Landscape (What Exists Now)

### Current Solutions in BD

| Solution | What it does | Limitation |
|----------|-------------|------------|
| Bikroy auto-replies | Basic listing management | No AI, no WhatsApp integration |
| Bproperty lead matching | Sends leads to agents | No automated response to inquiries |
| WhatsApp Business | Auto-greeting message | Dumb auto-reply, no property knowledge |
| ChatGPT (manual) | General AI assistant | No property data, not integrated |
| Human receptionist | Answers calls | Expensive, limited hours, forgets details |

**There is currently NO dedicated AI assistant for BD property dealers.** The market is wide open.

### Potential Competitors

1. **Local dev shops** — Might build something custom for big agencies. Too expensive for individual agents.
2. **International solutions** — Realtor.com, Zillow tools. Not built for BD market, Bangla language, or local platforms.
3. **Bproperty/Bikroy** — Could add AI features to their existing platforms. But they're listing platforms, not AI companies.
4. **WhatsApp Business API providers** — Could theoretically offer this. Currently focused on e-commerce.

**Window of opportunity: 12-18 months before a major player enters.**

---

## 9. Technical Architecture (Brief)

### Minimum Viable Product

**Tech stack recommendation:**

- **WhatsApp Business API** via provider (Twilio, WATI, or local BD provider like 10 Minute School's API team or REVE Systems)
- **AI/LLM backend:** Claude API or GPT-4o mini (cheaper, good Bangla support)
- **Database:** Simple PostgreSQL — properties, agents, inquiries
- **Frontend:** Simple web dashboard for agent to manage properties
- **Infrastructure:** AWS Bangladesh region or local hosting

**Cost to run (per 100 customers):**
- WhatsApp API: ~৳50,000-100,000/month
- AI API calls: ~৳30,000-80,000/month
- Hosting: ~৳10,000-20,000/month
- **Total: ~৳90,000-200,000/month to serve 100 customers paying ৳2,00,000/month**
- **Gross margin: ~50-80%** ✅

### Development Timeline

| Phase | Duration | Deliverable |
|-------|----------|-------------|
| MVP (WhatsApp only, basic AI) | 4-6 weeks | 10 beta customers |
| FB Messenger integration | +2 weeks | 25 customers |
| Lead qualification + analytics | +4 weeks | 50 customers |
| Visit scheduling + NRB features | +6 weeks | 100 customers |

**Total to revenue-ready MVP: 4-6 weeks.**

---

## 10. Getting First 5 Customers — Timeline

### Week 1: Groundwork
- Build basic WhatsApp AI demo (even a simple rule-based version)
- Join 10+ Dhaka property Facebook groups
- Collect 50 agent phone numbers from Bikroy
- Visit 5 physical broker offices in Mirpur/Mohammadpur/Uttara

### Week 2: Outreach
- Send WhatsApp messages to 50 agents
- Post in Facebook groups offering free trial
- Visit 5 more broker offices with phone demo
- **Target: 10 interested agents, 5 sign up for trial**

### Week 3: Onboarding & Proof
- Onboard 5 trial customers
- Set up their property data
- Monitor and fix AI responses
- Collect feedback daily
- **Target: All 5 agents using it, at least 3 happy**

### Week 4: Conversion
- Show each trial agent their stats: "AI handled X inquiries, scheduled Y visits"
- Ask: "Would you continue for ৳2,000/month?"
- **Target: 3-5 paying customers** 🎉

### Month 2: First Referrals
- Ask happy customers to refer other agents
- Offer referral bonus (1 month 50% off)
- Post testimonials in Facebook groups
- Scale outreach to 200 agents
- **Target: 10-15 total customers**

---

## 11. Risks & Honest Assessment

### What Could Go Wrong

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| AI gives wrong price/info | High early | High (loses trust) | Human review of all AI responses initially |
| Agents don't trust AI | Medium | Critical | 14-day free trial, show results |
| WhatsApp bans the number | Low-Medium | Critical | Use official WhatsApp Business API |
| Language issues (Banglish) | High early | Medium | Fine-tune on BD property language |
| Payment collection pain | Medium | Medium | bKash auto-pay or manual follow-up |
| Competition from Bproperty | Low (12-18mo) | High | Move fast, build brand, lock in customers |
| Agent churn after trial | High | Medium | Show clear value with monthly reports |

### What I'd Tell Myself (Brutally Honest)

1. **The product works.** The need is real, the solution is obvious.
2. **Sales is the hard part, not tech.** Building the AI is the easy part. Convincing skeptical Bangladeshi property dealers is the challenge.
3. **Start with WhatsApp, not a website.** Don't build a fancy dashboard. Build a WhatsApp bot that works.
4. **Price low, prove value, raise later.** ৳2,000/month is almost an impulse purchase for a Dhaka agent.
5. **Bangla-first.** Not English with Bangla support. Bangla FIRST. English second.
6. **The "ChatGPT is free" objection will come from EVERYONE.** Have your response practiced and ready.
7. **One success story is worth 100 cold calls.** Get one agent to say "this AI helped me close a deal" and share that everywhere.
8. **Don't build too much before selling.** A working WhatsApp bot with 3 properties is enough to start selling. Don't wait for the perfect product.
9. **Physical meetings > digital marketing in BD.** Property dealers trust face-to-face. Go to their offices.
10. **bKash is your friend.** Don't ask for bank transfers. bKash/Nagad payments only.

---

## 12. Summary — The 60-Second Pitch

> **"BD property dealers get 50-100 calls/day asking the same 5 questions: price, location, size, availability, and when can I visit. They miss 30% of calls, lose customers to competitors, and waste 5+ hours daily.**
>
> **An AI assistant on their WhatsApp answers instantly, 24/7, in Bangla. Handles inquiries, qualifies leads, schedules visits. Costs ৳2,000/month — less than 1/4 of a receptionist.**
>
> **If it saves just ONE extra deal per month, it pays for itself 10-20x over.**
>
> **15-day free trial. No commitment. Cancel anytime.**
>
> **They'll pay. The question is how fast you can build it and sell it."**

---

*Report prepared for market research purposes. All pricing in BDT. Estimates based on BD real estate market knowledge and industry analysis.*
