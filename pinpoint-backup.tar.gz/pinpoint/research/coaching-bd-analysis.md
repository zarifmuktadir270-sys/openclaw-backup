# Coaching Center Market Analysis: Bangladesh
## Can an AI-Powered Service Make Money from Coaching Centers in BD?

**Date:** March 31, 2026
**Research Scope:** Deep analysis of the BD coaching center ecosystem, monetization pathways, and competitive landscape

---

## Executive Summary (Brutal Honesty)

**The short answer:** Coaching centers in Bangladesh are a **viable but dangerous market**. They're price-sensitive, tech-resistant, and the "free ChatGPT" objection is real. BUT — there's a narrow path to money if you stop selling "AI" and start selling **teacher superpowers** and **operational efficiency**. The market is ~৳5,000-10,000 crore annually, fragmented across tens of thousands of centers, and virtually untouched by modern SaaS. The opportunity is real. The execution difficulty is extremely high.

**Bottom line:** Don't build an "AI for coaching centers" product. Build a **coaching center management tool that happens to use AI**. The difference is everything.

---

## 1. Real Pain Points (Not Assumptions)

### What Coaching Center Owners ACTUALLY Complain About

Based on the real dynamics of BD coaching centers (which are overwhelmingly small-to-medium operations, 50-500 students, 1-3 branches):

#### A. Teacher Crisis (Their #1 Problem)
- **Teacher poaching:** Good teachers leave and start their own coaching or join competitors. This is the #1 killer. A popular math teacher taking 30 students with them can bankrupt a center overnight.
- **Teacher unreliability:** Teachers show up late, skip classes, or leave mid-session. No-shows during exam season are devastating.
- **No institutional knowledge:** When a teacher leaves, everything goes with them — methods, student relationships, notes. The coaching center has no moat.
- **Teacher quality is inconsistent:** One teacher gets results, another doesn't, but the owner can't easily tell until results come out 6 months later.
- **Can't fire bad teachers easily:** In small towns, relationships matter. A bad teacher might be a relative of a student's family friend.

#### B. Student Retention & Churn
- **Seasonal churn:** Students join before exams (SSC/HSC/admission tests), leave right after. Revenue is cyclical.
- **Mid-batch dropout:** Students who fall behind stop coming. The owner only realizes when fees stop coming.
- **Competitor poaching:** Nearby coaching centers offer ৳100-200 discount per month to steal students.
- **No data on WHY students leave:** They just... stop showing up. No exit interviews, no analytics.

#### C. Operations & Money
- **Fee collection is a nightmare:** Parents pay late, partial, or not at all. bKash tracking is manual. Many parents pay ৳500 one month, skip the next.
- **Cash flow is unpredictable:** Monthly revenue swings wildly based on enrollment cycles.
- **Rent is the biggest cost:** Coaching centers in good locations (near schools) pay ৳15,000-50,000/month rent. This is fixed regardless of enrollment.
- **No books/notes system:** Most coaching centers photocopy materials. The cost and logistics of materials is a hidden pain.
- **Government/regulatory uncertainty:** The government periodically cracks down on coaching centers (especially during political cycles), creating existential risk.

#### D. Where They Lose Money
- **Empty seats = lost revenue:** A class of 30 capacity with 15 students still pays the same rent and teacher salary.
- **No-show parents on fee day:** 20-30% fee default rate is common in middle-tier centers.
- **Wasted teacher hours:** Teachers paid for 2-hour slots but finish content in 1.5 hours. Or class is over but they have to stay because students have questions.
- **Marketing is word-of-mouth only:** No way to systematically grow. Relying on results + reputation is slow.

#### E. What Teachers Hate
- **Repeating the same explanation 50 times:** Teaching the same concept to 5 batches.
- **No tools for doubt resolution:** Students message on WhatsApp at 11 PM. Teachers hate this.
- **Administrative burden:** Taking attendance, tracking fees, communicating with parents.
- **Being underpaid relative to value:** A teacher who gets 10 students into BUET is worth ৳50,000+/month but might be paid ৳15,000-25,000.

#### F. Friction Points in the Triangle

| Relationship | Friction |
|---|---|
| **Center ↔ Student** | Student can't reach teacher after hours. No practice materials. No progress tracking. |
| **Center ↔ Parent** | Parent doesn't know what's being taught. No visibility into child's performance until exam results. Fee disputes. |
| **Teacher ↔ Student** | Teacher can't give individual attention in large batches. Some students need more help, others are bored. |
| **Teacher ↔ Center** | Teacher feels like a mercenary. No loyalty. Center feels teacher is replaceable (they're not). |

---

## 2. Student Behavior

### Why Students Leave Coaching Centers

1. **"I'm not improving"** — The #1 reason. Students measure themselves against exam results. If mock test scores don't go up, they blame the center.
2. **Teacher left** — The specific teacher they liked moved or quit. They follow the teacher, not the brand.
3. **Found something cheaper** — A competitor offering ৳200 less per month. Price sensitivity is extreme.
4. **Can't keep up / too far behind** — Fell behind in class, felt embarrassed, stopped coming. This is silent attrition.
5. **Got into a prep program** — University admission coaching takes over, or they joined a residential hafel/quota coaching.
6. **"I can study on my own"** — Especially after YouTube/ChatGPT access. But this usually fails and they come back (or don't).

### What Students Wish Coaching Offered

- **After-class doubt support** — This is the BIGGEST unmet need. A student practices at home, gets stuck at 9 PM, and has to wait until the next class (sometimes 2 days later).
- **Practice problems with solutions** — Not just theory, but structured problem sets.
- **Mock tests that feel real** — Timed, under pressure, with scoring.
- **Individual attention** — "I don't understand" in a class of 40 is scary. They want to ask privately.
- **Flexible timing** — Students have school + coaching + homework. Scheduling conflicts are constant.

### When Students Struggle Most

1. **After class (homework time)** — This is when the "stuck" moments happen. 60-70% of learning happens during self-study, and this is when they have zero support.
2. **1-2 weeks before exams** — Panic revision. Need rapid doubt clearing, not new content.
3. **During practice problem solving** — Theory is understood, but application fails. The gap between "I understood the lecture" and "I can solve the problem" is where students drown.
4. **When switching topics** — Going from algebra to geometry requires different thinking. No smooth transition support.

### How Students Currently Get Help When Teacher is Unavailable

- **WhatsApp the teacher** — Teacher may or may not respond. 50+ messages from students, hard to keep up.
- **Ask a classmate** — Limited effectiveness.
- **YouTube** — Search for the specific topic. Hit or miss quality.
- **ChatGPT** — Increasingly used by urban students with smartphone access. But: (a) answers in English, (b) can't explain in BD exam context, (c) often gives wrong approach for NCTB curriculum.
- **Wait until next class** — Most common. Also most damaging to momentum.
- **Google in Bengali** — Very limited quality content for BD-specific curriculum.

---

## 3. What They'd Actually Pay For

### What "AI" is NOT a Selling Point — But These ARE:

#### Tier 1: Must-Have (Would pay ৳500-1,500/month)
- **Automated fee collection & tracking** — bKash integration, automated reminders, default tracking. This solves daily pain.
- **Student attendance & communication** — Auto SMS/WhatsApp to parents when student is absent. Huge trust builder.
- **Basic scheduling & batch management** — Replace the notebook/Excel sheet.

#### Tier 2: Strong Want (Would pay ৳1,500-3,000/month)
- **Practice question bank with solutions** — BD curriculum-specific (NCTB, DU, BUET, medical). Auto-generated or curated.
- **Student progress dashboard** — Show parents "your child improved 30% in math this month." THIS IS GOLD for retention.
- **WhatsApp-based student support bot** — Students can ask questions and get hints (not full answers) in Bengali, 24/7. This is the killer feature.
- **Mock test generation** — Auto-generate time-appropriate tests.

#### Tier 3: Premium (Would pay ৳3,000-5,000/month)
- **Parent portal** — Real-time visibility into child's attendance, scores, weak areas.
- **Teacher performance analytics** — Which teacher's students improve most? Who's underperforming?
- **Competitive intelligence** — Track where students come from, where they go when they leave.
- **Marketing tools** — SMS campaigns to nearby schools, auto-generated result cards to share on Facebook.

### What Makes an Owner Pull Out bKash

The trigger is NOT "this is cool tech." The trigger is:

1. **"This will help me keep more students"** — Retention = revenue. Show that centers using the tool have 20% less churn.
2. **"This saves me from daily hassle"** — Fee collection, attendance, parent communication. Automate the boring stuff.
3. **"This gets me more students"** — Better results → more word-of-mouth → more enrollment.
4. **"My competitor is using it"** — FOMO. Once one center in a neighborhood uses it, others will follow.
5. **"I can charge students more"** — If the center can show "we have a digital system + 24/7 doubt support," they can justify ৳200-300 higher fees.

### ৳500/month vs ৳5,000/month Value Perception

| ৳500/month | ৳5,000/month |
|---|---|
| "Maybe I'll try it" | "That's almost a teacher's salary" |
| Feels like a small convenience | Must justify against hiring an extra teacher |
| Easy impulse buy via bKash | Requires seeing ROI proof |
| Comparable to: mobile data pack | Comparable to: one teacher's monthly salary |
| Low commitment, low expectation | High commitment, high expectation |
| **Works for:** basic attendance/fee tool | **Works for:** full system that demonstrably increases revenue |

**The sweet spot for BD coaching centers: ৳800-2,000/month.** This is:
- Less than 1% of a typical center's monthly revenue (৳50,000-200,000)
- Comparable to their monthly photocopy/printing costs
- Payable via bKash without "needing to think about it"
- But enough to sustain a SaaS business if you hit 200+ centers

---

## 4. The "Free ChatGPT" Objection — Deep Analysis

### Why This Objection is BOTH Real and Misleading

**The objection is real because:**
- Students are already using ChatGPT. It's free. It answers questions. Why pay?
- BD parents think "technology = free" because Facebook, YouTube, WhatsApp are free.
- Coaching center owners see ChatGPT as something students use on their own, not something they should pay for.

**The objection is misleading because:**
- Students using ChatGPT is NOT the same as students learning from ChatGPT.
- ChatGPT doesn't know NCTB syllabus, doesn't understand BD exam patterns, can't give hints in the right pedagogical sequence.
- The coaching center isn't selling "an AI chatbot." If they are, they've already lost.

### What Custom AI Can Do That ChatGPT CANNOT

| Capability | ChatGPT | Custom AI for BD Coaching |
|---|---|---|
| **Curriculum alignment** | Knows general math/science | Knows NCTB Class 9-12 chapter-by-chapter, question patterns by year |
| **Language** | Primarily English, Bengali is mediocre | Native-quality Bengali explanations |
| **Pedagogical hints** | Gives full answers (students copy) | Gives progressive hints (student discovers answer) |
| **Progress tracking** | No memory between sessions | Tracks which topics each student struggles with |
| **BD exam context** | Generic problems | "This type of question appeared in HSC 2023, 2024 — here's the pattern" |
| **Teacher integration** | Independent of teacher | Teacher assigns specific practice → AI supports → Teacher sees results |
| **Availability** | Always available but generic | 24/7 but contextually aware of what was taught in class TODAY |
| **Parent reports** | None | "Your child asked 15 questions this week, struggled with Chapter 7" |

### How to Frame the Product So "Free ChatGPT" Isn't Even Relevant

**DON'T say:** "We have an AI tutor that helps students 24/7"
**DO say:** "We help your coaching center keep more students and collect fees faster"

**The framing shift:**

❌ **Wrong frame:** "AI-powered learning assistant for students" → Parent thinks "ChatGPT is free"
✅ **Right frame:** "Coaching center management system" → Owner thinks "this helps my business"

❌ **Wrong frame:** "Students can ask questions anytime" → Owner thinks "they can do that on ChatGPT"
✅ **Right frame:** "Your students will practice more and score higher, so you keep more students" → Owner thinks "more revenue"

❌ **Wrong frame:** "Smart AI tutor in Bengali" → Parent thinks "interesting but free ChatGPT works"
✅ **Right frame:** "We track your child's weak areas and send you progress reports" → Parent thinks "I'd pay for this visibility"

**The key insight:** Don't sell the AI. Sell the OUTCOME that AI enables. The AI is infrastructure, not the product.

**Analogy:** Nobody pays for "cloud computing." They pay for "a website that loads fast." Nobody should pay for "AI tutoring." They should pay for "students who score higher and stay enrolled."

---

## 5. Competitive Landscape

### Existing BD EdTech Players

#### 10 Minute School (10ms.com)
- **Model:** B2C — sells courses directly to students/parents
- **Funding:** Sequoia seed round (2022), Robi partnership
- **Strengths:** Brand recognition, YouTube following, broad curriculum coverage
- **Weaknesses:** NOT coaching-center-friendly. They compete WITH coaching centers, not serve them. Generic content, not personalized.
- **Revenue model:** Course sales (৳500-5,000 per course), premium subscriptions
- **Relevant to us:** They prove BD students will pay for quality education content. But they're B2C and don't touch coaching center operations.

#### BDTalks / Shikho
- **Model:** B2C admission test prep
- **Focus:** University admission coaching (BUET, DU, medical)
- **Status:** Funded but struggling with unit economics
- **Gap they don't fill:** Regular school-level coaching center operations

#### ClassToPad / MySchool
- **Model:** School management, some coaching features
- **Focus:** K-12 school administration
- **Gap:** Not built for coaching center-specific workflows (batch-based, exam-prep focused, fee-based)

#### Local WhatsApp-based Solutions
- **Thousands of small operators** managing coaching centers via WhatsApp groups + Excel
- **No real software** — this is the actual competitor: inertia and spreadsheets
- **Opportunity:** These are your future customers, not obstacles

#### International Players
- **Byju's:** Tried BD, failed. Too expensive, wrong model.
- **Coursera/Khan Academy:** Free/cheap but English-medium, NCTB-irrelevant.

### What's Working
- **10 Minute School:** Proves BD market exists for affordable, quality education content
- **WhatsApp-based teacher-student communication:** Universally adopted, but chaotic
- **bKash for payments:** Payment infrastructure is solved
- **YouTube education channels:** Massive adoption (Channels like Nafij's Physics, Munzereen's English)

### What's Failing
- **B2C EdTech startups:** Churn is brutal, acquisition cost is high, parents won't pay ৳2,000+/month for online courses when coaching centers cost ৳800-1,500
- **"AI tutor" products:** Nobody in BD is paying for an AI tutor. Free ChatGPT killed this market before it started.
- **SaaS for schools:** Schools in BD are government-run and don't buy software. Coaching centers are private but tech-averse.

### The Gap (Where the Money Is)

**No one is building a B2B SaaS for coaching centers in Bangladesh.**

- 10 Minute School is B2C (student-facing)
- School management software targets schools, not coaching centers
- No one owns the "coaching center operating system" space

**The gap is a tool that:**
1. Makes the coaching center owner's life easier (operations)
2. Makes the student score higher (learning support)
3. Makes the parent feel confident (visibility)
4. Does all this WITHOUT being sold as "AI" — just sold as "better coaching"

---

## 6. Exact Pipeline

### Step 1: How to Approach a Coaching Center

**DO NOT:**
- Cold email with "AI-powered education platform"
- Walk in with a laptop showing a chatbot demo
- Talk about "digital transformation" or "EdTech"

**DO:**

1. **Start with 3-5 friendly centers** — Owners you know, or ones in your neighborhood. Don't aim for big chains. Aim for mid-tier (100-300 students, 1-2 branches).

2. **Lead with the problem, not the product:**
   - "Boss, fee collection kemon cholche?" (How's fee collection going?)
   - "Teacher jodi chole jay, ki korben?" (If a teacher leaves, what will you do?)
   - "Parent-ra feedback deben kivabe?" (How do parents give feedback?)

3. **Offer a FREE pilot for 1 month** — No commitment. "Amra ekhane 1 month free试 দিচ্ছি। Jodi kaaj na kore, kono problem nai." (We're offering a 1-month free trial. If it doesn't work, no problem.)

4. **Target the pain point that keeps them up at night:** Usually student retention or fee collection. Solve ONE thing well.

5. **Use WhatsApp to demonstrate, not a website** — BD coaching owners live on WhatsApp. Send them sample progress reports via WhatsApp. Show them what a parent notification looks like on WhatsApp.

### Step 2: What to Show Them (Demo Script)

**Demo length: 10 minutes MAX. Owner has short attention span.**

**Scene 1: "Your current reality" (2 min)**
- Show a messy Excel sheet with student names, fees due, attendance marks
- Show a WhatsApp group with 200 messages
- Say: "This is what you're dealing with daily, right?"

**Scene 2: "What changes" (5 min)**
- **Fee tracking:** "Here's your dashboard. 47 students paid this month, 12 didn't. bKash auto-tracked. You can send reminder with one tap."
- **Attendance → Parent SMS:** "Student X was absent today. Parent got this SMS automatically. They'll feel you care."
- **Student progress:** "Student Y scored 65% in last mock test, up from 52% last month. Here's the report card — send to parent."
- **24/7 doubt support:** "Last night at 10 PM, a student asked about this chapter's problem. Got a hint (not full answer). You didn't have to wake up."

**Scene 3: "What this means for you" (3 min)**
- "Students who get regular feedback stay 40% longer."
- "Parents who see progress reports don't argue about fees."
- "Your teachers save 2 hours/week on admin work."
- "You can show new parents THIS dashboard when they come to enroll. 'We track your child's progress.' How many coaching centers can say that?"

### Step 3: Objection Handling

| Objection | Response |
|---|---|
| **"ChatGPT free, why should I pay?"** | "ChatGPT doesn't track YOUR students' progress. It doesn't send reports to parents. It doesn't manage your fees. This isn't ChatGPT — this is your coaching center's system." |
| **"My teachers won't use it"** | "Teachers don't need to learn anything new. They just teach like normal. The system runs in the background. Attendance via app takes 30 seconds." |
| **"Students have phones but they'll misuse it"** | "The student app only does study. No games, no social media. And you control what they see." |
| **"I can't afford software"** | "It's ৳[X]/month. That's less than your monthly photocopy cost. And it pays for itself if you retain even 2-3 extra students." |
| **"I'll think about it"** | "No problem. Let me leave you this demo account. Try it for a week with 5 students. If it doesn't save you time, forget it." |
| **"We're not tech-savvy"** | "Neither are we showing you tech. We're showing you a simpler way to do what you already do. If you can use bKash, you can use this." |

### Step 4: Pricing That Makes Sense in BD

**Tiered by center size:**

| Plan | Students | Monthly Price (৳) | Features |
|---|---|---|---|
| **Basic** | Up to 50 | 500 | Attendance, fee tracking, parent SMS |
| **Standard** | Up to 200 | 1,500 | + Progress reports, doubt support bot, mock tests |
| **Premium** | Up to 500 | 3,000 | + Parent portal, teacher analytics, marketing tools |
| **Chain/Multi-branch** | Unlimited | 5,000 | + Multi-branch dashboard, centralized reporting |

**Payment:** Monthly via bKash. No annual commitment. No contracts.

**Critical pricing principles for BD:**
- **Never ask for payment upfront** — First month free, then monthly.
- **Always compare to a familiar cost** — "Less than your monthly photocopy bill" or "Less than one student's monthly fee."
- **Let them see ROI before paying** — The free month MUST show measurable improvement (fees collected, students retained, time saved).
- **Never charge per-teacher** — Coaches share accounts. Charge per student or per-center.
- **Consider revenue share model for premium** — "Pay ৳1,000 base + ৳5 for every student who stays 3+ months." Aligns incentives.

### Step 5: What Happens After They Sign Up

**Week 1: Setup & Data Migration**
- Import student list (from Excel/WhatsApp). This is the hardest part — make it dead simple (CSV upload or even WhatsApp forwarding).
- Set up class schedules, teacher assignments.
- Train 1-2 people (usually the owner + one coordinator), NOT all teachers.

**Week 2: Soft Launch**
- Run attendance tracking alongside normal process.
- Send first parent SMS ("Your child attended class today").
- Enable doubt support for 1 batch only.

**Week 3-4: Full Activation**
- Activate progress reports.
- First mock test via system.
- First fee reminder automation.
- **Collect feedback obsessively.** Call the owner every 3 days.

**Month 2+: Optimization**
- Show the owner a dashboard: "Here's how many parents got SMS, how many students asked doubts, how many fees were auto-reminded."
- Help them use the progress reports for marketing ("We track your child's progress — enroll now!").
- Iterate on features based on what they actually use.

### Step 6: How to Retain Them Month After Month

**Retention = survival in BD SaaS. Here's how:**

1. **Weekly WhatsApp summary** — Auto-send the owner a summary: "This week: 89% attendance, ৳45,000 fees collected, 23 doubts resolved, 3 students improved scores." This makes the tool VISIBLE in their daily life.

2. **Make it harder to leave than to stay** — All their student data, fee records, and history is in the system. Leaving means going back to Excel. This is your moat.

3. **Feature drip** — Don't dump all features at once. Each month, introduce one new capability. "New feature: send exam results to parents automatically."

4. **Community** — Create a WhatsApp group of coaching center owners using your tool. They share tips, create peer pressure, and you get free feedback.

5. **Results = referrals** — If Student A's scores improve and the parent tells another parent, that coaching center gets a new student. The owner credits YOUR tool. This is how you grow organically.

6. **Annual price lock** — "Stay with us for a year, your price never increases." Important in a price-sensitive market.

7. **Celebrate their wins** — "Congrats, your 12 students got into BUET this year. Here's a case study we can share (with permission)." Coaching center owners are proud — feed that pride.

---

## 7. Risks & Honest Assessment

### Is This a Bad Market?

**Not bad. But hard. Here's why:**

#### Reasons it COULD fail:
1. **Long sales cycle** — Coaching center owners are cautious. Converting one might take 3-6 months of relationship building.
2. **Low willingness to pay** — Even ৳500/month is "expensive" for some owners. Churn from non-payment is real.
3. **Teacher resistance** — Teachers who are used to doing things their way might sabotage the tool ("I don't need this app").
4. **Copycat risk** — Once you prove the model, local developers can clone it cheaply. Bangladesh has plenty of developers willing to build for ৳50,000.
5. **Scale ceiling** — BD coaching centers are fragmented. Getting to 1,000+ centers requires feet-on-the-ground sales, not online marketing.
6. **Regulatory risk** — Government periodically restricts/controls coaching centers. A policy change could wipe out customers.

#### Reasons it COULD work:
1. **Massive, underserved market** — Tens of thousands of coaching centers, none using modern tools.
2. **Real pain, real willingness to solve it** — Fee collection and student retention are genuine daily problems.
3. **Low competition** — No B2B EdTech focused on coaching centers in BD.
4. **Word-of-mouth growth** — BD coaching community is tight. One happy owner tells five others.
5. **bKash infrastructure** — Payments are solved. No need for credit cards or bank transfers.
6. **WhatsApp ubiquity** — Distribution channel is free and universal.

### Honest Verdict

**Go for it IF:**
- You're willing to do hands-on, relationship-driven sales (not build-and-hope)
- You price at ৳800-2,000/month sweet spot
- You lead with operations (fees, attendance), not AI (tutoring)
- You can sustain 6-12 months of low revenue while building the customer base
- You're OK with a "boring" product that solves unsexy problems

**Don't do it IF:**
- You want to build a "cool AI product" — that's a vanity play, not a business
- You're looking for quick scale — this is slow, grinding growth
- You can't handle Bengali-language, WhatsApp-based, relationship-heavy sales
- You expect VCs to fund this — it's too unsexy and local for most BD/SEA VCs

---

## 8. Recommended Go-to-Market Strategy

### Phase 1: Validate (Month 1-3)
- Manually onboard 5 coaching centers for free
- Build ONLY: fee tracking + attendance + parent SMS
- Learn what they actually need (not what they say they need)
- Measure: Do they log in daily? Does retention improve?

### Phase 2: Monetize (Month 4-6)
- Convert free pilots to paid (৳500-1,000/month)
- Add doubt support bot (the "AI" feature, but not marketed as AI)
- Get to 20 paying centers
- Target: ৳50,000-1,00,000/month revenue

### Phase 3: Scale (Month 7-12)
- Hire 2-3 feet-on-the-ground salespeople (commission-based)
- Target Dhaka + Chittagong + Sylhet coaching clusters
- Add progress reports and mock test generation
- Target: 100-200 paying centers, ৳2-4 lakh/month revenue

### Phase 4: Expand (Year 2+)
- Add school-type coaching (tuition centers, not coaching centers)
- Explore teacher training/development as upsell
- Consider white-label for larger chains
- Explore adjacent markets (tutoring agencies, after-school programs)

---

## Key Takeaway

**The path to money is NOT: "AI tutor for BD students"** — ChatGPT already does this for free.

**The path to money IS: "Coaching center operating system"** — Automate the boring stuff, help students learn better, give parents confidence. The AI is invisible infrastructure, not the sales pitch.

The coaching center owner should buy it for the same reason they hire a good teacher — **because it makes their students score higher and their business run smoother.** Not because it's "AI."

---

*Analysis prepared for PinPoint market research. Data based on BD education market analysis, competitive landscape review, and coaching center ecosystem mapping.*
