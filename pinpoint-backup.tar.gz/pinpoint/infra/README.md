# PinPoint Infrastructure

**Zero-cost, self-hosted map infrastructure.** No Mapbox, no Google Maps — everything runs on your own servers using open-source tools.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Nginx (:80/443)                          │
│                   Reverse Proxy + Rate Limiting                 │
├─────────┬──────────┬──────────────┬──────────────┬──────────────┤
│         │          │              │              │              │
│   API   │  Tiles   │   Routing    │  Geocoding   │  Database    │
│  :3000  │  :8080   │    :5000     │    :7070     │   :5432      │
│         │          │              │              │              │
│ Node.js │  tileserver-gl    │     OSRM       │  Nominatim   │ PostGIS    │
│ Backend │  (vector tiles)   │  (directions)  │ (search)     │ (spatial)  │
└─────────┴──────────┴──────────────┴──────────────┴──────────────┘
```

### Components

| Service | Purpose | Technology |
|---------|---------|-----------|
| **PostGIS** | Spatial database | PostgreSQL 16 + PostGIS 3.4 |
| **Tile Server** | Serves vector/raster map tiles | [tileserver-gl](https://maptiler.com/tileserver-gl/) |
| **OSRM** | Driving directions & routing | [OSRM Backend](https://project-osrm.org/) |
| **Nominatim** | Geocoding (address → coordinates) | [Nominatim](https://nominatim.org/) |
| **API** | PinPoint backend | Your Node.js app |
| **Nginx** | Reverse proxy, SSL, rate limiting | Nginx Alpine |

## Prerequisites

- **Docker** 24+ and **Docker Compose** v2
- **50GB** free disk space (OSM data is large)
- **8GB RAM** recommended (4GB minimum)
- **Linux** server (Ubuntu 22.04 / Debian 12 recommended)
- Decent internet connection (~2GB download for data files)

## Quick Start (One Command)

```bash
git clone <your-repo> pinpoint
cd pinpoint/infra
bash scripts/setup.sh
```

This will:
1. ✅ Check prerequisites
2. ✅ Generate secure passwords in `.env`
3. ✅ Download Bangladesh OSM data (~500MB)
4. ✅ Generate vector tiles (~2GB)
5. ✅ Prepare routing data (~1.5GB)
6. ✅ Set up Nginx config
7. ✅ Start all services
8. ✅ Run health checks

**Time:** ~15-30 minutes (mostly data download + processing)

## Manual Setup

If you prefer step-by-step:

```bash
cd pinpoint/infra

# 1. Configure environment
cp .env.example .env
# Edit .env with your passwords and domain

# 2. Download and prepare map data
bash scripts/download-data.sh

# 3. Start services
docker compose up -d

# 4. Verify
bash scripts/health-check.sh
```

## Configuration

### Environment Variables (`.env`)

| Variable | Description | Example |
|----------|-------------|---------|
| `DB_PASSWORD` | PostgreSQL password | `auto-generated` |
| `NOMINATIM_PASSWORD` | Nominatim DB password | `auto-generated` |
| `JWT_SECRET` | API token signing secret | `auto-generated` |
| `DOMAIN` | Your domain for Nginx | `pinpoint.example.com` |
| `CERTBOT_EMAIL` | Email for Let's Encrypt | `admin@example.com` |

### Using a Different Country

Bangladesh is the default. To use another country:

1. **Edit `docker-compose.yml`:**
   - Change the `PBF_URL` in the nominatim service
   - Change the `--mbtiles` filename in the tileserver command
   - Change the `.osrm` path in the osrm command

2. **Edit `scripts/download-data.sh`:**
   - Change `COUNTRY` variable
   - Change `PBF_URL`

3. **Re-download data:**
   ```bash
   rm -rf data/ tiles/ osrm-data/
   bash scripts/download-data.sh
   ```

**Available regions:** Browse [Geofabrik](https://download.geofabrik.de/) for available regions.

## API Endpoints (via Nginx)

| Path | Service | Example |
|------|---------|---------|
| `/` | PinPoint API | `GET /health` |
| `/tiles/` | Tile Server | `GET /tiles/styles/osm-bright/style.json` |
| `/route/` | OSRM Routing | `GET /route/v1/driving/90.41,23.81;90.42,23.82` |
| `/geo/` | Nominatim | `GET /geo/search.php?q=Dhaka&format=json` |

### Example Requests

```bash
# Health check
curl http://localhost:3000/health

# Get route between two points (Dhaka)
curl 'http://localhost:5000/route/v1/driving/90.4125,23.8103;90.4200,23.8150?overview=full&geometries=geojson'

# Geocode an address
curl 'http://localhost:7070/search.php?q=Mirpur+Dhaka&format=json&limit=5'

# Reverse geocode
curl 'http://localhost:7070/reverse.php?lat=23.8103&lon=90.4125&format=json'

# Get map tiles
curl 'http://localhost:8080/styles/osm-bright/14/8726/6545.png'  # z/x/y
```

## Maintenance

### Health Monitoring

```bash
# Human-readable
bash scripts/health-check.sh

# JSON output (for monitoring tools)
bash scripts/health-check.sh --json
```

### Updating Map Data

Map data becomes stale as OpenStreetMap contributors add/edit data. Update weekly:

```bash
# Manual update
bash scripts/update-tiles.sh

# Automated (add to crontab)
0 3 * * 0 /path/to/pinpoint/infra/scripts/update-tiles.sh >> /var/log/pinpoint-tile-update.log 2>&1
```

### Database Backup

```bash
# Create backup
bash scripts/backup-db.sh

# Restore from backup
bash scripts/backup-db.sh --restore backups/pinpoint_20260101_020000.sql.gz

# Automated (add to crontab)
0 2 * * * /path/to/pinpoint/infra/scripts/backup-db.sh >> /var/log/pinpoint-backup.log 2>&1
```

### Logs

```bash
# All services
docker compose logs -f

# Specific service
docker compose logs -f tileserver
docker compose logs -f osrm
docker compose logs -f postgis
```

## Production Checklist

### Before Going Live

- [ ] Set strong passwords in `.env` (auto-generated by setup.sh)
- [ ] Set `DOMAIN` to your actual domain
- [ ] Point DNS A records to your server IP:
  - `api.pinpoint.yourdomain.com`
  - `tiles.pinpoint.yourdomain.com`
  - `route.pinpoint.yourdomain.com`
  - `geo.pinpoint.yourdomain.com`
- [ ] Run `bash scripts/setup-ssl.sh` for HTTPS
- [ ] Configure firewall (only expose ports 80, 443)
- [ ] Set up automated backups (cron)
- [ ] Set up automated tile updates (cron)
- [ ] Set up monitoring/alerting

### Security

- [ ] Change default PostgreSQL port exposure (remove `5432:5432` from docker-compose.yml)
- [ ] Enable UFW or iptables firewall
- [ ] Set up fail2ban for SSH
- [ ] Disable root SSH login
- [ ] Enable automatic security updates

### Firewall Rules

```bash
# UFW (Ubuntu/Debian)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable
```

### Automated Backups

```bash
# Add to crontab: crontab -e
# Daily backup at 2 AM
0 2 * * * cd /path/to/pinpoint/infra && bash scripts/backup-db.sh >> /var/log/pinpoint-backup.log 2>&1

# Weekly tile update at 3 AM Sunday
0 3 * * 0 cd /path/to/pinpoint/infra && bash scripts/update-tiles.sh >> /var/log/pinpoint-tile-update.log 2>&1
```

### Log Rotation

Docker handles log rotation by default, but for additional logs:

```bash
# /etc/logrotate.d/pinpoint
/var/log/pinpoint-*.log {
    weekly
    rotate 4
    compress
    missingok
    notifempty
}
```

## Estimated Costs

| Provider | Plan | Specs | Monthly Cost |
|----------|------|-------|-------------|
| **Hetzner** | CX31 | 4 vCPU, 8GB RAM, 80GB SSD | ~€4.50 (~$5) |
| **Hetzner** | CX41 | 8 vCPU, 16GB RAM, 160GB SSD | ~€8.50 (~$9) |
| **DigitalOcean** | Basic | 4 vCPU, 8GB RAM, 160GB SSD | ~$48 |
| **Vultr** | Cloud Compute | 4 vCPU, 8GB RAM, 160GB SSD | ~$48 |
| **Contabo** | VPS M | 6 vCPU, 16GB RAM, 200GB SSD | ~€6.50 (~$7) |

**Recommendation:** Hetzner CX31 or CX41 for best price/performance in the region.

**Disk usage breakdown:**
- OSM PBF: ~500MB
- MBTiles: ~2-3GB
- OSRM data: ~1-2GB
- PostGIS: ~500MB
- Nominatim: ~5-10GB
- **Total: ~10-15GB** (80GB disk gives plenty of headroom)

## Troubleshooting

### Nominatim import takes forever
Nominatim's first import is slow. For Bangladesh, expect 20-60 minutes depending on hardware. The health check has a 120s startup period.

### OSRM extract runs out of memory
Increase Docker memory limit, or use a machine with more RAM. OSRM extraction for Bangladesh needs ~4GB.

### Tiles not loading
Check that `bangladesh.mbtiles` exists in `tiles/`:
```bash
ls -lh tiles/
docker compose logs tileserver
```

### Port conflicts
If ports 80/443 are in use, edit `docker-compose.yml` nginx ports or stop conflicting services:
```bash
sudo ss -tlnp | grep ':80\|:443'
```

### Database won't start
```bash
docker compose logs postgis
# If corrupt: docker compose down -v && docker compose up -d
# WARNING: -v deletes the volume (data loss)
```

## File Structure

```
infra/
├── docker-compose.yml          # Main orchestration
├── .env.example                # Environment template
├── .env                        # Your secrets (git-ignored)
├── README.md                   # This file
├── data/                       # Downloaded OSM PBF files
├── tiles/                      # Generated MBTiles
├── osrm-data/                  # OSRM routing data
├── backups/                    # Database backups
├── init-db/
│   └── 01-extensions.sql       # PostGIS setup (runs on first boot)
├── nginx/
│   ├── nginx.conf              # Main Nginx config
│   ├── conf.d/
│   │   └── pinpoint.conf       # Routing rules
│   └── ssl/                    # Let's Encrypt certificates
└── scripts/
    ├── setup.sh                # One-command setup
    ├── download-data.sh        # Download + prepare OSM data
    ├── update-tiles.sh         # Weekly data refresh
    ├── health-check.sh         # Service health monitor
    ├── backup-db.sh            # Database backup/restore
    └── setup-ssl.sh            # Let's Encrypt SSL setup
```

## License

MIT — use it however you want.
