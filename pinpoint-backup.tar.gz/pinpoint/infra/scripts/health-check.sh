#!/usr/bin/env bash
###############################################################################
# health-check.sh — Monitor all PinPoint services
#
# Pings each service and reports its status. Exit code 0 = all healthy.
#
# Usage:
#   bash scripts/health-check.sh          # human-readable output
#   bash scripts/health-check.sh --json   # JSON output for monitoring tools
#
# Schedule with cron for periodic checks:
#   */5 * * * * /path/to/health-check.sh --json >> /var/log/pinpoint-health.log
###############################################################################
set -euo pipefail

# ── Configuration ───────────────────────────────────────────────────────────
# Override with environment variables if needed
API_URL="${PINPOINT_API_URL:-http://localhost:3000}"
TILES_URL="${PINPOINT_TILES_URL:-http://localhost:8080}"
OSRM_URL="${PINPOINT_OSRM_URL:-http://localhost:5000}"
NOMINATIM_URL="${PINPOINT_NOMINATIM_URL:-http://localhost:7070}"
POSTGRES_HOST="${PINPOINT_PG_HOST:-localhost}"
POSTGRES_PORT="${PINPOINT_PG_PORT:-5432}"

JSON_MODE=false
[[ "${1:-}" == "--json" ]] && JSON_MODE=true

# ── Health checks ──────────────────────────────────────────────────────────
check_service() {
    local name="$1"
    local url="$2"
    local timeout="${3:-5}"

    local status="down"
    local http_code=0

    if http_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time "$timeout" "$url" 2>/dev/null); then
        if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 400 ]; then
            status="up"
        fi
    fi

    echo "${name}:${status}:${http_code}"
}

check_postgres() {
    local name="postgis"
    local status="down"

    # Use pg_isready if available, otherwise try TCP connection
    if command -v pg_isready >/dev/null 2>&1; then
        if pg_isready -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -q 2>/dev/null; then
            status="up"
        fi
    elif timeout 5 bash -c "echo > /dev/tcp/${POSTGRES_HOST}/${POSTGRES_PORT}" 2>/dev/null; then
        status="up"
    fi

    echo "${name}:${status}:0"
}

# ── Run checks ─────────────────────────────────────────────────────────────
RESULTS=()
ALL_HEALTHY=true

# PostGIS (TCP check)
result=$(check_postgres)
RESULTS+=("$result")
[[ "$result" == *":up:"* ]] || ALL_HEALTHY=false

# Tile Server
result=$(check_service "tileserver" "${TILES_URL}/health")
RESULTS+=("$result")
[[ "$result" == *":up:"* ]] || ALL_HEALTHY=false

# OSRM (test a simple route)
result=$(check_service "osrm" "${OSRM_URL}/route/v1/driving/90.4125,23.8103;90.4126,23.8104?overview=false")
RESULTS+=("$result")
[[ "$result" == *":up:"* ]] || ALL_HEALTHY=false

# Nominatim (test a search query)
result=$(check_service "nominatim" "${NOMINATIM_URL}/search.php?q=Dhaka&format=json")
RESULTS+=("$result")
[[ "$result" == *":up:"* ]] || ALL_HEALTHY=false

# API
result=$(check_service "api" "${API_URL}/health" 10)
RESULTS+=("$result")
[[ "$result" == *":up:"* ]] || ALL_HEALTHY=false

# ── Output ─────────────────────────────────────────────────────────────────
if $JSON_MODE; then
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    echo "{"
    echo "  \"timestamp\": \"${timestamp}\","
    echo "  \"healthy\": ${ALL_HEALTHY},"
    echo "  \"services\": {"
    first=true
    for r in "${RESULTS[@]}"; do
        IFS=':' read -r name status code <<< "$r"
        $first || echo ","
        echo "    \"${name}\": {\"status\": \"${status}\", \"http_code\": ${code}}"
        first=false
    done
    echo ""
    echo "  }"
    echo "}"
else
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║           PinPoint Infrastructure Health Check              ║"
    echo "║           $(date '+%Y-%m-%d %H:%M:%S %Z')                    ║"
    echo "╠══════════════════════════════════════════════════════════════╣"

    for r in "${RESULTS[@]}"; do
        IFS=':' read -r name status code <<< "$r"
        if [ "$status" = "up" ]; then
            icon="✅"
        else
            icon="❌"
        fi
        printf "║  %-15s  %s  %-8s" "$name" "$icon" "$status"
        [ "$code" != "0" ] && printf " (HTTP %s)" "$code"
        echo ""
    done

    echo "╠══════════════════════════════════════════════════════════════╣"
    if $ALL_HEALTHY; then
        echo "║  Overall: ✅ All services healthy                           ║"
    else
        echo "║  Overall: ❌ Some services are down                         ║"
    fi
    echo "╚══════════════════════════════════════════════════════════════╝"
fi

$ALL_HEALTHY && exit 0 || exit 1
