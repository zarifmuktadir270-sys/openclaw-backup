#!/usr/bin/env bash
###############################################################################
# download-data.sh — Download Bangladesh OSM data and prepare tiles + routing
#
# Prerequisites: Docker, ~50GB free disk space, decent internet connection
# Duration: ~10-30 minutes depending on connection speed
#
# This script:
#   1. Downloads the Bangladesh .osm.pbf file from Geofabrik (~500MB)
#   2. Generates MBTiles for the vector tile server (~2GB)
#   3. Extracts + partitions + customizes OSRM routing data (~1.5GB)
#
# To use a different country:
#   1. Change PBF_URL in .env and docker-compose.yml
#   2. Change the filenames in this script
#   3. Change the --mbtiles and --osrm paths in docker-compose.yml
#
# Geofabrik download index: https://download.geofabrik.de/
###############################################################################
set -euo pipefail

# ── Configuration ───────────────────────────────────────────────────────────
# Change these to target a different country
COUNTRY="bangladesh"
PBF_URL="https://download.geofabrik.de/asia/${COUNTRY}-latest.osm.pbf"

DATA_DIR="./data"
TILES_DIR="./tiles"
OSRM_DIR="./osrm-data"
PBF_FILE="${DATA_DIR}/${COUNTRY}-latest.osm.pbf"

# Colors for pretty output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log()  { echo -e "${GREEN}[✓]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[✗]${NC} $*" >&2; }

# ── Pre-flight checks ──────────────────────────────────────────────────────
command -v docker >/dev/null 2>&1 || { err "Docker is not installed. Aborting."; exit 1; }
command -v wget  >/dev/null 2>&1 || command -v curl >/dev/null 2>&1 || { err "wget or curl required. Aborting."; exit 1; }

# ── Create directories ─────────────────────────────────────────────────────
mkdir -p "$DATA_DIR" "$TILES_DIR" "$OSRM_DIR"
log "Directories ready: ${DATA_DIR}, ${TILES_DIR}, ${OSRM_DIR}"

# ── Step 1: Download OSM data ──────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  Step 1/3: Downloading Bangladesh OSM data"
echo "  Source: ${PBF_URL}"
echo "  Size:   ~500MB"
echo "═══════════════════════════════════════════════════════════════"

if [ -f "$PBF_FILE" ]; then
    warn "PBF file already exists: ${PBF_FILE}"
    warn "Skipping download (delete the file to force re-download)"
else
    if command -v wget >/dev/null 2>&1; then
        wget -c --progress=bar:force "$PBF_URL" -O "$PBF_FILE"
    else
        curl -L -C - --progress-bar "$PBF_URL" -o "$PBF_FILE"
    fi
    log "Downloaded: ${PBF_FILE} ($(du -h "$PBF_FILE" | cut -f1))"
fi

# ── Step 2: Generate MBTiles ───────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  Step 2/3: Generating MBTiles for tile server"
echo "  Using Planetiler (this may take 5-15 minutes)"
echo "═══════════════════════════════════════════════════════════════"

if [ -f "${TILES_DIR}/${COUNTRY}.mbtiles" ]; then
    warn "MBTiles already exist. Skipping generation."
    warn "Delete ${TILES_DIR}/${COUNTRY}.mbtiles to regenerate."
else
    docker run --rm \
        -v "$(pwd)/${DATA_DIR}:/data" \
        -v "$(pwd)/${TILES_DIR}:/output" \
        ghcr.io/onthegomap/planetiler:latest \
        --download \
        --area="${COUNTRY}" \
        --output="/output/${COUNTRY}.mbtiles"

    log "MBTiles generated: ${TILES_DIR}/${COUNTRY}.mbtiles ($(du -h "${TILES_DIR}/${COUNTRY}.mbtiles" | cut -f1))"
fi

# ── Step 3: Prepare OSRM routing data ──────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  Step 3/3: Preparing OSRM routing data"
echo "  Extract → Partition → Customize (may take 10-20 minutes)"
echo "═══════════════════════════════════════════════════════════════"

OSRM_PREFIX="${OSRM_DIR}/${COUNTRY}-latest.osrm"

if [ -f "${OSRM_PREFIX}.osrm.ebg" ]; then
    warn "OSRM data already prepared. Skipping."
    warn "Delete ${OSRM_DIR}/ to regenerate."
else
    log "Extracting road network..."
    docker run --rm \
        -v "$(pwd)/${DATA_DIR}:/data" \
        -v "$(pwd)/${OSRM_DIR}:/output" \
        ghcr.io/project-osrm/osrm-backend:latest \
        osrm-extract -p /opt/car.lua "/data/${COUNTRY}-latest.osm.pbf"

    # osrm-extract outputs to the same directory as the input file
    # Move the .osrm files to our OSRM_DIR
    mv "${DATA_DIR}/${COUNTRY}-latest.osrm"* "${OSRM_DIR}/" 2>/dev/null || true

    log "Partitioning for MLD algorithm..."
    docker run --rm \
        -v "$(pwd)/${OSRM_DIR}:/data" \
        ghcr.io/project-osrm/osrm-backend:latest \
        osrm-partition "/data/${COUNTRY}-latest.osrm"

    log "Customizing edge weights..."
    docker run --rm \
        -v "$(pwd)/${OSRM_DIR}:/data" \
        ghcr.io/project-osrm/osrm-backend:latest \
        osrm-customize "/data/${COUNTRY}-latest.osrm"

    log "OSRM data ready: ${OSRM_DIR}/"
fi

# ── Summary ────────────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  Data preparation complete!"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "  Files:"
echo "    PBF:    ${PBF_FILE} ($(du -h "$PBF_FILE" | cut -f1))"
echo "    Tiles:  ${TILES_DIR}/${COUNTRY}.mbtiles ($(du -h "${TILES_DIR}/${COUNTRY}.mbtiles" | cut -f1))"
echo "    OSRM:   ${OSRM_DIR}/ ($(du -sh "$OSRM_DIR" | cut -f1))"
echo ""
echo "  Total disk used: $(du -sh "$DATA_DIR" "$TILES_DIR" "$OSRM_DIR" | awk '{sum+=$1} END {print sum "MB"}')"
echo ""
echo "  Next steps:"
echo "    1. cp .env.example .env  # edit with your passwords"
echo "    2. docker compose up -d"
echo "    3. bash scripts/health-check.sh"
echo ""
