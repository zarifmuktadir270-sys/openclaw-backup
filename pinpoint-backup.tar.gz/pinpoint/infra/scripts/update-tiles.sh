#!/usr/bin/env bash
###############################################################################
# update-tiles.sh — Weekly data refresh for PinPoint map infrastructure
#
# Keeps OSM map data up-to-date by:
#   1. Downloading the latest .osm.pbf (with diff updates)
#   2. Regenerating MBTiles for the tile server
#   3. Re-extracting and preparing OSRM routing data
#   4. Restarting affected services
#
# Schedule with cron (run every Sunday at 3 AM):
#   crontab -e
#   0 3 * * 0 /path/to/pinpoint/infra/scripts/update-tiles.sh >> /var/log/pinpoint-tile-update.log 2>&1
#
# Alternatively, use a systemd timer for better logging.
###############################################################################
set -euo pipefail

# ── Configuration ───────────────────────────────────────────────────────────
COUNTRY="bangladesh"
PBF_URL="https://download.geofabrik.de/asia/${COUNTRY}-latest.osm.pbf"

INFRA_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DATA_DIR="${INFRA_DIR}/data"
TILES_DIR="${INFRA_DIR}/tiles"
OSRM_DIR="${INFRA_DIR}/osrm-data"
PBF_FILE="${DATA_DIR}/${COUNTRY}-latest.osm.pbf"

LOCK_FILE="/tmp/pinpoint-tile-update.lock"
LOG_PREFIX="[pinpoint-update $(date '+%Y-%m-%d %H:%M:%S')]"

# ── Prevent concurrent runs ────────────────────────────────────────────────
exec 200>"$LOCK_FILE"
flock -n 200 || { echo "${LOG_PREFIX} Another update is running. Exiting."; exit 0; }

log()  { echo "${LOG_PREFIX} $*"; }
err()  { echo "${LOG_PREFIX} ERROR: $*" >&2; }

log "Starting tile data update for ${COUNTRY}..."

# ── Step 1: Download latest PBF ────────────────────────────────────────────
log "Downloading latest OSM data..."
wget -q --show-progress -c "$PBF_URL" -O "${PBF_FILE}.new"

# Only replace if download succeeded and file is valid (> 10MB)
if [ -f "${PBF_FILE}.new" ] && [ "$(stat -c%s "${PBF_FILE}.new")" -gt 10000000 ]; then
    mv "${PBF_FILE}.new" "$PBF_FILE"
    log "PBF updated: ${PBF_FILE} ($(du -h "$PBF_FILE" | cut -f1))"
else
    err "Download failed or file too small. Aborting update."
    rm -f "${PBF_FILE}.new"
    exit 1
fi

# ── Step 2: Regenerate MBTiles ─────────────────────────────────────────────
log "Regenerating MBTiles..."
rm -f "${TILES_DIR}/${COUNTRY}.mbtiles"

docker run --rm \
    -v "${DATA_DIR}:/data" \
    -v "${TILES_DIR}:/output" \
    ghcr.io/onthegomap/planetiler:latest \
    --area="${COUNTRY}" \
    --output="/output/${COUNTRY}.mbtiles"

log "MBTiles regenerated."

# ── Step 3: Re-extract OSRM data ───────────────────────────────────────────
log "Re-extracting OSRM routing data..."
rm -f "${OSRM_DIR}/${COUNTRY}-latest.osrm"*

docker run --rm \
    -v "${DATA_DIR}:/data" \
    -v "${OSRM_DIR}:/output" \
    ghcr.io/project-osrm/osrm-backend:latest \
    osrm-extract -p /opt/car.lua "/data/${COUNTRY}-latest.osm.pbf"

mv "${DATA_DIR}/${COUNTRY}-latest.osrm"* "${OSRM_DIR}/" 2>/dev/null || true

log "Partitioning..."
docker run --rm \
    -v "${OSRM_DIR}:/data" \
    ghcr.io/project-osrm/osrm-backend:latest \
    osrm-partition "/data/${COUNTRY}-latest.osrm"

log "Customizing..."
docker run --rm \
    -v "${OSRM_DIR}:/data" \
    ghcr.io/project-osrm/osrm-backend:latest \
    osrm-customize "/data/${COUNTRY}-latest.osrm"

log "OSRM data refreshed."

# ── Step 4: Restart affected services ──────────────────────────────────────
log "Restarting tile server and OSRM..."
cd "$INFRA_DIR"
docker compose restart tileserver osrm

# Wait for health checks
sleep 10

# ── Step 5: Verify ─────────────────────────────────────────────────────────
TILES_OK=false
OSRM_OK=false

if wget -qO- "http://localhost:8080/health" >/dev/null 2>&1; then
    TILES_OK=true
fi

if wget -qO- "http://localhost:5000/route/v1/driving/90.4125,23.8103;90.4126,23.8104?overview=false" >/dev/null 2>&1; then
    OSRM_OK=true
fi

if $TILES_OK && $OSRM_OK; then
    log "Update complete. All services healthy. ✅"
else
    err "Update finished but health checks failed:"
    $TILES_OK || err "  - Tile server not responding"
    $OSRM_OK || err "  - OSRM not responding"
    exit 1
fi
