#!/usr/bin/env bash
###############################################################################
# backup-db.sh — Automated PostgreSQL backup for PinPoint
#
# Creates compressed backups of the PostGIS database and keeps the last N days.
#
# Usage:
#   bash scripts/backup-db.sh              # manual backup
#   bash scripts/backup-db.sh --restore <file>  # restore from backup
#
# Schedule with cron:
#   0 2 * * * /path/to/backup-db.sh >> /var/log/pinpoint-backup.log 2>&1
###############################################################################
set -euo pipefail

INFRA_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BACKUP_DIR="${INFRA_DIR}/backups"
KEEP_DAYS=7  # Keep backups for 7 days

source "${INFRA_DIR}/.env" 2>/dev/null || { echo "ERROR: .env not found"; exit 1; }

mkdir -p "$BACKUP_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="${BACKUP_DIR}/pinpoint_${TIMESTAMP}.sql.gz"

# ── Restore mode ───────────────────────────────────────────────────────────
if [[ "${1:-}" == "--restore" ]]; then
    RESTORE_FILE="${2:-}"
    if [ -z "$RESTORE_FILE" ] || [ ! -f "$RESTORE_FILE" ]; then
        echo "Usage: $0 --restore <backup_file.sql.gz>"
        echo ""
        echo "Available backups:"
        ls -lh "$BACKUP_DIR"/*.sql.gz 2>/dev/null || echo "  (none)"
        exit 1
    fi

    echo "Restoring from: ${RESTORE_FILE}"
    read -r -p "This will OVERWRITE the current database. Continue? [y/N] " confirm
    [[ "$confirm" =~ ^[Yy]$ ]] || exit 0

    if [[ "$RESTORE_FILE" == *.gz ]]; then
        gunzip -c "$RESTORE_FILE" | docker exec -i pinpoint-postgis psql -U pinpoint -d pinpoint
    else
        docker exec -i pinpoint-postgis psql -U pinpoint -d pinpoint < "$RESTORE_FILE"
    fi

    echo "Restore complete."
    exit 0
fi

# ── Backup mode ────────────────────────────────────────────────────────────
echo "[$(date)] Starting backup..."

# Dump database (compressed)
docker exec pinpoint-postgis pg_dump -U pinpoint -d pinpoint --format=custom | gzip > "$BACKUP_FILE"

BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
echo "[$(date)] Backup created: ${BACKUP_FILE} (${BACKUP_SIZE})"

# ── Cleanup old backups ────────────────────────────────────────────────────
DELETED=$(find "$BACKUP_DIR" -name "*.sql.gz" -mtime +${KEEP_DAYS} -delete -print | wc -l)
if [ "$DELETED" -gt 0 ]; then
    echo "[$(date)] Cleaned up ${DELETED} old backup(s)"
fi

echo "[$(date)] Backup complete. Total backups: $(ls "$BACKUP_DIR"/*.sql.gz 2>/dev/null | wc -l)"
