#!/usr/bin/env bash
###############################################################################
# setup.sh — One-command PinPoint infrastructure setup
#
# This script does EVERYTHING:
#   1. Checks prerequisites (Docker, Docker Compose, disk space)
#   2. Creates .env from template if missing
#   3. Downloads OSM data for Bangladesh
#   4. Generates MBTiles for the tile server
#   5. Prepares OSRM routing data
#   6. Sets up Nginx config
#   7. Creates database initialization scripts
#   8. Starts all services
#   9. Runs health checks
#
# Usage:
#   cd pinpoint/infra
#   bash scripts/setup.sh
#
# Time: ~15-30 minutes (mostly data download + processing)
# Disk: ~50GB free recommended (will use ~10-15GB)
###############################################################################
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INFRA_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "$INFRA_DIR"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
BOLD='\033[1m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[✗]${NC} $*" >&2; }
step() { echo -e "\n${BLUE}${BOLD}═══════════════════════════════════════════════════════════${NC}"; echo -e "${BLUE}${BOLD}  $*${NC}"; echo -e "${BLUE}${BOLD}═══════════════════════════════════════════════════════════${NC}\n"; }

echo -e "${BOLD}"
echo "  ╔═══════════════════════════════════════════════════╗"
echo "  ║           PinPoint Infrastructure Setup           ║"
echo "  ║           Self-hosted • Open Source • Zero Cost   ║"
echo "  ╚═══════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── Step 1: Prerequisites ──────────────────────────────────────────────────
step "Step 1/8: Checking prerequisites"

# Docker
if ! command -v docker >/dev/null 2>&1; then
    err "Docker is not installed."
    echo "  Install it: https://docs.docker.com/engine/install/"
    exit 1
fi
log "Docker found: $(docker --version)"

# Docker Compose (v2 plugin or standalone)
DOCKER_COMPOSE="docker compose"
if ! docker compose version >/dev/null 2>&1; then
    if command -v docker-compose >/dev/null 2>&1; then
        DOCKER_COMPOSE="docker-compose"
    else
        err "Docker Compose not found."
        echo "  Install: https://docs.docker.com/compose/install/"
        exit 1
    fi
fi
log "Docker Compose found"

# Disk space (need at least 20GB free)
AVAIL_GB=$(df -BG --output=avail "$INFRA_DIR" | tail -1 | tr -d ' G')
if [ "$AVAIL_GB" -lt 20 ]; then
    warn "Only ${AVAIL_GB}GB free. Recommended: 50GB+"
    read -r -p "Continue anyway? [y/N] " response
    [[ "$response" =~ ^[Yy]$ ]] || exit 0
else
    log "Disk space: ${AVAIL_GB}GB available ✓"
fi

# Memory (recommend 4GB+)
TOTAL_MEM_MB=$(free -m | awk '/^Mem:/{print $2}')
if [ "$TOTAL_MEM_MB" -lt 3000 ]; then
    warn "Only ${TOTAL_MEM_MB}MB RAM. Recommended: 8GB+ for smooth operation."
else
    log "RAM: ${TOTAL_MEM_MB}MB available ✓"
fi

# ── Step 2: Environment setup ──────────────────────────────────────────────
step "Step 2/8: Setting up environment"

if [ ! -f .env ]; then
    cp .env.example .env

    # Generate secure random passwords
    DB_PASS=$(openssl rand -hex 16)
    NOMINATIM_PASS=$(openssl rand -hex 16)
    JWT_SECRET_VAL=$(openssl rand -hex 32)

    # Replace placeholders in .env
    sed -i "s/changeme_use_a_strong_random_password/${DB_PASS}/" .env
    sed -i "s/changeme_nominatim_password/${NOMINATIM_PASS}/" .env
    sed -i "s/changeme_generate_with_openssl_rand_hex_32/${JWT_SECRET_VAL}/" .env

    log "Created .env with auto-generated passwords"
    warn "Edit .env to set your DOMAIN and CERTBOT_EMAIL for production"
else
    log ".env already exists — using existing configuration"
fi

# ── Step 3: Create directory structure ─────────────────────────────────────
step "Step 3/8: Creating directory structure"

mkdir -p data tiles osrm-data nginx/conf.d nginx/ssl init-db
log "Directories created"

# Make scripts executable
chmod +x scripts/*.sh
log "Scripts made executable"

# ── Step 4: Database initialization ────────────────────────────────────────
step "Step 4/8: Creating database initialization scripts"

# Create init script that enables PostGIS extensions
cat > init-db/01-extensions.sql << 'SQLEOF'
-- PinPoint Database Initialization
-- This runs automatically on first PostgreSQL startup

-- Enable PostGIS extensions
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;
CREATE EXTENSION IF NOT EXISTS postgis_sfcgal;
CREATE EXTENSION IF NOT EXISTS fuzzystrmatch;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Create application schema
CREATE SCHEMA IF NOT EXISTS pinpoint;

-- Spatial indexes will be created by the application migrations
-- but we set up the foundation here.

COMMENT ON DATABASE pinpoint IS 'PinPoint — Self-hosted map infrastructure';
SQLEOF
log "Database init script created"

# ── Step 5: Nginx configuration ────────────────────────────────────────────
step "Step 5/8: Generating Nginx configuration"

# Main nginx.conf
cat > nginx/nginx.conf << 'NGINXEOF'
###############################################################################
# PinPoint — Nginx Reverse Proxy Configuration
#
# Routes:
#   /              → PinPoint API (port 3000)
#   /tiles/        → Tile server (port 8080)
#   /route/        → OSRM routing (port 5000)
#   /search/       → Nominatim geocoding (port 7070)
#
# For subdomain-based routing, see conf.d/ files.
# For production, enable HTTPS by running: bash scripts/setup-ssl.sh
###############################################################################
user  nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid       /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    # Logging format
    log_format main '$remote_addr - $remote_user [$time_local] '
                    '"$request" $status $body_bytes_sent '
                    '"$http_referer" "$http_user_agent" '
                    'rt=$request_time';

    access_log /var/log/nginx/access.log main;

    sendfile        on;
    tcp_nopush      on;
    keepalive_timeout 65;

    # Gzip compression for tiles and API responses
    gzip on;
    gzip_types application/json application/x-protobuf application/javascript text/css;
    gzip_min_length 1000;

    # Rate limiting (protect against abuse)
    limit_req_zone $binary_remote_addr zone=api:10m rate=30r/s;
    limit_req_zone $binary_remote_addr zone=tiles:10m rate=100r/s;

    # Include site configs
    include /etc/nginx/conf.d/*.conf;
}
NGINXEOF

# Site config — path-based routing (single domain)
cat > nginx/conf.d/pinpoint.conf << 'SITEEOF'
###############################################################################
# PinPoint — Path-based routing (default setup)
#
# Uses a single domain with path prefixes:
#   pinpoint.yourdomain.com/       → API
#   pinpoint.yourdomain.com/tiles/ → Tile server
#   pinpoint.yourdomain.com/route/ → OSRM
#   pinpoint.yourdomain.com/geo/   → Nominatim
#
# For subdomain routing, disable this file and use subdomains.conf instead.
###############################################################################

upstream api {
    server api:3000;
}

upstream tileserver {
    server tileserver:8080;
}

upstream osrm {
    server osrm:5000;
}

upstream nominatim {
    server nominatim:8080;
}

server {
    listen 80;
    server_name _;

    # ── API (default) ──────────────────────────────────────────────────────
    location / {
        limit_req zone=api burst=20 nodelay;

        proxy_pass http://api;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket support (if needed for live tracking)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # ── Tile Server ────────────────────────────────────────────────────────
    location /tiles/ {
        limit_req zone=tiles burst=50 nodelay;

        proxy_pass http://tileserver/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;

        # Cache tiles aggressively (they don't change often)
        proxy_cache_valid 200 7d;
        add_header X-Cache-Status $upstream_cache_status;
        add_header Access-Control-Allow-Origin *;

        # Tiles can be large
        client_max_body_size 50m;
    }

    # ── OSRM Routing ───────────────────────────────────────────────────────
    location /route/ {
        limit_req zone=api burst=20 nodelay;

        proxy_pass http://osrm/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;

        add_header Access-Control-Allow-Origin *;
    }

    # ── Nominatim Geocoding ────────────────────────────────────────────────
    location /geo/ {
        limit_req zone=api burst=20 nodelay;

        proxy_pass http://nominatim/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;

        add_header Access-Control-Allow-Origin *;
    }

    # ── Health check endpoint ──────────────────────────────────────────────
    location /health {
        access_log off;
        return 200 '{"status":"ok","service":"pinpoint-nginx"}';
        add_header Content-Type application/json;
    }
}
SITEEOF

log "Nginx configuration created"

# ── Step 6: Download and prepare map data ──────────────────────────────────
step "Step 6/8: Downloading and preparing map data"
echo -e "${YELLOW}This is the longest step (~10-30 minutes)${NC}"
echo ""

bash scripts/download-data.sh

# ── Step 7: Start services ─────────────────────────────────────────────────
step "Step 7/8: Starting all services"

$DOCKER_COMPOSE up -d

echo ""
log "Waiting for services to initialize (30 seconds)..."
sleep 30

# ── Step 8: Health check ───────────────────────────────────────────────────
step "Step 8/8: Running health checks"

# Give services more time to start
log "Waiting for all services to be ready..."
for i in $(seq 1 12); do
    if bash scripts/health-check.sh 2>/dev/null; then
        break
    fi
    echo "  Waiting... ($((i * 10))s)"
    sleep 10
done

# Final health check
bash scripts/health-check.sh || warn "Some services may still be starting. Run health-check.sh again in a minute."

# ── Summary ────────────────────────────────────────────────────────────────
step "Setup Complete! 🎉"

source .env 2>/dev/null || true

echo "  PinPoint is running at:"
echo ""
echo "    📍 API:        http://localhost:3000"
echo "    🗺️  Tiles:      http://localhost:8080"
echo "    🚗 Routing:    http://localhost:5000"
echo "    📌 Geocoding:  http://localhost:7070"
echo "    🌐 Nginx:      http://localhost:80"
echo ""
echo "  Database:"
echo "    Host: localhost:5432"
echo "    Name: pinpoint"
echo "    User: pinpoint"
echo ""
echo "  Quick test:"
echo "    curl http://localhost:3000/health"
echo "    curl 'http://localhost:5000/route/v1/driving/90.4125,23.8103;90.4200,23.8150?overview=false'"
echo "    curl 'http://localhost:7070/search.php?q=Dhaka&format=json'"
echo ""
echo "  For production:"
echo "    1. Set DOMAIN and CERTBOT_EMAIL in .env"
echo "    2. Point DNS to this server"
echo "    3. bash scripts/setup-ssl.sh"
echo ""
echo "  Maintenance:"
echo "    Health check:  bash scripts/health-check.sh"
echo "    Update tiles:  bash scripts/update-tiles.sh"
echo "    View logs:     docker compose logs -f"
echo "    Stop all:      docker compose down"
echo ""
