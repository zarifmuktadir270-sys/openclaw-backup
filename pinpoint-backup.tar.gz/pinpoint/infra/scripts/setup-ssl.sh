#!/usr/bin/env bash
###############################################################################
# setup-ssl.sh — Set up Let's Encrypt SSL certificates for PinPoint
#
# Prerequisites:
#   - Domain DNS pointed to this server
#   - Ports 80 and 443 open
#   - .env file with DOMAIN and CERTBOT_EMAIL set
#
# Usage:
#   bash scripts/setup-ssl.sh
###############################################################################
set -euo pipefail

INFRA_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$INFRA_DIR"

source .env

if [ -z "${DOMAIN:-}" ] || [ "$DOMAIN" = "pinpoint.yourdomain.com" ]; then
    echo "ERROR: Set DOMAIN in .env to your actual domain before running this script."
    exit 1
fi

if [ -z "${CERTBOT_EMAIL:-}" ] || [ "$CERTBOT_EMAIL" = "admin@yourdomain.com" ]; then
    echo "ERROR: Set CERTBOT_EMAIL in .env to your actual email."
    exit 1
fi

echo "Setting up SSL for: ${DOMAIN}"

# Create SSL directory
mkdir -p nginx/ssl

# Use certbot in Docker to get certificates
SUBDOMAINS=("api" "tiles" "route" "geo")
DOMAIN_ARGS="-d ${DOMAIN}"

for sub in "${SUBDOMAINS[@]}"; do
    DOMAIN_ARGS="${DOMAIN_ARGS} -d ${sub}.${DOMAIN}"
done

echo "Requesting certificates for: ${DOMAIN} and subdomains"

docker run --rm -it \
    -v "$(pwd)/nginx/ssl:/etc/letsencrypt" \
    -v "$(pwd)/nginx/ssl-challenge:/var/www/certbot" \
    -p 80:80 \
    certbot/certbot certonly \
    --standalone \
    --email "${CERTBOT_EMAIL}" \
    --agree-tos \
    --no-eff-email \
    ${DOMAIN_ARGS}

echo ""
echo "SSL certificates obtained!"
echo ""
echo "Now update nginx/conf.d/pinpoint.conf to:"
echo "  1. Listen on port 443 with ssl"
echo "  2. Add ssl_certificate and ssl_certificate_key directives"
echo "  3. Add a redirect from port 80 to 443"
echo ""
echo "Then restart Nginx:"
echo "  docker compose restart nginx"
echo ""
echo "Auto-renewal cron (add to crontab):"
echo "  0 3 1 */2 * docker run --rm -v \$(pwd)/nginx/ssl:/etc/letsencrypt certbot/certbot renew && docker compose restart nginx"
