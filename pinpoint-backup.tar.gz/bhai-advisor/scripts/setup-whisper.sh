#!/bin/bash
# Setup faster-whisper for BhaiAdvisor
# Creates a Python virtual environment and installs faster-whisper

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$SCRIPT_DIR/../whisper-env"

echo "🎙️ Setting up faster-whisper for BhaiAdvisor..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ python3 not found. Install Python 3.8+ first."
    exit 1
fi

echo "📦 Python version: $(python3 --version)"

# Create virtual environment
if [ -d "$VENV_DIR" ]; then
    echo "⚠️  Whisper environment already exists at $VENV_DIR"
    read -p "Reinstall? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf "$VENV_DIR"
    else
        echo "Skipping installation."
        exit 0
    fi
fi

echo "Creating virtual environment..."
python3 -m venv "$VENV_DIR"

echo "Activating virtual environment..."
source "$VENV_DIR/bin/activate"

echo "Installing faster-whisper..."
pip install --upgrade pip
pip install faster-whisper

echo ""
echo "✅ Whisper installed successfully!"
echo ""
echo "To use whisper in your project:"
echo "  source $VENV_DIR/bin/activate"
echo "  python3 src/whisper-wrapper.py <audio-file>"
echo ""
echo "The server will auto-detect the whisper-env directory."
