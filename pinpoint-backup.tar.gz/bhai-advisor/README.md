# BhaiAdvisor — AI Business Companion for Restaurant Owners in Bangladesh 🇧🇩

An AI-powered daily advisor that helps Bangladeshi restaurant owners make smarter business decisions.

## How It Works

1. Restaurant owner sends daily data via WhatsApp (text or voice)
2. System transcribes voice messages using faster-whisper
3. Stores daily data in files
4. Every morning at 7 AM, generates personalized suggestions using GPT-4o Mini
5. Sends suggestions back via WhatsApp

## Setup

### 1. Clone and Install

```bash
git clone <repo-url>
cd bhai-advisor
npm install
```

### 2. Environment Variables

```bash
cp .env.example .env
# Edit .env and add your OpenAI API key
```

Required variables:
- `OPENAI_API_KEY` — Your OpenAI API key (for GPT-4o Mini)
- `WHISPER_MODEL` — Whisper model size (default: `base`)
- `MORNING_REPORT_CRON` — Cron schedule (default: `0 7 * * *` = 7 AM daily)
- `PORT` — Server port (default: `3001`)

### 3. Install Whisper (for voice transcription)

```bash
chmod +x scripts/setup-whisper.sh
./scripts/setup-whisper.sh
```

This creates a Python virtual environment at `../whisper-env/` and installs faster-whisper.

### 4. Add Restaurant Data

Each restaurant needs two files in `data/restaurants/{restaurant-id}/`:

- **memory.md** — Restaurant profile (copy from `memory/restaurant-template.md`)
- **daily/** — Directory for daily data JSON files

An example restaurant is included at `data/restaurants/example-restaurant/`.

### 5. Set Up Phone-to-Restaurant Mapping

Create `data/phone-map.json` to map WhatsApp phone numbers to restaurant IDs:

```json
{
  "+8801711XXXXXX": "example-restaurant",
  "+8801811XXXXXX": "another-restaurant"
}
```

### 6. Start the Server

```bash
npm start
# or for development with auto-reload:
npm run dev
```

### 7. Configure WhatsApp Webhook

Point your WhatsApp Business webhook to:

```
https://your-server.com/webhook
```

Set the verify token in your `.env` file (or use the default `bhaiadvisor-verify`).

## Usage

### Sending Daily Data (via WhatsApp)

**Text format:**
```
sales=45000, chicken biryani 22 plates, chicken ran out at 7pm, expenses=12000, slow day only 30 customers
```

**Voice message:**
Just speak naturally! The system will transcribe and parse the data.

### Morning Reports

Reports are automatically generated at 7 AM daily (configurable via `MORNING_REPORT_CRON`).

To manually trigger a report:

```bash
# Via CLI
npm run morning-report

# Via HTTP
curl -X POST http://localhost:3001/trigger-report
```

### Test AI

```bash
npm run test-ai
```

## Project Structure

```
bhai-advisor/
├── src/
│   ├── server.js           # Express server + WhatsApp webhook
│   ├── morning-report.js   # Daily report CRON job
│   ├── ai-engine.js        # RAG pipeline + GPT-4o Mini calls
│   ├── transcribe.js       # Audio transcription module
│   ├── data-manager.js     # File-based data storage
│   ├── whisper-wrapper.py  # Python faster-whisper wrapper
│   └── prompts/
│       └── system-prompt.txt  # AI personality prompt
├── data/
│   ├── restaurants/
│   │   └── {id}/
│   │       ├── memory.md   # Restaurant profile
│   │       └── daily/      # Daily data JSON files
│   └── suggestions/
│       └── {id}/           # AI-generated suggestions
├── memory/
│   └── restaurant-template.md  # Template for new restaurants
├── scripts/
│   └── setup-whisper.sh    # Whisper installation script
├── .env.example
├── package.json
└── README.md
```

## RAG Pipeline

1. **Retrieve** — Load `memory.md` (restaurant profile) + last 7 days of `daily/*.json`
2. **Augment** — Build prompt = system prompt + retrieved data + latest daily data + analysis context
3. **Generate** — Call GPT-4o Mini with the augmented prompt
4. **Store** — Save suggestions to `data/suggestions/{restaurant}/{date}.json`

## Tech Stack

- **Runtime:** Node.js (ES Modules)
- **Server:** Express.js
- **AI:** OpenAI GPT-4o Mini
- **Transcription:** faster-whisper (Python)
- **Scheduling:** node-cron
- **Storage:** File-based JSON

## License

MIT
