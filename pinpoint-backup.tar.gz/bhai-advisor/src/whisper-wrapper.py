#!/usr/bin/env python3
"""
BhaiAdvisor Whisper Wrapper
Transcribes audio files using faster-whisper
Handles Bangla (bn) and English (en) automatically

Usage:
    python whisper-wrapper.py <audio-file-path>

Output:
    Prints transcribed text to stdout
"""

import sys
import os

# Suppress warning logs from whisper
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

try:
    from faster_whisper import WhisperModel
except ImportError:
    print("ERROR: faster-whisper not installed. Run: pip install faster-whisper", file=sys.stderr)
    sys.exit(1)


def main():
    if len(sys.argv) < 2:
        print("Usage: python whisper-wrapper.py <audio-file>", file=sys.stderr)
        sys.exit(1)

    audio_file = sys.argv[1]

    if not os.path.exists(audio_file):
        print(f"ERROR: File not found: {audio_file}", file=sys.stderr)
        sys.exit(1)

    # Load model (base model, CPU-optimized)
    # Will auto-download on first run
    try:
        model = WhisperModel("base", device="cpu", compute_type="int8")
    except Exception as e:
        print(f"ERROR: Failed to load Whisper model: {e}", file=sys.stderr)
        sys.exit(1)

    # Transcribe with VAD filter for better accuracy
    try:
        segments, info = model.transcribe(
            audio_file,
            beam_size=5,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500),
            # Auto-detect language, prefer Bangla or English
            language=None,
        )
    except Exception as e:
        print(f"ERROR: Transcription failed: {e}", file=sys.stderr)
        sys.exit(1)

    # Collect all segments
    full_text = ""
    for segment in segments:
        full_text += segment.text + " "

    result = full_text.strip()

    if not result:
        print("ERROR: No speech detected in audio", file=sys.stderr)
        sys.exit(1)

    # Print result to stdout (this is what Node reads)
    print(result)

    # Log detected language to stderr (for debugging)
    detected_lang = getattr(info, 'language', 'unknown')
    lang_confidence = getattr(info, 'language_probability', 0)
    print(f"Detected language: {detected_lang} ({lang_confidence:.0%})", file=sys.stderr)


if __name__ == "__main__":
    main()
