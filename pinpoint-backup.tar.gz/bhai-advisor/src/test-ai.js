#!/usr/bin/env node
/**
 * Test AI Engine
 * Tests the RAG pipeline with the example restaurant
 * Run: npm run test-ai
 */

import dotenv from 'dotenv';
import { buildRAGPrompt, generateSuggestions } from './ai-engine.js';

dotenv.config();

async function testAI() {
  console.log('🧪 Testing AI Engine with example-restaurant...\n');

  if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === 'your-key') {
    console.error('❌ OPENAI_API_KEY not set. Add your key to .env first.');
    process.exit(1);
  }

  try {
    // Build the RAG prompt
    console.log('1️⃣  Building RAG prompt...');
    const prompt = await buildRAGPrompt('example-restaurant');

    console.log(`   Prompt length: ${prompt.length} chars`);
    console.log('\n--- PROMPT PREVIEW ---');
    console.log(prompt.substring(0, 500) + '...');
    console.log('--- END PREVIEW ---\n');

    // Generate suggestions
    console.log('2️⃣  Calling GPT-4o Mini...');
    const suggestions = await generateSuggestions(prompt);

    console.log('\n--- AI SUGGESTIONS ---');
    console.log(suggestions.text);
    console.log('--- END SUGGESTIONS ---\n');

    console.log('📊 Metadata:');
    console.log(`   Model: ${suggestions.model}`);
    console.log(`   Tokens: ${suggestions.usage?.total_tokens || 'N/A'}`);
    console.log(`   Timestamp: ${suggestions.timestamp}`);

    if (suggestions.error) {
      console.log('\n⚠️  Response was a fallback (API error)');
    } else {
      console.log('\n✅ AI test passed!');
    }
  } catch (err) {
    console.error('\n❌ Test failed:', err.message);
    process.exit(1);
  }
}

testAI();
