#!/usr/bin/env node
/**
 * Morning Report Generator
 * Runs daily at 7 AM (or manually via `npm run morning-report`)
 * Reads all restaurant data → builds RAG prompt → generates AI suggestions
 */

import dotenv from 'dotenv';
import { listRestaurants, saveSuggestion } from './data-manager.js';
import { buildRAGPrompt, generateSuggestions } from './ai-engine.js';
import fs from 'fs-extra';
import path from 'path';

dotenv.config();

const SUGGESTIONS_DIR = path.resolve('./data/suggestions');

async function runMorningReport() {
  console.log('🌅 Starting morning report generation...\n');

  try {
    const restaurants = await listRestaurants();

    if (restaurants.length === 0) {
      console.log('⚠️  No restaurants found. Add restaurants to data/restaurants/');
      process.exit(0);
    }

    console.log(`📋 Found ${restaurants.length} restaurant(s): ${restaurants.join(', ')}\n`);

    const today = new Date().toISOString().split('T')[0];
    const results = [];

    for (const restaurantId of restaurants) {
      console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
      console.log(`📊 Processing: ${restaurantId}`);
      console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

      try {
        // Step 1: Retrieve — load memory + last 7 days data
        console.log('  📥 Retrieving restaurant data...');
        const prompt = await buildRAGPrompt(restaurantId);

        // Step 2: Augment + Generate — call GPT-4o Mini
        console.log('  🤖 Generating AI suggestions...');
        const suggestions = await generateSuggestions(prompt);

        // Step 3: Store — save suggestions
        console.log('  💾 Saving suggestions...');
        await saveSuggestion(restaurantId, today, suggestions);

        results.push({
          restaurant: restaurantId,
          date: today,
          success: true,
        });

        console.log(`  ✅ Done for ${restaurantId}\n`);
      } catch (err) {
        console.error(`  ❌ Error for ${restaurantId}:`, err.message);
        results.push({
          restaurant: restaurantId,
          date: today,
          success: false,
          error: err.message,
        });
      }
    }

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('🌅 Morning report complete!');
    console.log(`   ${results.filter(r => r.success).length}/${results.length} successful`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    return results;
  } catch (err) {
    console.error('❌ Fatal error in morning report:', err);
    process.exit(1);
  }
}

// Run if called directly
runMorningReport()
  .then(() => {
    console.log('\nDone. Exiting...');
    process.exit(0);
  })
  .catch((err) => {
    console.error('Failed:', err);
    process.exit(1);
  });

export { runMorningReport };
