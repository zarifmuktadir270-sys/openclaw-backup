/**
 * Audio Transcription Module
 * Uses faster-whisper (Python) via child_process to transcribe
 * audio files — handles both Bangla and English
 */

import { execFile } from 'child_process';
import path from 'path';
import fs from 'fs-extra';

const WHISPER_WRAPPER = path.resolve('./src/whisper-wrapper.py');
const WHISPER_ENV_PYTHON = path.resolve('../whisper-env/bin/python');
const SYSTEM_PYTHON = 'python3';

/**
 * Transcribe an audio file using faster-whisper
 * @param {string} audioFilePath - Path to the audio file
 * @returns {Promise<string>} - Transcribed text
 */
export async function transcribeAudio(audioFilePath) {
  // Verify file exists
  if (!(await fs.pathExists(audioFilePath))) {
    throw new Error(`Audio file not found: ${audioFilePath}`);
  }

  // Determine which python to use
  const pythonCmd = (await fs.pathExists(WHISPER_ENV_PYTHON))
    ? WHISPER_ENV_PYTHON
    : SYSTEM_PYTHON;

  return new Promise((resolve, reject) => {
    execFile(
      pythonCmd,
      [WHISPER_WRAPPER, audioFilePath],
      {
        timeout: 5 * 60 * 1000, // 5 minute timeout
        env: { ...process.env, PYTHONIOENCODING: 'utf-8' },
      },
      (error, stdout, stderr) => {
        if (error) {
          console.error('Whisper error:', stderr || error.message);
          return reject(new Error(`Transcription failed: ${error.message}`));
        }

        const text = stdout.trim();
        if (!text) {
          return reject(new Error('Transcription returned empty text'));
        }

        resolve(text);
      }
    );
  });
}

/**
 * Detect language from audio using whisper (for logging)
 * @param {string} audioFilePath
 * @returns {Promise<string>} - Language code
 */
export async function detectLanguage(audioFilePath) {
  // faster-whisper detects language automatically during transcription
  // This is just a helper to log what was detected
  const pythonCmd = (await fs.pathExists(WHISPER_ENV_PYTHON))
    ? WHISPER_ENV_PYTHON
    : SYSTEM_PYTHON;

  return new Promise((resolve, reject) => {
    execFile(
      pythonCmd,
      ['-c', `
import sys
sys.path.insert(0, '${path.dirname(WHISPER_WRAPPER)}')
from faster_whisper import WhisperModel
model = WhisperModel("base", device="cpu", compute_type="int8")
segments, info = model.transcribe("${audioFilePath}", beam_size=1, vad_filter=True)
print(info.language)
`],
      { timeout: 2 * 60 * 1000 },
      (error, stdout) => {
        if (error) return reject(error);
        resolve(stdout.trim());
      }
    );
  });
}
