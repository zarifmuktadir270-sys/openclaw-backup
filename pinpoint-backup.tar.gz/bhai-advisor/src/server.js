import express from 'express';
import cron from 'node-cron';
import dotenv from 'dotenv';
import { saveDailyData } from './data-manager.js';
import { transcribeAudio } from './transcribe.js';
import { buildRAGPrompt, generateSuggestions } from './ai-engine.js';
import { listRestaurants, saveSuggestion } from './data-manager.js';
import fs from 'fs-extra';
import path from 'path';

dotenv.config();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 3001;
const DATA_DIR = path.resolve('./data/restaurants');
const SUGGESTIONS_DIR = path.resolve('./data/suggestions');

// ─── WhatsApp Webhook Verification (Meta requires GET) ───
app.get('/webhook', (req, res) => {
  const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN || 'bhaiadvisor-verify';
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('✅ WhatsApp webhook verified');
    return res.status(200).send(challenge);
  }
  res.sendStatus(403);
});

// ─── WhatsApp Webhook (POST — incoming messages) ───
app.post('/webhook', async (req, res) => {
  // Acknowledge immediately to prevent Meta retries
  res.sendStatus(200);

  try {
    const body = req.body;

    if (body.object !== 'whatsapp_business_account') {
      return;
    }

    for (const entry of body.entry || []) {
      for (const change of entry.changes || []) {
        const value = change.value;
        if (!value?.messages) continue;

        for (const message of value.messages) {
          const from = message.from; // phone number
          const restaurantId = await resolveRestaurantByPhone(from);

          if (!restaurantId) {
            console.log(`⚠️ Unknown sender: ${from}`);
            continue;
          }

          // ── Text message ──
          if (message.type === 'text') {
            const text = message.text.body;
            console.log(`📩 Text from ${restaurantId}: ${text}`);
            await handleIncomingData(restaurantId, text, 'text');
          }

          // ── Audio (voice) message ──
          if (message.type === 'audio' || message.type === 'voice') {
            const audioId = message.audio?.id || message.voice?.id;
            console.log(`🎙️ Audio from ${restaurantId}: ${audioId}`);

            // Download audio from WhatsApp
            const audioPath = await downloadWhatsAppAudio(audioId, restaurantId);
            if (audioPath) {
              // Transcribe
              const transcription = await transcribeAudio(audioPath);
              console.log(`📝 Transcribed: ${transcription}`);
              await handleIncomingData(restaurantId, transcription, 'voice');

              // Clean up audio file
              await fs.remove(audioPath);
            }
          }
        }
      }
    }
  } catch (err) {
    console.error('❌ Webhook error:', err);
  }
});

// ─── Resolve restaurant ID from phone number ───
// Uses a simple mapping file: data/phone-map.json
// e.g. { "+8801711XXXXXX": "example-restaurant" }
async function resolveRestaurantByPhone(phoneNumber) {
  const mapPath = path.resolve('./data/phone-map.json');
  try {
    if (await fs.pathExists(mapPath)) {
      const map = await fs.readJson(mapPath);
      return map[phoneNumber] || null;
    }
  } catch (err) {
    console.error('Phone map error:', err);
  }

  // Fallback: check if any restaurant has a matching phone in memory.md
  const restaurants = await listRestaurants();
  for (const rid of restaurants) {
    const memPath = path.resolve(`./data/restaurants/${rid}/memory.md`);
    try {
      const content = await fs.readFile(memPath, 'utf-8');
      if (content.includes(phoneNumber)) {
        return rid;
      }
    } catch { /* skip */ }
  }

  return null;
}

// ─── Download WhatsApp media ───
async function downloadWhatsAppAudio(mediaId, restaurantId) {
  try {
    const axios = (await import('axios')).default;
    const token = process.env.WHATSAPP_ACCESS_TOKEN;

    // Get media URL
    const { data: urlData } = await axios.get(
      `https://graph.facebook.com/v18.0/${mediaId}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );

    // Download media
    const downloadDir = path.resolve(`./data/restaurants/${restaurantId}/audio`);
    await fs.ensureDir(downloadDir);
    const filePath = path.join(downloadDir, `${mediaId}.ogg`);

    const response = await axios.get(urlData.url, {
      headers: { Authorization: `Bearer ${token}` },
      responseType: 'stream',
    });

    const writer = fs.createWriteStream(filePath);
    response.data.pipe(writer);

    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });

    return filePath;
  } catch (err) {
    console.error('Audio download error:', err.message);
    return null;
  }
}

// ─── Handle incoming data (text or transcribed voice) ───
async function handleIncomingData(restaurantId, content, sentVia) {
  const today = new Date().toISOString().split('T')[0];

  // Try to parse structured data from the message
  // Expected format: "sales=45000, chicken biryani 22 plates, chicken ran out at 7pm, expenses=12000, slow day only 30 customers"
  const parsed = parseDailyUpdate(content);

  const dailyData = {
    date: today,
    raw_message: content,
    sent_via: sentVia,
    ...parsed,
  };

  await saveDailyData(restaurantId, dailyData);
  console.log(`💾 Saved daily data for ${restaurantId} (${today})`);
}

// ─── Parse natural language daily update ───
function parseDailyUpdate(text) {
  const data = {};

  // Sales: "sales=45000" or "sales 45000" or "45000 taka" or "৳45000"
  const salesMatch = text.match(/(?:sales|total|总收入)[:\s]*[৳]?\s*(\d[\d,]*)/i);
  if (salesMatch) {
    data.sales = parseInt(salesMatch[1].replace(/,/g, ''));
  }

  // Best seller: "chicken biryani 22" or "best: chicken biryani (22)"
  const sellerMatch = text.match(/(?:best\s*(?:seller)?|সবচেয়ে বেশি)[:\s]*([a-zA-Z\s]+?)[\s(]*(\d+)?[)]?\s*(?:plates?|pieces?|units?)?/i);
  if (sellerMatch) {
    data.best_seller = sellerMatch[1].trim();
    if (sellerMatch[2]) data.best_seller_count = parseInt(sellerMatch[2]);
  }

  // Stock issues: "ran out of X at Ypm"
  const stockMatch = text.match(/(?:ran out|stock out| shortage)[:\s]*(?:of\s*)?(.+?)(?:at\s*(\d+\s*(?:AM|PM|am|pm))?|$)/i);
  if (stockMatch) {
    data.stock_issues = [stockMatch[1].trim() + (stockMatch[2] ? ` at ${stockMatch[2]}` : '')];
  }

  // Expenses: "expenses=12000" or "expense 12000"
  const expenseMatch = text.match(/(?:expenses?|খরচ)[:\s]*[৳]?\s*(\d[\d,]*)/i);
  if (expenseMatch) {
    data.expenses = parseInt(expenseMatch[1].replace(/,/g, ''));
  }

  // Notes: everything else becomes the note
  let notes = text
    .replace(/sales[=:]\s*\d[\d,]*/gi, '')
    .replace(/expenses?[=:]\s*\d[\d,]*/gi, '')
    .trim();
  if (notes.length > 5) {
    data.notes = notes;
  }

  return data;
}

// ─── CRON: Morning Report at 7 AM ───
const cronSchedule = process.env.MORNING_REPORT_CRON || '0 7 * * *';
cron.schedule(cronSchedule, async () => {
  console.log('🌅 Running morning report...');
  try {
    const restaurants = await listRestaurants();
    const today = new Date().toISOString().split('T')[0];

    for (const restaurantId of restaurants) {
      console.log(`📊 Generating report for ${restaurantId}...`);
      const prompt = await buildRAGPrompt(restaurantId);
      const suggestions = await generateSuggestions(prompt);
      await saveSuggestion(restaurantId, today, suggestions);
      console.log(`✅ Report saved for ${restaurantId}`);
    }

    console.log('🌅 Morning report complete!');
  } catch (err) {
    console.error('❌ Morning report error:', err);
  }
});

// ─── Health check ───
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'bhai-advisor', time: new Date().toISOString() });
});

// ─── Manual trigger endpoint (for testing) ───
app.post('/trigger-report', async (req, res) => {
  try {
    const restaurants = await listRestaurants();
    const today = new Date().toISOString().split('T')[0];
    const results = [];

    for (const restaurantId of restaurants) {
      const prompt = await buildRAGPrompt(restaurantId);
      const suggestions = await generateSuggestions(prompt);
      await saveSuggestion(restaurantId, today, suggestions);
      results.push({ restaurant: restaurantId, suggestions });
    }

    res.json({ status: 'ok', results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Start server ───
app.listen(PORT, () => {
  console.log(`🔥 BhaiAdvisor running on port ${PORT}`);
  console.log(`📅 Morning report cron: ${cronSchedule}`);
});

export default app;
