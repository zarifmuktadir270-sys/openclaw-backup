/**
 * AI Engine — The Brain of BhaiAdvisor
 *
 * RAG Pipeline:
 * 1. Retrieve: Load memory.md + last 7 days of daily/*.json
 * 2. Augment: Build prompt = system-prompt + retrieved data + latest daily data
 * 3. Generate: Call GPT-4o-mini → get suggestions
 * 4. Store: Save suggestions to suggestions/{restaurant}/{date}.json
 */

import OpenAI from 'openai';
import dotenv from 'dotenv';
import fs from 'fs-extra';
import path from 'path';
import { getMemoryFile, getDailyData } from './data-manager.js';

dotenv.config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const SYSTEM_PROMPT_PATH = path.resolve('./src/prompts/system-prompt.txt');

/**
 * Build a RAG prompt for a restaurant
 * Combines system prompt + memory file + last 7 days of daily data
 * @param {string} restaurantId
 * @returns {string} - Full augmented prompt
 */
export async function buildRAGPrompt(restaurantId) {
  // 1. Load system prompt
  const systemPrompt = await fs.readFile(SYSTEM_PROMPT_PATH, 'utf-8');

  // 2. Load restaurant memory (profile)
  const memory = await getMemoryFile(restaurantId);

  // 3. Load last 7 days of daily data
  const dailyData = await getDailyData(restaurantId, 7);

  // 4. Build the augmented prompt
  let augmentedPrompt = '';

  // System instructions
  augmentedPrompt += '## System Instructions\n';
  augmentedPrompt += systemPrompt + '\n\n';

  // Restaurant profile (memory)
  augmentedPrompt += '## Restaurant Profile\n';
  if (memory) {
    augmentedPrompt += memory + '\n\n';
  } else {
    augmentedPrompt += '(No profile data available yet)\n\n';
  }

  // Historical data (last 7 days)
  augmentedPrompt += '## Last 7 Days Data\n';
  if (dailyData.length > 0) {
    for (const day of dailyData) {
      augmentedPrompt += `### ${day.date}\n`;
      augmentedPrompt += formatDailyData(day);
      augmentedPrompt += '\n';
    }
  } else {
    augmentedPrompt += '(No daily data recorded yet)\n';
  }

  // Today's data (most recent entry, if available)
  const todayData = dailyData.length > 0 ? dailyData[dailyData.length - 1] : null;
  augmentedPrompt += '\n## Today\'s Data (Latest Entry)\n';
  if (todayData) {
    augmentedPrompt += formatDailyData(todayData);
  } else {
    augmentedPrompt += '(No data submitted today yet)\n';
  }

  // Contextual analysis hints
  augmentedPrompt += '\n## Analysis Context\n';
  if (dailyData.length >= 2) {
    const salesList = dailyData.filter(d => d.sales).map(d => d.sales);
    if (salesList.length > 0) {
      const avgSales = Math.round(salesList.reduce((a, b) => a + b, 0) / salesList.length);
      const maxSales = Math.max(...salesList);
      const minSales = Math.min(...salesList);
      augmentedPrompt += `- 7-day avg sales: ৳${avgSales}\n`;
      augmentedPrompt += `- Best day: ৳${maxSales}\n`;
      augmentedPrompt += `- Worst day: ৳${minSales}\n`;
    }

    // Check for trends
    if (salesList.length >= 3) {
      const recent = salesList.slice(-3);
      const trend = recent[recent.length - 1] - recent[0];
      if (trend > 0) {
        augmentedPrompt += `- Trend: Sales are going UP (+৳${trend})\n`;
      } else if (trend < 0) {
        augmentedPrompt += `- Trend: Sales are going DOWN (৳${trend})\n`;
      } else {
        augmentedPrompt += `- Trend: Sales are stable\n`;
      }
    }

    // Stock issues summary
    const allIssues = dailyData.flatMap(d => d.stock_issues || []);
    if (allIssues.length > 0) {
      augmentedPrompt += `- Stock issues this week: ${allIssues.join('; ')}\n`;
    }
  }

  // Final instruction
  augmentedPrompt += '\n## Task\n';
  augmentedPrompt += 'Based on all the data above, generate a personalized morning message for the restaurant owner. ';
  augmentedPrompt += 'Follow the format in the system instructions. Be specific with numbers. Give 2-4 actionable items. ';
  augmentedPrompt += 'Keep it under 150 words. Mix Bangla and English naturally.';

  return augmentedPrompt;
}

/**
 * Call GPT-4o Mini to generate suggestions
 * @param {string} prompt - The augmented RAG prompt
 * @returns {Promise<object>} - { text, raw_response, timestamp }
 */
export async function generateSuggestions(prompt) {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY not set. Add it to .env');
  }

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are BhaiAdvisor, a sharp business coach for Bangladeshi restaurant owners.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 300,
      response_format: { type: 'text' },
    });

    const text = completion.choices[0]?.message?.content?.trim();

    if (!text) {
      throw new Error('Empty response from GPT-4o Mini');
    }

    console.log(`    💬 AI Response (${text.length} chars)`);

    return {
      text,
      model: completion.model,
      usage: {
        prompt_tokens: completion.usage?.prompt_tokens,
        completion_tokens: completion.usage?.completion_tokens,
        total_tokens: completion.usage?.total_tokens,
      },
      timestamp: new Date().toISOString(),
    };
  } catch (err) {
    console.error('OpenAI API error:', err.message);

    // Fallback: generate a basic suggestion without AI
    return {
      text: 'Bhai, AI service temporary down ache. Kalke data check kore asha kori. Please try again in a few minutes.',
      model: 'fallback',
      usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
      timestamp: new Date().toISOString(),
      error: true,
    };
  }
}

/**
 * Format daily data object as readable text for the prompt
 * @param {object} data - Daily data entry
 * @returns {string}
 */
function formatDailyData(data) {
  let text = '';
  if (data.sales) text += `- Sales: ৳${data.sales}\n`;
  if (data.best_seller) text += `- Best seller: ${data.best_seller}${data.best_seller_count ? ` (${data.best_seller_count} sold)` : ''}\n`;
  if (data.stock_issues?.length) text += `- Stock issues: ${data.stock_issues.join(', ')}\n`;
  if (data.expenses) text += `- Expenses: ৳${data.expenses}\n`;
  if (data.notes) text += `- Notes: ${data.notes}\n`;
  if (data.raw_message && !data.sales && !data.best_seller) text += `- Message: ${data.raw_message}\n`;
  return text || '(No structured data)\n';
}
