/**
 * Data Manager — File-based storage for BhaiAdvisor
 *
 * Directory structure:
 * data/
 * ├── restaurants/
 * │   ├── {restaurant-id}/
 * │   │   ├── memory.md          (restaurant profile)
 * │   │   ├── daily/
 * │   │   │   ├── 2026-03-30.json
 * │   │   │   ├── 2026-03-31.json
 * │   │   │   └── ...
 * │   │   └── audio/             (temporary audio files)
 * │   └── ...
 * └── suggestions/
 *     ├── {restaurant-id}/
 *     │   ├── 2026-03-30.json
 *     │   └── ...
 *     └── ...
 */

import fs from 'fs-extra';
import path from 'path';

const BASE_DIR = path.resolve('./data');
const RESTAURANTS_DIR = path.join(BASE_DIR, 'restaurants');
const SUGGESTIONS_DIR = path.join(BASE_DIR, 'suggestions');

// Ensure directories exist
await fs.ensureDir(RESTAURANTS_DIR);
await fs.ensureDir(SUGGESTIONS_DIR);

/**
 * Save daily data entry for a restaurant
 * @param {string} restaurantId - Restaurant identifier (e.g., "example-restaurant")
 * @param {object} data - Daily data object
 */
export async function saveDailyData(restaurantId, data) {
  const dailyDir = path.join(RESTAURANTS_DIR, restaurantId, 'daily');
  await fs.ensureDir(dailyDir);

  const filePath = path.join(dailyDir, `${data.date}.json`);

  // If file exists, merge with existing data
  let existing = {};
  if (await fs.pathExists(filePath)) {
    try {
      existing = await fs.readJson(filePath);
    } catch { /* use empty */ }
  }

  const merged = {
    ...existing,
    ...data,
    updated_at: new Date().toISOString(),
  };

  await fs.writeJson(filePath, merged, { spaces: 2 });
  return merged;
}

/**
 * Get last N days of daily data for a restaurant
 * @param {string} restaurantId
 * @param {number} days - Number of days to retrieve (default: 7)
 * @returns {Promise<Array>} - Array of daily data objects, sorted by date ascending
 */
export async function getDailyData(restaurantId, days = 7) {
  const dailyDir = path.join(RESTAURANTS_DIR, restaurantId, 'daily');

  if (!(await fs.pathExists(dailyDir))) {
    return [];
  }

  const files = await fs.readdir(dailyDir);
  const jsonFiles = files
    .filter(f => f.endsWith('.json'))
    .sort()
    .reverse() // newest first
    .slice(0, days)
    .reverse(); // oldest first for chronological order

  const data = [];
  for (const file of jsonFiles) {
    try {
      const entry = await fs.readJson(path.join(dailyDir, file));
      data.push(entry);
    } catch (err) {
      console.error(`Error reading ${file}:`, err.message);
    }
  }

  return data;
}

/**
 * Get the memory file (restaurant profile) for a restaurant
 * @param {string} restaurantId
 * @returns {Promise<string|null>} - Memory file content or null
 */
export async function getMemoryFile(restaurantId) {
  const memoryPath = path.join(RESTAURANTS_DIR, restaurantId, 'memory.md');

  if (!(await fs.pathExists(memoryPath))) {
    console.warn(`⚠️ No memory file found for ${restaurantId}`);
    return null;
  }

  return fs.readFile(memoryPath, 'utf-8');
}

/**
 * Save morning report suggestions for a restaurant
 * @param {string} restaurantId
 * @param {string} date - Date string (YYYY-MM-DD)
 * @param {object} suggestions - { text, model, usage, timestamp }
 */
export async function saveSuggestion(restaurantId, date, suggestions) {
  const suggestionDir = path.join(SUGGESTIONS_DIR, restaurantId);
  await fs.ensureDir(suggestionDir);

  const filePath = path.join(suggestionDir, `${date}.json`);

  const entry = {
    date,
    restaurant: restaurantId,
    ...suggestions,
    created_at: new Date().toISOString(),
  };

  await fs.writeJson(filePath, entry, { spaces: 2 });
  return entry;
}

/**
 * Get suggestions for a restaurant on a specific date
 * @param {string} restaurantId
 * @param {string} date - Date string (YYYY-MM-DD)
 * @returns {Promise<object|null>}
 */
export async function getSuggestion(restaurantId, date) {
  const filePath = path.join(SUGGESTIONS_DIR, restaurantId, `${date}.json`);

  if (!(await fs.pathExists(filePath))) {
    return null;
  }

  return fs.readJson(filePath);
}

/**
 * Get suggestions for a restaurant for the last N days
 * @param {string} restaurantId
 * @param {number} days
 * @returns {Promise<Array>}
 */
export async function getSuggestionsHistory(restaurantId, days = 7) {
  const suggestionDir = path.join(SUGGESTIONS_DIR, restaurantId);

  if (!(await fs.pathExists(suggestionDir))) {
    return [];
  }

  const files = await fs.readdir(suggestionDir);
  const jsonFiles = files
    .filter(f => f.endsWith('.json'))
    .sort()
    .reverse()
    .slice(0, days);

  const suggestions = [];
  for (const file of jsonFiles) {
    try {
      const entry = await fs.readJson(path.join(suggestionDir, file));
      suggestions.push(entry);
    } catch { /* skip */ }
  }

  return suggestions;
}

/**
 * List all restaurant IDs (subdirectories of data/restaurants/)
 * @returns {Promise<string[]>}
 */
export async function listRestaurants() {
  if (!(await fs.pathExists(RESTAURANTS_DIR))) {
    return [];
  }

  const entries = await fs.readdir(RESTAURANTS_DIR, { withFileTypes: true });
  return entries
    .filter(e => e.isDirectory())
    .map(e => e.name);
}

/**
 * Get a restaurant's full info (memory + recent stats)
 * @param {string} restaurantId
 * @returns {Promise<object>}
 */
export async function getRestaurantInfo(restaurantId) {
  const memory = await getMemoryFile(restaurantId);
  const recentData = await getDailyData(restaurantId, 7);
  const recentSuggestions = await getSuggestionsHistory(restaurantId, 3);

  return {
    id: restaurantId,
    memory,
    recentData,
    recentSuggestions,
    hasData: recentData.length > 0,
  };
}
