# Restaurant: {name}

## Basic Info
- Owner: {owner_name}
- Location: {location}
- Seats: {seats}
- Staff: {staff_description}
- Hours: {hours}
- Open since: {since}

## Financial
- Monthly rent: {rent}
- Monthly target: {target}
- Average daily sales: {avg_sales}
- Best day: {best_day_info}
- Worst day: {worst_day_info}

## Menu
- Best seller: {best_seller}
- Second best: {second_best}
- Dead items: {dead_items}
- Food cost target: {food_cost_target}%
- Food cost actual: {food_cost_actual}%

## Suppliers
- {item}: {supplier_name} ({phone})

## Patterns
{learned_patterns}

## Current Issues
{current_issues}
