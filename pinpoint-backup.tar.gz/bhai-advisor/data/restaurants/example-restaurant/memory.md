# Restaurant: Rahim's Biryani House

## Basic Info
- Owner: Rahim bhai
- Location: Dhanmondi, Dhaka
- Seats: 45
- Staff: 2 waiters, 1 chef, 1 helper
- Hours: 11 AM - 10 PM
- Open since: 2019

## Financial
- Monthly rent: ৳35,000
- Monthly target: ৳12,00,000
- Average daily sales: ৳40,000
- Best day: Friday (৳65,000)
- Worst day: Monday (৳25,000)

## Menu
- Best seller: Chicken Biryani (40% of sales)
- Second: Kacchi Biryani (25%)
- Dead items: Mutton Roast
- Food cost target: 33%
- Food cost actual: 38%

## Suppliers
- Chicken: Raju Chicken (01711-XXXXX), delivers 6 AM daily
- Rice: Karim Rice (01811-XXXXX), Mon/Thu

## Patterns
- Friday rush: prep 30% extra chicken
- Rainy days: delivery orders spike 40%
- Month-end: sales drop (rent season)

## Current Issues
- Food cost too high (38% vs 33%)
- Chicken supplier raised prices 12%
- Only 1 chef
